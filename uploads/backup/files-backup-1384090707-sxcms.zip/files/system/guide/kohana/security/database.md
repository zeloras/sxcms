Discuss database security.

How to avoid injection, etc.

Not sure why I'm linking to this: <http://kohanaframework.org/guide/security.database>