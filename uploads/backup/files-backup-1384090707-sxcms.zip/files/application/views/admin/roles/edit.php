<div class="main">
    <div class="container">
        <div class="row">
            <div class="span12">
                <div class="widget stacked">
<div class="widget-header">
    <i class="icon-file"></i>
    <h3><?=__('Role edit')?></h3>
    <span class="action_buttons">
        <button class="btn pull-right formSubmit" data-form="#submit-form" data-after="exit" data-action="/admin/roles/edit/<?=$role_id?>">
            <i class=" icon-save icon-large"></i> <?=__('Save and exit')?>
        </button>
        <button class="btn btn-success pull-right formSubmit" data-form="#submit-form" data-after="save" data-action="/admin/roles/edit/<?=$role_id?>">
            <i class=" icon-save icon-large"></i> <?=__('Save')?>
        </button>
        <button data-href="/admin/roles" data-container="#base-container" class="btn pull-right btn-info pjax_button">
            <i class="icon-arrow-left"></i> <?=__('Back')?>
        </button>
    </span>
</div>
                    
<div class="widget-content">
    <?if (isset($success)) {?>
        <div id="success_block">
            <p id="status_success">showMessage('<?=__('Success edit role')?>', '<?=__('Status role edit')?>', 'success')</p>
            <p id="url_success">/admin/roles/edit/<?=$success?></p>
            <p id="url_success_exit">/admin/roles/</p>
        </div>
    <?}?>
    <div id="errors_block">
        <?if (isset($errors)) {?>
        <div class="alert alert-error">
            <strong><?=__('Error')?></strong>
            <ul>
                <?foreach ($errors as $error) {?>
                    <li><?=__($error)?></li>
                <?}?>
            </ul>
        </div>
        <?}?>
    </div>
    <form id="submit-form" method="post" class="form-horizontal">
            <input type="hidden" name="submit_this_form" value="1">
            <input type="hidden" name="role_id" value="<?=$role_id?>">
            <div class="control-group">
                <label class="control-label" for="title_p"><?=__('Title')?></label>
                <div class="controls">
                    <input type="text" class="input-xxlarge" name="title" value="<?=$role['title']?>" id="title_p">
                </div>
            </div>

            <div class="control-group">
                <label class="control-label" for="name_p"><?=__('Name')?></label>
                <div class="controls">
                    <input type="text" class="input-xxlarge" name="name" value="<?=$role['name']?>" id="name_p">
                </div>
            </div>

            <div class="control-group">
                <label class="control-label" for="description_p"><?=__('Description')?></label>
                <div class="controls">
                    <input type="text" class="input-xxlarge" value="<?=$role['description']?>" name="description" id="description_p">
                </div>
            </div>

            <div class="control-group">
                
                <div class="span3 pull-left">
                    <div class="widget stacked widget-table">
                        <div class="widget-header">
                            <span class="icon-key"></span>
                            <h3><?=__('Administrative')?></h3>
                        </div>

                        <div class="widget-content">
                            <div class="checkbox-row">
                                <span class="niceCheck" <?if (in_array(71, $access)) {?>style="background-position: 0px -17px;"<?}?>>
                                    <input type="checkbox" name="access[]" <?if (in_array(71, $access)) {?>checked="checked"<?}?> value="71">
                                </span> <?=__('Login in admin panel')?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="span3 pull-left">
                    <div class="widget stacked widget-table">
                        <div class="widget-header">
                            <span class="icon-th"></span>
                            <h3><?=__('Pages')?></h3>
                        </div>

                        <div class="widget-content">
                            <div class="checkbox-row">
                                <span class="niceCheck" <?if (in_array(11, $access)) {?>style="background-position: 0px -17px;"<?}?>>
                                    <input type="checkbox" name="access[]" <?if (in_array(11, $access)) {?>checked="checked"<?}?> value="11">
                                </span> <?=__('View a list of pages')?>
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck" <?if (in_array(12, $access)) {?>style="background-position: 0px -17px;"<?}?>>
                                    <input type="checkbox" name="access[]" <?if (in_array(12, $access)) {?>checked="checked"<?}?> value="12">
                                </span> <?=__('Create pages')?>
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck" <?if (in_array(13, $access)) {?>style="background-position: 0px -17px;"<?}?>>
                                    <input type="checkbox" name="access[]" <?if (in_array(13, $access)) {?>checked="checked"<?}?> value="13">
                                </span> <?=__('Edit pages')?>
                            </div>
                            
                            <div class="checkbox-row">
                                <span class="niceCheck" <?if (in_array(14, $access)) {?>style="background-position: 0px -17px;"<?}?>>
                                    <input type="checkbox" name="access[]" <?if (in_array(14, $access)) {?>checked="checked"<?}?> value="14">
                                </span> <?=__('Remove pages')?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="span3 pull-left">
                    <div class="widget stacked widget-table">
                        <div class="widget-header">
                            <span class="icon-list-alt"></span>
                            <h3><?=__('Categories')?></h3>
                        </div>

                        <div class="widget-content">
                            <div class="checkbox-row">
                                <span class="niceCheck" <?if (in_array(21, $access)) {?>style="background-position: 0px -17px;"<?}?>>
                                    <input type="checkbox" name="access[]" <?if (in_array(21, $access)) {?>checked="checked"<?}?> value="21">
                                </span> <?=__('View categories list')?>
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck" <?if (in_array(22, $access)) {?>style="background-position: 0px -17px;"<?}?>>
                                    <input type="checkbox" name="access[]" <?if (in_array(22, $access)) {?>checked="checked"<?}?> value="22">
                                </span> <?=__('Create categories')?>
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck" <?if (in_array(23, $access)) {?>style="background-position: 0px -17px;"<?}?>>
                                    <input type="checkbox" name="access[]" <?if (in_array(23, $access)) {?>checked="checked"<?}?> value="23">
                                </span> <?=__('Edit categories')?>
                            </div>
                            
                            <div class="checkbox-row">
                                <span class="niceCheck" <?if (in_array(24, $access)) {?>style="background-position: 0px -17px;"<?}?>>
                                    <input type="checkbox" name="access[]" <?if (in_array(24, $access)) {?>checked="checked"<?}?> value="24">
                                </span> <?=__('Remove categories')?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="span3 pull-left">
                    <div class="widget stacked widget-table">
                        <div class="widget-header">
                            <span class="icon-link"></span>
                            <h3><?=__('Menu')?></h3>
                        </div>

                        <div class="widget-content">
                            <div class="checkbox-row">
                                <span class="niceCheck" <?if (in_array(31, $access)) {?>style="background-position: 0px -17px;"<?}?>>
                                    <input type="checkbox" name="access[]" <?if (in_array(31, $access)) {?>checked="checked"<?}?> value="31">
                                </span> <?=__('View lists menu')?>
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck" <?if (in_array(32, $access)) {?>style="background-position: 0px -17px;"<?}?>>
                                    <input type="checkbox" name="access[]" <?if (in_array(32, $access)) {?>checked="checked"<?}?> value="32">
                                </span> <?=__('Create menu')?>
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck" <?if (in_array(33, $access)) {?>style="background-position: 0px -17px;"<?}?>>
                                    <input type="checkbox" name="access[]" <?if (in_array(33, $access)) {?>checked="checked"<?}?> value="33">
                                </span> <?=__('Edit menu')?>
                            </div>
                            
                            <div class="checkbox-row">
                                <span class="niceCheck" <?if (in_array(34, $access)) {?>style="background-position: 0px -17px;"<?}?>>
                                    <input type="checkbox" name="access[]" <?if (in_array(34, $access)) {?>checked="checked"<?}?> value="34">
                                </span> <?=__('Remove menu')?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="span3 pull-left">
                    <div class="widget stacked widget-table">
                        <div class="widget-header">
                            <span class="icon-group"></span>
                            <h3><?=__('Groups')?></h3>
                        </div>

                        <div class="widget-content">
                            <div class="checkbox-row">
                                <span class="niceCheck" <?if (in_array(41, $access)) {?>style="background-position: 0px -17px;"<?}?>>
                                    <input type="checkbox" name="access[]" <?if (in_array(41, $access)) {?>checked="checked"<?}?> value="41">
                                </span> <?=__('View lists groups')?>
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck" <?if (in_array(42, $access)) {?>style="background-position: 0px -17px;"<?}?>>
                                    <input type="checkbox" name="access[]" <?if (in_array(42, $access)) {?>checked="checked"<?}?> value="42">
                                </span> <?=__('Create groups')?>
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck" <?if (in_array(43, $access)) {?>style="background-position: 0px -17px;"<?}?>>
                                    <input type="checkbox" name="access[]" <?if (in_array(43, $access)) {?>checked="checked"<?}?> value="43">
                                </span> <?=__('Edit groups')?>
                            </div>
                            
                            <div class="checkbox-row">
                                <span class="niceCheck" <?if (in_array(44, $access)) {?>style="background-position: 0px -17px;"<?}?>>
                                    <input type="checkbox" name="access[]" <?if (in_array(44, $access)) {?>checked="checked"<?}?> value="44">
                                </span> <?=__('Remove groups')?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="span3 pull-left">
                    <div class="widget stacked widget-table">
                        <div class="widget-header">
                            <span class="icon-user"></span>
                            <h3><?=__('Users')?></h3>
                        </div>

                        <div class="widget-content">
                            <div class="checkbox-row">
                                <span class="niceCheck" <?if (in_array(51, $access)) {?>style="background-position: 0px -17px;"<?}?>>
                                    <input type="checkbox" name="access[]" <?if (in_array(51, $access)) {?>checked="checked"<?}?> value="51">
                                </span> <?=__('View users lists')?>
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck" <?if (in_array(52, $access)) {?>style="background-position: 0px -17px;"<?}?>>
                                    <input type="checkbox" name="access[]" <?if (in_array(52, $access)) {?>checked="checked"<?}?> value="52">
                                </span> <?=__('Create users')?>
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck" <?if (in_array(53, $access)) {?>style="background-position: 0px -17px;"<?}?>>
                                    <input type="checkbox" name="access[]" <?if (in_array(53, $access)) {?>checked="checked"<?}?> value="53">
                                </span> <?=__('Edit users')?>
                            </div>
                            
                            <div class="checkbox-row">
                                <span class="niceCheck" <?if (in_array(54, $access)) {?>style="background-position: 0px -17px;"<?}?>>
                                    <input type="checkbox" name="access[]" <?if (in_array(54, $access)) {?>checked="checked"<?}?> value="54">
                                </span> <?=__('Remove users')?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="span3 pull-left">
                    <div class="widget stacked widget-table">
                        <div class="widget-header">
                            <span class="icon-user"></span>
                            <h3><?=__('For users')?></h3>
                        </div>

                        <div class="widget-content">
                            <div class="checkbox-row">
                                <span class="niceCheck" <?if (in_array(61, $access)) {?>style="background-position: 0px -17px;"<?}?>>
                                    <input type="checkbox" name="access[]" <?if (in_array(61, $access)) {?>checked="checked"<?}?> value="61">
                                </span> <?=__('View pages')?>
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck" <?if (in_array(62, $access)) {?>style="background-position: 0px -17px;"<?}?>>
                                    <input type="checkbox" name="access[]" <?if (in_array(62, $access)) {?>checked="checked"<?}?> value="62">
                                </span> <?=__('Comment')?>
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck" <?if (in_array(63, $access)) {?>style="background-position: 0px -17px;"<?}?>>
                                    <input type="checkbox" name="access[]" <?if (in_array(63, $access)) {?>checked="checked"<?}?> value="63">
                                </span> <?=__('Login')?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </form>
</div>
                </div>
            </div>
        </div>
    </div>
</div>