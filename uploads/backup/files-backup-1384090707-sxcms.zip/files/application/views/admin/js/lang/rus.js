Globalite.language("ru", {
	delete_status: "Статус удаления",
	sort_status: "Статус сортировки",
	remove_from_ftp: "Удалить с FTP",
	save_on_ftp: "Сохранить на FTP",
        remove_from_disk: "Удалить с диска",
        save_on_disk: "Сохранить на диск",
        link_on_category: "Ссылка на категорию",
        category: "Категория",
        link_on: "Ссылка на",
        template: "Шаблон",
        author: "Автор",
});