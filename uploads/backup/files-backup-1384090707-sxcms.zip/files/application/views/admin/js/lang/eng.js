Globalite.language("en", {
	delete_status: "Delete status",
	sort_status: "Sort status",
	remove_from_ftp: "Remove from FTP",
	save_on_ftp: "Save on FTP",
        remove_from_disk: "Remove from disk",
        save_on_disk: "Save on disk",
        link_on_category: "Link on category",
        category: "Category",
        link_on: "Link on",
        template: "Template",
        author: "Author",
});