<div class="main">
    <div class="container">
        <div class="row">
            <div class="span12">
                <div class="widget stacked">
<div class="widget-header">
    <i class="icon-file"></i>
    <h3><?=__('User edit')?></h3>
    <span class="action_buttons">
        <button class="btn pull-right formSubmit" data-form="#submit-form" data-after="exit" data-action="/admin/users/edit/<?=$user_id?>">
            <i class=" icon-save icon-large"></i> <?=__('Save and exit')?>
        </button>
        <button class="btn btn-success pull-right formSubmit" data-form="#submit-form" data-after="save" data-action="/admin/users/edit/<?=$user_id?>">
            <i class=" icon-save icon-large"></i> <?=__('Save')?>
        </button>
        <button data-href="/admin/users" data-container="#base-container" class="btn pull-right btn-info pjax_button">
            <i class="icon-arrow-left"></i> <?=__('Back')?>
        </button>
    </span>
</div>
                    
<div class="widget-content">
    <?if (isset($success)) {?>
        <div id="success_block">
            <p id="status_success">showMessage('<?=__('Success edit user')?>', '<?=__('Status user edit')?>', 'success')</p>
            <p id="url_success">/admin/users/edit/<?=$success?></p>
            <p id="url_success_exit">/admin/users/</p>
        </div>
    <?}?>
    <div id="errors_block">
        <?if (isset($errors)) {?>
        <div class="alert alert-error">
            <strong>Ошибка!</strong>
            <ul>
                <?foreach ($errors as $error) {?>
                    <li><?=__($error)?></li>
                <?}?>
            </ul>
        </div>
        <?}?>
    </div>
    <form id="submit-form" method="post" class="form-horizontal">
        <div class="tab-content">
            <input type="hidden" name="submit_this_form" value="1">
            <input type="hidden" name="user_id" value="<?=$user_id?>">
            <div class="tab-pane active" id="content">
                <div class="control-group">
                    <label class="control-label" for="username_p"><?=__('Username')?></label>
                    <div class="controls">
                        <input type="text" class="input-xxlarge" name="username" value="<?=$user['username']?>" id="username_p">
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label" for="email_p"><?=__('Email')?></label>
                    <div class="controls">
                        <input type="text" class="input-xxlarge" name="email" value="<?=$user['email']?>" id="email_p">
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label" for="new_password_p"><?=__('New password')?></label>
                    <div class="controls">
                        <input type="text" class="input-xxlarge" name="new_password" id="new_password_p">
                    </div>
                </div>
                
                <div class="control-group">
                    <label class="control-label" for="role_p"><?=__('Role')?></label>
                    <div class="controls">
                        <select class="input-xxlarge" name="role" id="role_p">
                            <?foreach ($roles as $role) {?>
                                <option value="<?=$role->id?>" <?if ($role->id == $user_role) {?>selected="selected"<?}?>><?=$role->title?></option>
                            <?}?>
                        </select>
                    </div>
                </div>
                
            </div>
        </div>	
    </form>
</div>
                </div>
            </div>
        </div>
    </div>
</div>