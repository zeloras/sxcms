<title><?=$base_title?> / <?=$title?></title>
<meta name="description" content="<?=$description?>" />		
<meta name="keywords" content="<?=$base_keywords?>, <?=$keywords?>" />
