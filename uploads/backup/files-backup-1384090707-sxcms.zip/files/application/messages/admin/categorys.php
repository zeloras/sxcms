<?php defined('SYSPATH') or die('No direct script access.');

return array(
    'url' => array(
        'check_url' => 'Link you entered already exists in this category',
    ),
);
?>
