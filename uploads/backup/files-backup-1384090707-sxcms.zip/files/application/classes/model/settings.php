<?php defined('SYSPATH') or die('No direct script access.');

class Model_Settings extends ORM
{
    protected $_table_name = 'settings';
    protected $_primary_key = 'general';
}
