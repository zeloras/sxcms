<?php defined('SYSPATH') or die('No direct script access.');

class Controller_Admin extends Controller_Admin_Auth {
        private $is_auth_user = false,
                $is_auth_role = false;
        private $access_code = array();
        public $language_system = "en",
               $texteditor_system = "elrte",
               $system_username = array();


        public function __construct(\Request $request, \Response $response) {
            parent::__construct($request, $response);
            $settings = ORM::factory('settings')->find()->as_array();
            $settings_global = unserialize($settings['general']);
            I18n::lang($settings_global['language']);
            $this->texteditor_system = $settings_global['text_editor'];
            $this->access_code = $this->get_access();
            $this->access_code = (is_array($this->access_code)) ? $this->access_code : array(0);
            $this->language_system = I18n::$lang;
            $this->system_username = Auth::instance()->get_user();
        }


        public function action_route()
	{
            $url_segment = $this->request->param('route');
            $auth = Auth::instance();
            $this->is_auth_user = $auth->logged_in();
            $this->is_auth_role = (in_array(71, $this->access_code)) ? true : false;
                        
            View::bind_global('is_auth_user', $this->is_auth_user);
            View::bind_global('is_auth_role', $this->is_auth_role);
            if (!$this->is_auth_user || !$this->is_auth_role)
            {
                   $this->admin_auth(); 
            }
            else
            {
                if (preg_match("/^auth/", $url_segment))
                {
                    $this->admin_auth();
                }
                else
                {
                    $this->routes($url_segment);
                }
                
                if (strlen($url_segment) < 1)
                    $this->display_tpl('index/home');
            }
            
            
	}
        
        private function menu_generate()
        {
            $data_menu['menus'] = array(
                    array('title' =>  __("Home"), 'class' => 'active', 'caret' => '', 'url' => '/admin/', 'icon' => 'icon-home'),
                    array('title' => __("Components"), 'class' => 'dropdown', 'caret' => 'caret', 'url' => 'javascript://', 'icon' => 'icon-th', 
                        'under' => array(
                                array('title' => __("Categories"), 'url' => '/admin/categorys'),
                                array('title' => __("Menu"), 'url' => '/admin/menus'),
                                array('title' => __("Users"), 'url' => '/admin/users'),
                                array('title' => __("Roles"), 'url' => '/admin/roles'),
                            ),
                        ),
                    array('title' => __("Pages"), 'class' => '', 'caret' => '', 'url' => '/admin/pages', 'icon' => 'icon-copy'),
                    array('title' => __("Settings"), 'class' => '', 'caret' => '',  'url' => '/admin/settings', 'icon' => 'icon-wrench'),
                );
            
            if ($this->is_auth_user)
            {
                return View::factory('/admin/admin_menu', $data_menu);
            }
            else
            {
                return false;
            }
        }
        
        private function access_error()
        {
            $this->display_tpl('system/access_denied');
        }
        
        private function routes($url_segment)
        {
            $access = $this->access_code;
            
            if (preg_match("/^pages/", $url_segment))
            {
                $url_exp = explode('/', $url_segment);
                
                if (!isset($url_exp[1]))
                    $url_exp[1] = 'page';
                if (!isset($url_exp[2]))
                    $url_exp[2] = 0;
                
                switch ($url_exp[1]) {
                    case 'add':
                        if (in_array(12, $access))
                            $this->page_add();
                        else
                            $this->access_error();
                    break;

                    case 'edit':
                        if (in_array(13, $access))
                            $this->page_edit($url_exp[2]);
                        else
                            $this->access_error();
                    break;

                    default:
                        if (in_array(11, $access))
                            $this->page_list($url_exp[1], $url_exp[2]);
                        else
                            $this->access_error();
                    break;
                }
            }
            
            if (preg_match("/^categorys/", $url_segment))
            {
                $url_exp = explode('/', $url_segment);
                
                if (!isset($url_exp[1]))
                    $url_exp[1] = 'page';
                if (!isset($url_exp[2]))
                    $url_exp[2] = 0;
                
                switch ($url_exp[1]) {
                    case 'add':
                        if (in_array(22, $access))
                            $this->category_add();
                        else
                            $this->access_error();
                    break;

                    case 'edit':
                        if (in_array(23, $access))
                            $this->category_edit($url_exp[2]);
                        else
                            $this->access_error();
                    break;

                    default:
                        if (in_array(21, $access))
                            $this->category_list($url_exp[1], $url_exp[2]);
                        else
                            $this->access_error();
                    break;
                }
            }
            
            
            if (preg_match("/^menus/", $url_segment))
            {
                $url_exp = explode('/', $url_segment);
                
                if (!isset($url_exp[1]))
                    $url_exp[1] = 'page';
                if (!isset($url_exp[2]))
                    $url_exp[2] = 0;
                
                switch ($url_exp[1]) {
                    case 'add':
                        if (in_array(32, $access))
                            $this->menus_add();
                        else
                            $this->access_error();
                    break;

                    case 'edit':
                        if (in_array(33, $access))
                            $this->menus_edit($url_exp[2]);
                        else
                            $this->access_error();
                    break;

                    default:
                        if (in_array(31, $access))
                            $this->menus_list($url_exp[1], $url_exp[2]);
                        else
                            $this->access_error();
                    break;
                }
            }
            
            
            if (preg_match("/^users/", $url_segment))
            {
                $url_exp = explode('/', $url_segment);
                
                if (!isset($url_exp[1]))
                    $url_exp[1] = 'users';
                if (!isset($url_exp[2]))
                    $url_exp[2] = 0;
                
                switch ($url_exp[1]) {
                    case 'add':
                        if (in_array(52, $access))
                            $this->users_add();
                        else
                            $this->access_error();
                    break;

                    case 'edit':
                        if (in_array(53, $access))
                            $this->users_edit($url_exp[2]);
                        else
                            $this->access_error();
                    break;

                    default:
                        if (in_array(51, $access))
                            $this->users_list($url_exp[1], $url_exp[2]);
                        else
                            $this->access_error();
                    break;
                }
            }
            
            
            if (preg_match("/^roles/", $url_segment))
            {
                $url_exp = explode('/', $url_segment);
                
                if (!isset($url_exp[1]))
                    $url_exp[1] = 'roles';
                if (!isset($url_exp[2]))
                    $url_exp[2] = 0;
                
                switch ($url_exp[1]) {
                    case 'add':
                        if (in_array(52, $access))
                            $this->roles_add();
                        else
                            $this->access_error();
                    break;

                    case 'edit':
                        if (in_array(53, $access))
                            $this->roles_edit($url_exp[2]);
                        else
                            $this->access_error();
                    break;

                    default:
                        if (in_array(51, $access))
                            $this->roles_list($url_exp[1], $url_exp[2]);
                        else
                            $this->access_error();
                    break;
                }
            }
            
            
            if (preg_match("/^menus_data/", $url_segment))
            {
                $url_exp = explode('/', $url_segment);
                
                if (!isset($url_exp[1]))
                    $url_exp[1] = 0;
                if (!isset($url_exp[2]))
                    $url_exp[2] = 'page';
                if (!isset($url_exp[3]))
                    $url_exp[3] = 0;
                
                switch ($url_exp[1]) {
                    case 'add':
                        if (in_array(32, $access))
                            $this->menus_data_add($url_exp[2]);
                        else
                            $this->access_error();
                    break;

                    case 'edit':
                        if (in_array(32, $access))
                            $this->menus_data_edit($url_exp[2], $url_exp[3]);
                        else
                            $this->access_error();
                    break;

                    default:
                        if (in_array(32, $access))
                            $this->menus_data_list($url_exp[1], $url_exp[2], $url_exp[3]);
                        else
                            $this->access_error();
                    break;
                }
            }
            
            
            
            if (preg_match("/^settings/", $url_segment))
            {
                $url_exp = explode('/', $url_segment);
                
                if (!isset($url_exp[1]))
                    $url_exp[1] = 'settings';
                if (!isset($url_exp[2]))
                    $url_exp[2] = 0;
                
                switch ($url_exp[1]) {
                    default:
                        if (in_array(51, $access))
                            $this->settings($url_exp[1], $url_exp[2]);
                        else
                            $this->access_error();
                    break;
                }
            }
            
            
            
            if (preg_match("/^syscom/", $url_segment))
            {
                $url_exp = explode('/', $url_segment);
                
                switch ($url_exp[1]) {
                    case 'ajax_delete':
                        $this->ajax_delete($url_exp[2], $this->access_code);
                    break;
                
                    case 'ajax_changeactive':
                        $this->ajaxChangeActive();        
                    break;
                
                    case 'getCategorys_opt':
                        $this->ajax_getCategorys_opt();
                    break;
                
                    case 'getPages_opt':
                        $this->ajax_getPages_opt($url_exp[2]);
                    break;
                
                    case 'getSystem_opt':
                        $this->ajax_getSystem_opt();
                    break;
                
                    case 'getTranslitUrl':
                        $this->ajax_translit_url();
                    break;
                    
                    case 'ajax_save_position':
                        $this->ajax_save_position($url_exp[2]);
                    break;
                
                    case 'ajax_cloud_check':
                        $this->ajaxCloudCheckConnect($url_exp[2]);
                    break;
                
                    case 'ajax_ftp_check':
                        $this->ajaxFTPCheckConnect($url_exp[2]);
                    break;
                
                    case 'ajax_ftp_save':
                        $this->ajaxFTPSaveFile($url_exp[2]);
                    break;
                
                    case 'ajax_ftp_delete':
                        $this->ajaxFTPDeleteFile($url_exp[2]);
                    break;
                
                    case 'ajax_cloud_save':
                        $this->ajaxCloudSaveFile($url_exp[2]);
                    break;
                
                    case 'ajax_cloud_delete':
                        $this->ajaxCloudDeleteFile($url_exp[2]);
                    break;
                }
            }

        }


        public function display_tpl($template, $data = array(), $metategs = array())
        {
            $access_code = $this->access_code;
            $language = $this->language_system;
            $text_editor = $this->texteditor_system;
            $useradmin = $this->system_username->username;
            //$this->template->metatags = View::factory('admin/meta_tags', $metategs);
            
            $this->template->menu_admin_html = $this->menu_generate();
            
            $this->template->language = $language;
            $this->template->text_editor = $text_editor;
            $this->template->username = $useradmin;
            
            $this->template->content_admin = View::factory('admin/'.$template, $data)
                    ->bind('access_code', $access_code)
                    ->bind('language', $language);
        }
        
        public function ajax_tpl($data = array())
        {
            $access_code = $this->access_code;
            $language = $this->language_system;
            $text_editor = $this->texteditor_system;
            $useradmin = $this->system_username->username;
            
            $this->template->menu_admin_html = false;
            
            $this->template->language = $language;
            $this->template->text_editor = $text_editor;
            $this->template->username = $useradmin;
            
            $this->template->content_admin = View::factory('admin/system/blank', $data)
                ->bind('access_code', $access_code)
                ->bind('language', $language);
        }

} // End Welcome
