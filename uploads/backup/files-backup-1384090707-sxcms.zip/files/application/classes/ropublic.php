<?php defined('SYSPATH') or die('No direct script access.');

class Ropublic extends Base {
    public $template = 'public/default/index';
    
    public function __construct(\Request $request, \Response $response) {
        parent::__construct($request, $response);
        
        $config_file = 'config.xml';
        $get_config = file_get_contents($config_file);
        $get_xml_config = new SimpleXMLElement($get_config);
        $base_template = $get_xml_config->base->template;
        $this->template = 'public/'.$base_template.'/index';
    }
}