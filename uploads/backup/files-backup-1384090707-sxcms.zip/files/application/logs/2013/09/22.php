<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2013-09-22 00:23:56 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ MODPATH/orm/classes/kohana/orm.php [ 356 ]
2013-09-22 00:23:56 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ MODPATH/orm/classes/kohana/orm.php [ 356 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(356): Kohana_Core::error_handler(2, 'Invalid argumen...', '/var/www/zelora...', 356, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1198): Kohana_ORM->_validation()
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/users.php(19): Kohana_ORM->save()
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/users.php(20): Model_Admin_Users->admin_users_add()
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(146): Controller_Admin_Users->users_add()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('users/add')
#8 [internal function]: Controller_Admin->action_route()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-09-22 00:24:15 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ MODPATH/orm/classes/kohana/orm.php [ 356 ]
2013-09-22 00:24:15 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ MODPATH/orm/classes/kohana/orm.php [ 356 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(356): Kohana_Core::error_handler(2, 'Invalid argumen...', '/var/www/zelora...', 356, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1198): Kohana_ORM->_validation()
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/users.php(19): Kohana_ORM->save()
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/users.php(20): Model_Admin_Users->admin_users_add()
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(146): Controller_Admin_Users->users_add()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('users/add')
#8 [internal function]: Controller_Admin->action_route()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-09-22 00:35:22 --- ERROR: Database_Exception [ 1062 ]: Duplicate entry 'zeloras@gmail.com' for key 2 [ INSERT INTO `sx_users` (`username`, `email`, `password`) VALUES ('12313', 'zeloras@gmail.com', '40ae7077764901b1c6b4ed8742326120bf6856203cb3bbb13c9fca9b53544509') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-09-22 00:35:22 --- STRACE: Database_Exception [ 1062 ]: Duplicate entry 'zeloras@gmail.com' for key 2 [ INSERT INTO `sx_users` (`username`, `email`, `password`) VALUES ('12313', 'zeloras@gmail.com', '40ae7077764901b1c6b4ed8742326120bf6856203cb3bbb13c9fca9b53544509') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `sx...', false, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1252): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/users.php(19): Kohana_ORM->save()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/users.php(20): Model_Admin_Users->admin_users_add()
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(146): Controller_Admin_Users->users_add()
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('users/add')
#7 [internal function]: Controller_Admin->action_route()
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#12 {main}
2013-09-22 00:35:29 --- ERROR: Database_Exception [ 1062 ]: Duplicate entry 'zeloras@gmail.com' for key 2 [ INSERT INTO `sx_users` (`username`, `email`, `password`) VALUES ('12313', 'zeloras@gmail.com', 'd43486a6a14d14de64430bd962c5673a85df9c0ef7726c30e10ae4e95bbb737e') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-09-22 00:35:29 --- STRACE: Database_Exception [ 1062 ]: Duplicate entry 'zeloras@gmail.com' for key 2 [ INSERT INTO `sx_users` (`username`, `email`, `password`) VALUES ('12313', 'zeloras@gmail.com', 'd43486a6a14d14de64430bd962c5673a85df9c0ef7726c30e10ae4e95bbb737e') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `sx...', false, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1252): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/users.php(19): Kohana_ORM->save()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/users.php(20): Model_Admin_Users->admin_users_add()
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(146): Controller_Admin_Users->users_add()
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('users/add')
#7 [internal function]: Controller_Admin->action_route()
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#12 {main}
2013-09-22 00:49:14 --- ERROR: ErrorException [ 8 ]: Undefined index: user ~ APPPATH/classes/controller/admin/special.php [ 63 ]
2013-09-22 00:49:14 --- STRACE: ErrorException [ 8 ]: Undefined index: user ~ APPPATH/classes/controller/admin/special.php [ 63 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/special.php(63): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 63, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(192): Controller_Admin_Special->ajax_delete('user')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('syscom/ajax_del...')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-09-22 00:50:17 --- ERROR: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
2013-09-22 00:50:17 --- STRACE: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(80): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 80, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-09-22 00:50:17 --- ERROR: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
2013-09-22 00:50:17 --- STRACE: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(80): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 80, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-09-22 00:59:32 --- ERROR: ErrorException [ 8 ]: Undefined variable: user ~ APPPATH/views/admin/roles/index.php [ 43 ]
2013-09-22 00:59:32 --- STRACE: ErrorException [ 8 ]: Undefined variable: user ~ APPPATH/views/admin/roles/index.php [ 43 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/roles/index.php(43): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 43, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-09-22 23:02:54 --- ERROR: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, string given ~ APPPATH/views/admin/roles/edit.php [ 76 ]
2013-09-22 23:02:54 --- STRACE: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, string given ~ APPPATH/views/admin/roles/edit.php [ 76 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'in_array() expe...', '/var/www/zelora...', 76, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/roles/edit.php(76): in_array(11, '63')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#5 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#9 [internal function]: Kohana_Controller_Template->after()
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#14 {main}
2013-09-22 23:05:04 --- ERROR: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, string given ~ APPPATH/views/admin/roles/edit.php [ 76 ]
2013-09-22 23:05:04 --- STRACE: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, string given ~ APPPATH/views/admin/roles/edit.php [ 76 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'in_array() expe...', '/var/www/zelora...', 76, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/roles/edit.php(76): in_array(11, '63')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#5 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#9 [internal function]: Kohana_Controller_Template->after()
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#14 {main}
2013-09-22 23:06:17 --- ERROR: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, string given ~ APPPATH/views/admin/roles/edit.php [ 76 ]
2013-09-22 23:06:17 --- STRACE: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, string given ~ APPPATH/views/admin/roles/edit.php [ 76 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'in_array() expe...', '/var/www/zelora...', 76, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/roles/edit.php(76): in_array(11, '63')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#5 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#9 [internal function]: Kohana_Controller_Template->after()
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#14 {main}
2013-09-22 23:07:55 --- ERROR: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, string given ~ APPPATH/views/admin/roles/edit.php [ 76 ]
2013-09-22 23:07:55 --- STRACE: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, string given ~ APPPATH/views/admin/roles/edit.php [ 76 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'in_array() expe...', '/var/www/zelora...', 76, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/roles/edit.php(76): in_array(11, '63')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#5 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#9 [internal function]: Kohana_Controller_Template->after()
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#14 {main}
2013-09-22 23:08:21 --- ERROR: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, boolean given ~ APPPATH/views/admin/roles/edit.php [ 76 ]
2013-09-22 23:08:21 --- STRACE: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, boolean given ~ APPPATH/views/admin/roles/edit.php [ 76 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'in_array() expe...', '/var/www/zelora...', 76, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/roles/edit.php(76): in_array(11, false)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#5 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#9 [internal function]: Kohana_Controller_Template->after()
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#14 {main}
2013-09-22 23:08:23 --- ERROR: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, boolean given ~ APPPATH/views/admin/roles/edit.php [ 76 ]
2013-09-22 23:08:23 --- STRACE: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, boolean given ~ APPPATH/views/admin/roles/edit.php [ 76 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'in_array() expe...', '/var/www/zelora...', 76, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/roles/edit.php(76): in_array(11, false)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#5 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#9 [internal function]: Kohana_Controller_Template->after()
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#14 {main}
2013-09-22 23:14:34 --- ERROR: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, boolean given ~ APPPATH/views/admin/roles/edit.php [ 76 ]
2013-09-22 23:14:34 --- STRACE: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, boolean given ~ APPPATH/views/admin/roles/edit.php [ 76 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'in_array() expe...', '/var/www/zelora...', 76, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/roles/edit.php(76): in_array(11, false)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#5 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#9 [internal function]: Kohana_Controller_Template->after()
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#14 {main}
2013-09-22 23:14:47 --- ERROR: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, boolean given ~ APPPATH/views/admin/roles/edit.php [ 76 ]
2013-09-22 23:14:47 --- STRACE: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, boolean given ~ APPPATH/views/admin/roles/edit.php [ 76 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'in_array() expe...', '/var/www/zelora...', 76, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/roles/edit.php(76): in_array(11, false)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#5 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#9 [internal function]: Kohana_Controller_Template->after()
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#14 {main}
2013-09-22 23:14:49 --- ERROR: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, boolean given ~ APPPATH/views/admin/roles/edit.php [ 76 ]
2013-09-22 23:14:49 --- STRACE: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, boolean given ~ APPPATH/views/admin/roles/edit.php [ 76 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'in_array() expe...', '/var/www/zelora...', 76, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/roles/edit.php(76): in_array(11, false)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#5 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#9 [internal function]: Kohana_Controller_Template->after()
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#14 {main}