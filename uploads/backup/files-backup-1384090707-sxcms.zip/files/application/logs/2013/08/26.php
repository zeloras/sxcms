<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2013-08-26 02:00:49 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 02:00:49 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 02:17:20 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 02:17:20 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 03:42:21 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 03:42:21 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 05:53:38 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 05:53:38 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 05:53:39 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 05:53:39 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 07:55:12 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 07:55:12 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 08:06:28 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 08:06:28 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 08:51:22 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 08:51:22 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 10:00:55 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 10:00:55 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 10:29:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 10:29:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 11:52:15 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 11:52:15 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 12:12:38 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 12:12:38 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 12:51:20 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 12:51:20 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 12:54:42 --- ERROR: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 82 ]
2013-08-26 12:54:42 --- STRACE: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 82 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(82): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 82, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(128): Helper_Public::breadcrumbs('category_list')
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 13:43:57 --- ERROR: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 82 ]
2013-08-26 13:43:57 --- STRACE: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 82 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(82): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 82, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(128): Helper_Public::breadcrumbs('category_list')
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 14:01:47 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 14:01:47 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 16:50:00 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 16:50:00 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 17:12:30 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 17:12:30 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 17:36:17 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 17:36:17 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 19:12:37 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 19:12:37 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 19:41:02 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 19:41:02 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 19:59:29 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 19:59:29 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 19:59:37 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 19:59:37 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:06:43 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 20:06:43 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:06:52 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 20:06:52 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:06:55 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 20:06:55 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:10:11 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:10:11 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:10:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:10:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:12:44 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:12:44 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:12:57 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:12:57 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:13:19 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:13:19 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:15:04 --- ERROR: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 34 ]
2013-08-26 20:15:04 --- STRACE: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 34 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(34): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 34, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(110): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:15:05 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:15:05 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:15:12 --- ERROR: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 36 ]
2013-08-26 20:15:12 --- STRACE: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(110): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:15:12 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:15:12 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:15:13 --- ERROR: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 36 ]
2013-08-26 20:15:13 --- STRACE: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(110): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:15:14 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:15:14 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:15:14 --- ERROR: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 36 ]
2013-08-26 20:15:14 --- STRACE: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(110): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:15:14 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:15:14 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:15:28 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/classes/helper/public.php [ 36 ]
2013-08-26 20:15:28 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/classes/helper/public.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(36): Kohana_Core::error_handler(2, 'Invalid argumen...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(110): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:15:29 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:15:29 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:15:29 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/classes/helper/public.php [ 36 ]
2013-08-26 20:15:29 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/classes/helper/public.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(36): Kohana_Core::error_handler(2, 'Invalid argumen...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(110): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:15:30 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:15:30 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:15:30 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/classes/helper/public.php [ 36 ]
2013-08-26 20:15:30 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/classes/helper/public.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(36): Kohana_Core::error_handler(2, 'Invalid argumen...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(110): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:15:30 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:15:30 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:15:56 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:15:56 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:16:21 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:16:21 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:16:51 --- ERROR: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/public/default/system/breadcrumbs.php [ 5 ]
2013-08-26 20:16:51 --- STRACE: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/public/default/system/breadcrumbs.php [ 5 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/system/breadcrumbs.php(5): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 5, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/page.php(1): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#8 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(52): Kohana_View->__toString()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#12 [internal function]: Kohana_Controller_Template->after()
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#14 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#15 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#16 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#17 {main}
2013-08-26 20:16:51 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:16:51 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:17:32 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:17:32 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:21:44 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:21:44 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:23:52 --- ERROR: ErrorException [ 8 ]: Undefined variable: url ~ APPPATH/classes/helper/public.php [ 37 ]
2013-08-26 20:23:52 --- STRACE: ErrorException [ 8 ]: Undefined variable: url ~ APPPATH/classes/helper/public.php [ 37 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(37): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 37, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(110): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:23:52 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:23:52 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:23:53 --- ERROR: ErrorException [ 8 ]: Undefined variable: url ~ APPPATH/classes/helper/public.php [ 37 ]
2013-08-26 20:23:53 --- STRACE: ErrorException [ 8 ]: Undefined variable: url ~ APPPATH/classes/helper/public.php [ 37 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(37): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 37, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(110): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:23:53 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:23:53 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:23:53 --- ERROR: ErrorException [ 8 ]: Undefined variable: url ~ APPPATH/classes/helper/public.php [ 37 ]
2013-08-26 20:23:53 --- STRACE: ErrorException [ 8 ]: Undefined variable: url ~ APPPATH/classes/helper/public.php [ 37 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(37): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 37, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(110): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:23:53 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:23:53 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:23:53 --- ERROR: ErrorException [ 8 ]: Undefined variable: url ~ APPPATH/classes/helper/public.php [ 37 ]
2013-08-26 20:23:53 --- STRACE: ErrorException [ 8 ]: Undefined variable: url ~ APPPATH/classes/helper/public.php [ 37 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(37): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 37, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(110): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:23:54 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:23:54 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:23:54 --- ERROR: ErrorException [ 8 ]: Undefined variable: url ~ APPPATH/classes/helper/public.php [ 37 ]
2013-08-26 20:23:54 --- STRACE: ErrorException [ 8 ]: Undefined variable: url ~ APPPATH/classes/helper/public.php [ 37 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(37): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 37, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(110): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:23:54 --- ERROR: ErrorException [ 8 ]: Undefined variable: url ~ APPPATH/classes/helper/public.php [ 37 ]
2013-08-26 20:23:54 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:23:54 --- STRACE: ErrorException [ 8 ]: Undefined variable: url ~ APPPATH/classes/helper/public.php [ 37 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(37): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 37, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(110): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:23:54 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:23:54 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:23:54 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:23:54 --- ERROR: ErrorException [ 8 ]: Undefined variable: url ~ APPPATH/classes/helper/public.php [ 37 ]
2013-08-26 20:23:54 --- STRACE: ErrorException [ 8 ]: Undefined variable: url ~ APPPATH/classes/helper/public.php [ 37 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(37): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 37, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(110): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:23:55 --- ERROR: ErrorException [ 8 ]: Undefined variable: url ~ APPPATH/classes/helper/public.php [ 37 ]
2013-08-26 20:23:55 --- STRACE: ErrorException [ 8 ]: Undefined variable: url ~ APPPATH/classes/helper/public.php [ 37 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(37): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 37, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(110): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:23:55 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:23:55 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:23:55 --- ERROR: ErrorException [ 8 ]: Undefined variable: url ~ APPPATH/classes/helper/public.php [ 37 ]
2013-08-26 20:23:55 --- STRACE: ErrorException [ 8 ]: Undefined variable: url ~ APPPATH/classes/helper/public.php [ 37 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(37): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 37, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(110): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:23:55 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:23:55 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:24:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:24:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:24:43 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:24:43 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:26:29 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:26:29 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:26:32 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:26:32 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:26:33 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:26:33 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:26:57 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:26:57 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:27:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:27:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:27:09 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:27:09 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:27:10 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:27:10 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:27:11 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:27:11 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:27:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:27:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:28:05 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:28:05 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:28:09 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:28:09 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:28:16 --- ERROR: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 81 ]
2013-08-26 20:28:16 --- STRACE: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 81 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(81): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 81, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(127): Helper_Public::breadcrumbs('category_list')
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:28:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:28:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:28:20 --- ERROR: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 81 ]
2013-08-26 20:28:20 --- STRACE: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 81 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(81): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 81, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(127): Helper_Public::breadcrumbs('category_list')
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:28:20 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:28:20 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:28:21 --- ERROR: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 81 ]
2013-08-26 20:28:21 --- STRACE: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 81 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(81): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 81, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(127): Helper_Public::breadcrumbs('category_list')
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:28:21 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:28:21 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:28:21 --- ERROR: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 81 ]
2013-08-26 20:28:21 --- STRACE: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 81 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(81): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 81, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(127): Helper_Public::breadcrumbs('category_list')
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:28:22 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:28:22 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:29:11 --- ERROR: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 81 ]
2013-08-26 20:29:11 --- STRACE: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 81 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(81): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 81, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(127): Helper_Public::breadcrumbs('category_list')
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:29:11 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:29:11 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:29:12 --- ERROR: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 81 ]
2013-08-26 20:29:12 --- STRACE: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 81 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(81): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 81, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(127): Helper_Public::breadcrumbs('category_list')
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:29:12 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:29:12 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:29:12 --- ERROR: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 81 ]
2013-08-26 20:29:12 --- STRACE: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 81 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(81): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 81, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(127): Helper_Public::breadcrumbs('category_list')
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:29:13 --- ERROR: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 81 ]
2013-08-26 20:29:13 --- STRACE: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 81 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(81): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 81, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(127): Helper_Public::breadcrumbs('category_list')
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:29:13 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:29:13 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:29:13 --- ERROR: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 81 ]
2013-08-26 20:29:13 --- STRACE: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 81 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(81): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 81, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(127): Helper_Public::breadcrumbs('category_list')
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:29:13 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:29:13 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:29:13 --- ERROR: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 81 ]
2013-08-26 20:29:13 --- STRACE: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 81 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(81): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 81, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(127): Helper_Public::breadcrumbs('category_list')
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:29:14 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:29:14 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:29:14 --- ERROR: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 81 ]
2013-08-26 20:29:14 --- STRACE: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 81 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(81): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 81, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(127): Helper_Public::breadcrumbs('category_list')
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:29:14 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:29:14 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:29:14 --- ERROR: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 81 ]
2013-08-26 20:29:14 --- STRACE: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 81 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(81): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 81, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(127): Helper_Public::breadcrumbs('category_list')
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:29:14 --- ERROR: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 81 ]
2013-08-26 20:29:14 --- STRACE: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 81 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(81): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 81, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(127): Helper_Public::breadcrumbs('category_list')
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:29:14 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:29:14 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:29:14 --- ERROR: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 81 ]
2013-08-26 20:29:14 --- STRACE: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 81 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(81): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 81, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(127): Helper_Public::breadcrumbs('category_list')
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-26 20:29:15 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:29:15 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:29:31 --- ERROR: ErrorException [ 8 ]: Undefined variable: bread ~ APPPATH/views/public/default/system/breadcrumbs.php [ 4 ]
2013-08-26 20:29:31 --- STRACE: ErrorException [ 8 ]: Undefined variable: bread ~ APPPATH/views/public/default/system/breadcrumbs.php [ 4 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/system/breadcrumbs.php(4): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 4, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/category.php(1): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#8 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(52): Kohana_View->__toString()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#12 [internal function]: Kohana_Controller_Template->after()
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#14 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#15 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#16 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#17 {main}
2013-08-26 20:29:32 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:29:32 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:29:45 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:29:45 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:29:46 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:29:46 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:29:49 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:29:49 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:30:13 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:30:13 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:30:19 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:30:19 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:30:42 --- ERROR: ErrorException [ 8 ]: Undefined variable: bread ~ APPPATH/views/public/default/system/breadcrumbs.php [ 4 ]
2013-08-26 20:30:42 --- STRACE: ErrorException [ 8 ]: Undefined variable: bread ~ APPPATH/views/public/default/system/breadcrumbs.php [ 4 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/system/breadcrumbs.php(4): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 4, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/category.php(1): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#8 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(52): Kohana_View->__toString()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#12 [internal function]: Kohana_Controller_Template->after()
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#14 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#15 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#16 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#17 {main}
2013-08-26 20:30:42 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:30:42 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:31:40 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:31:40 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:45:32 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:45:32 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:45:35 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:45:35 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:45:38 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-26 20:45:38 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:47:01 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 20:47:01 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:47:07 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 20:47:07 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:47:07 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 20:47:07 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:47:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 20:47:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:47:11 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 20:47:11 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:47:13 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-26 20:47:13 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:47:49 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 145 ]
2013-08-26 20:47:49 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 145 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(145): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 145, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:47:51 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 145 ]
2013-08-26 20:47:51 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 145 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(145): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 145, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:47:52 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 145 ]
2013-08-26 20:47:52 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 145 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(145): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 145, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:47:52 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 145 ]
2013-08-26 20:47:52 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 145 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(145): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 145, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:47:56 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 145 ]
2013-08-26 20:47:56 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 145 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(145): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 145, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:47:56 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 145 ]
2013-08-26 20:47:56 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 145 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(145): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 145, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:50:58 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:50:58 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:50:58 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:50:58 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:50:59 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:50:59 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:50:59 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:50:59 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:51:00 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:51:00 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:51:00 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:51:00 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:51:00 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:51:00 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:51:00 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:51:00 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:51:00 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:51:00 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:51:01 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:51:01 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:51:14 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 146 ]
2013-08-26 20:51:14 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 146 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:51:14 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 146 ]
2013-08-26 20:51:14 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 146 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:51:15 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 146 ]
2013-08-26 20:51:15 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 146 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:51:15 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 146 ]
2013-08-26 20:51:15 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 146 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:51:15 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 146 ]
2013-08-26 20:51:15 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 146 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:51:15 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 146 ]
2013-08-26 20:51:15 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 146 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:51:16 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 146 ]
2013-08-26 20:51:16 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 146 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:51:16 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 146 ]
2013-08-26 20:51:16 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 146 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:51:16 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 146 ]
2013-08-26 20:51:16 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 146 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:51:17 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 146 ]
2013-08-26 20:51:17 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 146 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:51:18 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 146 ]
2013-08-26 20:51:18 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 146 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:51:18 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 146 ]
2013-08-26 20:51:18 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 146 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:52:02 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 148 ]
2013-08-26 20:52:02 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 148 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:52:03 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 148 ]
2013-08-26 20:52:03 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 148 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:52:04 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 148 ]
2013-08-26 20:52:04 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 148 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:52:04 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 148 ]
2013-08-26 20:52:04 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 148 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:52:04 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 148 ]
2013-08-26 20:52:04 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 148 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:52:11 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 148 ]
2013-08-26 20:52:11 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 148 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:52:12 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 148 ]
2013-08-26 20:52:12 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 148 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:52:13 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 148 ]
2013-08-26 20:52:13 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 148 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:52:20 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:52:20 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:52:21 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:52:21 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:52:22 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:52:22 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:52:25 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:52:25 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:52:27 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:52:27 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:52:28 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:52:28 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:52:29 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:52:29 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:52:29 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:52:29 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:52:29 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:52:29 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:52:45 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:52:45 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:53:50 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 148 ]
2013-08-26 20:53:50 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 148 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:02 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 148 ]
2013-08-26 20:54:02 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 148 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:03 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 148 ]
2013-08-26 20:54:03 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 148 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:03 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 148 ]
2013-08-26 20:54:03 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 148 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:03 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 148 ]
2013-08-26 20:54:03 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 148 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:12 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:12 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:13 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:13 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:14 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:14 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:14 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:14 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:15 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:15 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:16 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:16 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:16 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:16 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:16 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:16 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:16 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:16 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:16 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:16 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:16 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:16 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:16 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:16 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:16 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:16 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:16 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:16 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:17 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:17 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:17 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:17 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:17 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:17 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:17 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:17 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:17 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:17 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:17 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:17 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:17 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:17 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:17 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:17 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:17 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:17 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:17 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:17 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:17 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:17 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:17 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:17 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:17 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:17 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:17 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:17 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:17 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:17 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:18 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:18 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:18 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:18 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:18 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:18 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:18 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:18 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:18 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:18 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:18 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:18 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:18 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
2013-08-26 20:54:18 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public.php [ 147 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:30 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public/page.php [ 9 ]
2013-08-26 20:54:30 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public/page.php [ 9 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:31 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public/page.php [ 9 ]
2013-08-26 20:54:31 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public/page.php [ 9 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:32 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public/page.php [ 9 ]
2013-08-26 20:54:32 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public/page.php [ 9 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:32 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public/page.php [ 9 ]
2013-08-26 20:54:32 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public/page.php [ 9 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:32 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public/page.php [ 9 ]
2013-08-26 20:54:32 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public/page.php [ 9 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:54:32 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public/page.php [ 9 ]
2013-08-26 20:54:32 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Pages as array ~ APPPATH/classes/controller/public/page.php [ 9 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-26 20:55:04 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 140 ]
2013-08-26 20:55:04 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 140 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(140): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 140, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:57:07 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 140 ]
2013-08-26 20:57:07 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 140 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(140): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 140, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:57:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 140 ]
2013-08-26 20:57:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 140 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(140): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 140, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:57:11 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 140 ]
2013-08-26 20:57:11 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 140 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(140): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 140, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:57:11 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 140 ]
2013-08-26 20:57:11 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 140 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(140): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 140, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:57:34 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:57:34 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:57:34 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:57:34 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:58:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:58:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:58:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:58:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:58:17 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:58:17 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:58:17 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:58:17 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:58:17 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:58:17 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:58:18 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:58:18 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:58:18 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:58:18 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:58:18 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:58:18 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:58:23 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:58:23 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:58:24 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:58:24 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:58:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:58:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:58:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:58:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:58:27 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:58:27 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:58:28 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:58:28 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:58:30 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:58:30 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:58:33 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:58:33 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:58:34 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:58:34 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-26 20:58:35 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-26 20:58:35 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}