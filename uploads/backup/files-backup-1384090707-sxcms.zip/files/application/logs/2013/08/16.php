<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2013-08-16 01:33:34 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 01:33:34 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 01:33:34 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 01:33:34 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 01:37:13 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 01:37:13 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 01:49:24 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 01:49:24 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 01:49:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 01:49:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 01:49:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 01:49:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 02:23:49 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 02:23:49 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 03:13:49 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 03:13:49 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 03:13:49 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 03:13:49 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 03:14:18 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 03:14:18 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 03:14:19 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 03:14:19 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 04:31:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 04:31:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 04:31:34 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 04:31:34 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 04:32:43 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 04:32:43 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 04:32:43 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 04:32:43 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 04:32:44 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 04:32:44 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 04:41:30 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 04:41:30 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 04:41:36 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 04:41:36 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 04:41:37 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 04:41:37 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 04:41:37 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 04:41:37 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 04:41:41 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 04:41:41 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 04:41:59 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 04:41:59 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 04:42:34 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 04:42:34 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 04:42:35 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 04:42:35 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 04:43:01 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 04:43:01 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 05:02:17 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 05:02:17 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 05:02:18 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 05:02:18 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 05:02:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 05:02:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 05:02:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 05:02:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 05:02:51 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 05:02:51 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 05:02:53 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 05:02:53 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 05:05:28 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 05:05:28 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 05:05:28 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 05:05:28 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 05:05:33 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 05:05:33 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 05:05:34 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 05:05:34 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 05:08:13 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 05:08:13 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 05:08:14 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 05:08:14 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 05:11:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 05:11:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 05:11:27 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 05:11:27 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 05:11:58 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 05:11:58 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 05:11:59 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 05:11:59 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 05:15:02 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 05:15:02 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 05:15:03 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 05:15:03 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 05:18:51 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 05:18:51 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 05:18:51 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 05:18:51 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 05:22:10 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 05:22:10 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 05:22:11 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 05:22:11 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 05:23:38 --- ERROR: Kohana_Exception [ 0 ]: The category_id property does not exist in the Model_Pages class ~ MODPATH/orm/classes/kohana/orm.php [ 621 ]
2013-08-16 05:23:38 --- STRACE: Kohana_Exception [ 0 ]: The category_id property does not exist in the Model_Pages class ~ MODPATH/orm/classes/kohana/orm.php [ 621 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/pages/index.php(52): Kohana_ORM->__get('category_id')
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-08-16 05:23:40 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 05:23:40 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 05:23:49 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 05:23:49 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 05:23:51 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 05:23:51 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 05:58:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 05:58:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 06:28:47 --- ERROR: Kohana_Exception [ 0 ]: The name property does not exist in the Model_Categorys class ~ MODPATH/orm/classes/kohana/orm.php [ 621 ]
2013-08-16 06:28:47 --- STRACE: Kohana_Exception [ 0 ]: The name property does not exist in the Model_Categorys class ~ MODPATH/orm/classes/kohana/orm.php [ 621 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/common.php(44): Kohana_ORM->__get('name')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/pages.php(10): Helper_Common::get_category_info('18')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(80): Controller_Admin_Pages->page_list('page', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('pages')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-16 06:28:51 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 06:28:51 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 06:29:40 --- ERROR: Kohana_Exception [ 0 ]: The name property does not exist in the Model_Categorys class ~ MODPATH/orm/classes/kohana/orm.php [ 621 ]
2013-08-16 06:29:40 --- STRACE: Kohana_Exception [ 0 ]: The name property does not exist in the Model_Categorys class ~ MODPATH/orm/classes/kohana/orm.php [ 621 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/common.php(44): Kohana_ORM->__get('name')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/pages.php(10): Helper_Common::get_category_info('18')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(80): Controller_Admin_Pages->page_list('page', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('pages')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-16 06:29:41 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 06:29:41 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 06:29:44 --- ERROR: Kohana_Exception [ 0 ]: The name property does not exist in the Model_Categorys class ~ MODPATH/orm/classes/kohana/orm.php [ 621 ]
2013-08-16 06:29:44 --- STRACE: Kohana_Exception [ 0 ]: The name property does not exist in the Model_Categorys class ~ MODPATH/orm/classes/kohana/orm.php [ 621 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/common.php(44): Kohana_ORM->__get('name')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/pages.php(10): Helper_Common::get_category_info('18')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(80): Controller_Admin_Pages->page_list('page', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('pages')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-16 06:29:45 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 06:29:45 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 06:29:45 --- ERROR: Kohana_Exception [ 0 ]: The name property does not exist in the Model_Categorys class ~ MODPATH/orm/classes/kohana/orm.php [ 621 ]
2013-08-16 06:29:45 --- STRACE: Kohana_Exception [ 0 ]: The name property does not exist in the Model_Categorys class ~ MODPATH/orm/classes/kohana/orm.php [ 621 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/common.php(44): Kohana_ORM->__get('name')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/pages.php(10): Helper_Common::get_category_info('18')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(80): Controller_Admin_Pages->page_list('page', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('pages')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-16 06:29:46 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 06:29:46 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 06:29:57 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 06:29:57 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 06:29:58 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 06:29:58 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 06:33:09 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 06:33:09 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 06:33:10 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 06:33:10 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 06:34:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 06:34:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 06:34:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 06:34:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 06:35:01 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 06:35:01 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 06:35:02 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 06:35:02 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 06:36:24 --- ERROR: ErrorException [ 2 ]: Illegal string offset 'title' ~ APPPATH/views/admin/pages/index.php [ 52 ]
2013-08-16 06:36:24 --- STRACE: ErrorException [ 2 ]: Illegal string offset 'title' ~ APPPATH/views/admin/pages/index.php [ 52 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/pages/index.php(52): Kohana_Core::error_handler(2, 'Illegal string ...', '/var/www/zelora...', 52, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-08-16 06:36:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 06:36:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 06:37:27 --- ERROR: ErrorException [ 2 ]: Illegal string offset 'title' ~ APPPATH/views/admin/pages/index.php [ 52 ]
2013-08-16 06:37:27 --- STRACE: ErrorException [ 2 ]: Illegal string offset 'title' ~ APPPATH/views/admin/pages/index.php [ 52 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/pages/index.php(52): Kohana_Core::error_handler(2, 'Illegal string ...', '/var/www/zelora...', 52, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-08-16 06:37:28 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 06:37:28 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 06:42:47 --- ERROR: ErrorException [ 2 ]: Illegal string offset 'title' ~ APPPATH/views/admin/pages/index.php [ 52 ]
2013-08-16 06:42:47 --- STRACE: ErrorException [ 2 ]: Illegal string offset 'title' ~ APPPATH/views/admin/pages/index.php [ 52 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/pages/index.php(52): Kohana_Core::error_handler(2, 'Illegal string ...', '/var/www/zelora...', 52, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-08-16 06:42:48 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 06:42:48 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 06:42:50 --- ERROR: ErrorException [ 2 ]: Illegal string offset 'title' ~ APPPATH/views/admin/pages/index.php [ 52 ]
2013-08-16 06:42:50 --- STRACE: ErrorException [ 2 ]: Illegal string offset 'title' ~ APPPATH/views/admin/pages/index.php [ 52 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/pages/index.php(52): Kohana_Core::error_handler(2, 'Illegal string ...', '/var/www/zelora...', 52, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-08-16 06:42:51 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 06:42:51 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 06:44:05 --- ERROR: ErrorException [ 2 ]: Illegal string offset 'title' ~ APPPATH/views/admin/pages/index.php [ 52 ]
2013-08-16 06:44:05 --- STRACE: ErrorException [ 2 ]: Illegal string offset 'title' ~ APPPATH/views/admin/pages/index.php [ 52 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/pages/index.php(52): Kohana_Core::error_handler(2, 'Illegal string ...', '/var/www/zelora...', 52, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-08-16 06:44:07 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 06:44:07 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 06:49:00 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 06:49:00 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 06:49:01 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 06:49:01 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 06:56:53 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 06:56:53 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 06:56:54 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 06:56:54 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 06:57:06 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 06:57:06 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 06:57:07 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 06:57:07 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 06:57:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 06:57:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 06:57:09 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 06:57:09 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 06:58:29 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 06:58:29 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 06:58:31 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 06:58:31 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 06:59:35 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 06:59:35 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 06:59:36 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 06:59:36 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:00:01 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:00:01 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:00:02 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:00:02 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:00:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:00:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:00:27 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:00:27 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:04:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:04:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:04:17 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:04:17 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:05:39 --- ERROR: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
2013-08-16 07:05:39 --- STRACE: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(80): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 80, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-16 07:05:40 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:05:40 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:06:14 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:06:14 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:06:54 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:06:54 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:06:55 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:06:55 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:08:31 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:08:31 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:08:33 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:08:33 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:24:07 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:24:07 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:24:07 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:24:07 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:24:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:24:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:24:09 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:24:09 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:25:43 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:25:43 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:25:43 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:25:43 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:25:43 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:25:43 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:25:44 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:25:44 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:25:47 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:25:47 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:25:47 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:25:47 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:25:47 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:25:47 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:25:48 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:25:48 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:25:49 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:25:49 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:25:50 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:25:50 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:28:04 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:28:04 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:28:04 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:28:04 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:29:32 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:29:32 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 07:29:33 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 07:29:33 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 08:51:02 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 08:51:02 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 08:51:03 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 08:51:03 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 08:51:46 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 08:51:46 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 08:51:47 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 08:51:47 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 08:51:47 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 08:51:47 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 08:51:48 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 08:51:48 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 08:56:36 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 08:56:36 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 08:56:37 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 08:56:37 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 08:57:10 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 08:57:10 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 08:57:11 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 08:57:11 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 08:57:34 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 08:57:34 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 08:57:35 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 08:57:35 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 08:57:53 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 08:57:53 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 08:57:57 --- ERROR: ErrorException [ 1 ]: Call to undefined method Helper_Public::get_category_path() ~ APPPATH/views/public/default/category.php [ 8 ]
2013-08-16 08:57:57 --- STRACE: ErrorException [ 1 ]: Call to undefined method Helper_Public::get_category_path() ~ APPPATH/views/public/default/category.php [ 8 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-16 08:57:58 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 08:57:58 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 09:00:42 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 09:00:42 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 09:00:46 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 09:00:46 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 09:00:48 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 09:00:48 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 09:01:32 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 09:01:32 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 09:01:33 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 09:01:33 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 09:23:04 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 09:23:04 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 09:33:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 09:33:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 09:42:34 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 09:42:34 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:08:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:08:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:08:17 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:08:17 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:08:19 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Admin::menus_list() ~ APPPATH/classes/controller/admin.php [ 129 ]
2013-08-16 10:08:19 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Admin::menus_list() ~ APPPATH/classes/controller/admin.php [ 129 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-16 10:08:19 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:08:19 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:08:19 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Admin::menus_list() ~ APPPATH/classes/controller/admin.php [ 129 ]
2013-08-16 10:08:19 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Admin::menus_list() ~ APPPATH/classes/controller/admin.php [ 129 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-16 10:08:19 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:08:19 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:08:20 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:08:20 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:08:36 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:08:36 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:08:36 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:08:36 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:15:31 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:15:31 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:15:32 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:15:32 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:16:52 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:16:52 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:16:53 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:16:53 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:19:04 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:19:04 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:19:05 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:19:05 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:21:05 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:21:05 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:21:06 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:21:06 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:21:36 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:21:36 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:21:37 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:21:37 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:23:30 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:23:30 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:23:31 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:23:31 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:35:00 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:35:00 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:35:01 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:35:01 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:35:02 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Admin::menus_add() ~ APPPATH/classes/controller/admin.php [ 121 ]
2013-08-16 10:35:02 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Admin::menus_add() ~ APPPATH/classes/controller/admin.php [ 121 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-16 10:35:02 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:35:02 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:35:02 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Admin::menus_add() ~ APPPATH/classes/controller/admin.php [ 121 ]
2013-08-16 10:35:02 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Admin::menus_add() ~ APPPATH/classes/controller/admin.php [ 121 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-16 10:35:02 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:35:02 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:35:02 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:35:02 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:40:37 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:40:37 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:40:38 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:40:38 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:41:37 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:41:37 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:41:38 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:41:38 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:57:05 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:57:05 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 10:57:06 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 10:57:06 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 11:06:47 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 11:06:47 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 11:06:48 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 11:06:48 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 11:07:04 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 11:07:04 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 11:07:05 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 11:07:05 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 11:51:37 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 11:51:37 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 11:51:37 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 11:51:37 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 11:51:46 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 11:51:46 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 11:54:54 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 11:54:54 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 11:54:55 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 11:54:55 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 11:54:59 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 11:54:59 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 11:55:00 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 11:55:00 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 11:55:05 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 11:55:05 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 11:55:06 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 11:55:06 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 11:55:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 11:55:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 11:55:09 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 11:55:09 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 11:55:18 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 11:55:18 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 11:55:19 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 11:55:19 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 11:57:14 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 11:57:14 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 11:57:15 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 11:57:15 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 11:57:22 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 11:57:22 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 11:57:23 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 11:57:23 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 12:11:14 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 12:11:14 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 12:11:15 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 12:11:15 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 12:11:42 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 12:11:42 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 12:11:43 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 12:11:43 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 12:11:50 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 12:11:50 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 12:11:50 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 12:11:50 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 12:11:52 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 12:11:52 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 12:11:52 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 12:11:52 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 12:11:52 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 12:11:52 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 12:11:53 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 12:11:53 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 12:47:49 --- ERROR: ErrorException [ 1 ]: Class 'Model_Menus_data' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
2013-08-16 12:47:49 --- STRACE: ErrorException [ 1 ]: Class 'Model_Menus_data' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-16 12:47:49 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 12:47:49 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 12:51:43 --- ERROR: ErrorException [ 1 ]: Class 'Model_Menus_data' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
2013-08-16 12:51:43 --- STRACE: ErrorException [ 1 ]: Class 'Model_Menus_data' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-16 12:51:44 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 12:51:44 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 12:51:44 --- ERROR: ErrorException [ 1 ]: Class 'Model_Menus_data' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
2013-08-16 12:51:44 --- STRACE: ErrorException [ 1 ]: Class 'Model_Menus_data' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-16 12:51:45 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 12:51:45 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 12:51:45 --- ERROR: ErrorException [ 1 ]: Class 'Model_Menus_data' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
2013-08-16 12:51:45 --- STRACE: ErrorException [ 1 ]: Class 'Model_Menus_data' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-16 12:51:46 --- ERROR: ErrorException [ 1 ]: Class 'Model_Menus_data' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
2013-08-16 12:51:46 --- STRACE: ErrorException [ 1 ]: Class 'Model_Menus_data' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-16 12:51:46 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 12:51:46 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 12:51:46 --- ERROR: ErrorException [ 1 ]: Class 'Model_Menus_data' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
2013-08-16 12:51:46 --- STRACE: ErrorException [ 1 ]: Class 'Model_Menus_data' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-16 12:51:46 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 12:51:46 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 12:54:26 --- ERROR: Database_Exception [ 1146 ]: Table 'zeloras_def.sx_menus_data' doesn't exist [ SHOW FULL COLUMNS FROM `sx_menus_data` ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-16 12:54:26 --- STRACE: Database_Exception [ 1146 ]: Table 'zeloras_def.sx_menus_data' doesn't exist [ SHOW FULL COLUMNS FROM `sx_menus_data` ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/mysql.php(358): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1538): Kohana_Database_MySQL->list_columns('menus_data')
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(392): Kohana_ORM->list_columns()
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(337): Kohana_ORM->reload_columns()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(246): Kohana_ORM->_initialize()
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(37): Kohana_ORM->__construct(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/menus.php(14): Kohana_ORM::factory('links')
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(156): Controller_Admin_Menus->menus_data_list('2', 'page', 0)
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('menus_data/2')
#9 [internal function]: Controller_Admin->action_route()
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#14 {main}
2013-08-16 12:54:27 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 12:54:27 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 13:06:16 --- ERROR: Database_Exception [ 1146 ]: Table 'zeloras_def.sx_menus_data' doesn't exist [ SHOW FULL COLUMNS FROM `sx_menus_data` ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-16 13:06:16 --- STRACE: Database_Exception [ 1146 ]: Table 'zeloras_def.sx_menus_data' doesn't exist [ SHOW FULL COLUMNS FROM `sx_menus_data` ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/mysql.php(358): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1538): Kohana_Database_MySQL->list_columns('menus_data')
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(392): Kohana_ORM->list_columns()
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(337): Kohana_ORM->reload_columns()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(246): Kohana_ORM->_initialize()
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(37): Kohana_ORM->__construct(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/menus.php(14): Kohana_ORM::factory('links')
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(156): Controller_Admin_Menus->menus_data_list('2', 'page', 0)
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('menus_data/2')
#9 [internal function]: Controller_Admin->action_route()
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#14 {main}
2013-08-16 13:06:17 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 13:06:17 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 13:06:24 --- ERROR: Database_Exception [ 1146 ]: Table 'zeloras_def.sx_menus_data' doesn't exist [ SHOW FULL COLUMNS FROM `sx_menus_data` ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-16 13:06:24 --- STRACE: Database_Exception [ 1146 ]: Table 'zeloras_def.sx_menus_data' doesn't exist [ SHOW FULL COLUMNS FROM `sx_menus_data` ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/mysql.php(358): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1538): Kohana_Database_MySQL->list_columns('menus_data')
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(392): Kohana_ORM->list_columns()
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(337): Kohana_ORM->reload_columns()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(246): Kohana_ORM->_initialize()
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(37): Kohana_ORM->__construct(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/menus.php(14): Kohana_ORM::factory('links')
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(156): Controller_Admin_Menus->menus_data_list('2', 'page', 0)
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('menus_data/2')
#9 [internal function]: Controller_Admin->action_route()
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#14 {main}
2013-08-16 13:06:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 13:06:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 13:06:26 --- ERROR: Database_Exception [ 1146 ]: Table 'zeloras_def.sx_menus_data' doesn't exist [ SHOW FULL COLUMNS FROM `sx_menus_data` ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-16 13:06:26 --- STRACE: Database_Exception [ 1146 ]: Table 'zeloras_def.sx_menus_data' doesn't exist [ SHOW FULL COLUMNS FROM `sx_menus_data` ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/mysql.php(358): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1538): Kohana_Database_MySQL->list_columns('menus_data')
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(392): Kohana_ORM->list_columns()
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(337): Kohana_ORM->reload_columns()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(246): Kohana_ORM->_initialize()
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(37): Kohana_ORM->__construct(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/menus.php(14): Kohana_ORM::factory('links')
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(156): Controller_Admin_Menus->menus_data_list('2', 'page', 0)
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('menus_data/2')
#9 [internal function]: Controller_Admin->action_route()
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#14 {main}
2013-08-16 13:06:27 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 13:06:27 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 13:07:00 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 13:07:00 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 13:07:01 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 13:07:01 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 13:15:58 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 13:15:58 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 13:42:10 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 13:42:10 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 14:09:38 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 14:09:38 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 14:18:15 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 14:18:15 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 14:18:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 14:18:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 14:46:52 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 14:46:52 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 14:46:53 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 14:46:53 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 14:54:20 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 14:54:20 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:00:20 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:00:20 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:00:21 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:00:21 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:15:50 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:15:50 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:15:51 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:15:51 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:15:54 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:15:54 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:15:55 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:15:55 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:15:55 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:15:55 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:15:56 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:15:56 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:15:59 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:15:59 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:15:59 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:15:59 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:24:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:24:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:32:21 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:32:21 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:47:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:47:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:47:17 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:47:17 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:47:19 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:47:19 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:47:20 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:47:20 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:47:21 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:47:21 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:47:21 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:47:21 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:47:22 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:47:22 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:47:22 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:47:22 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:47:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:47:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:47:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:47:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:50:27 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:50:27 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:50:28 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:50:28 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:50:29 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:50:29 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:51:04 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:51:04 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:51:05 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:51:05 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:51:06 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:51:06 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:51:06 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:51:06 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:51:06 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:51:06 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:51:07 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:51:07 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:51:09 --- ERROR: Kohana_Exception [ 0 ]: The visible property does not exist in the Model_Links class ~ MODPATH/orm/classes/kohana/orm.php [ 621 ]
2013-08-16 15:51:09 --- STRACE: Kohana_Exception [ 0 ]: The visible property does not exist in the Model_Links class ~ MODPATH/orm/classes/kohana/orm.php [ 621 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/menus/data/index.php(47): Kohana_ORM->__get('visible')
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-08-16 15:51:10 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:51:10 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:51:27 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:51:27 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:51:28 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:51:28 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 15:51:47 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 15:51:47 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 16:15:05 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 16:15:05 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 16:15:05 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 16:15:05 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 16:15:06 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 16:15:06 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 16:15:07 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 16:15:07 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 16:15:12 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 16:15:12 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 16:15:12 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 16:15:12 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 16:15:13 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 16:15:13 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 16:15:14 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 16:15:14 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 16:16:45 --- ERROR: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Arr::merge() must be of the type array, integer given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/core.php on line 931 and defined ~ SYSPATH/classes/kohana/arr.php [ 419 ]
2013-08-16 16:16:45 --- STRACE: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Arr::merge() must be of the type array, integer given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/core.php on line 931 and defined ~ SYSPATH/classes/kohana/arr.php [ 419 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/arr.php(419): Kohana_Core::error_handler(4096, 'Argument 2 pass...', '/var/www/zelora...', 419, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/core.php(931): Kohana_Arr::merge(Array, 1)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(564): Kohana_Core::message('admin/menus', 'name.check_name')
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm/validation/exception.php(172): Kohana_Validation->errors('admin/menus', true)
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm/validation/exception.php(133): Kohana_ORM_Validation_Exception->generate_errors('menus', Array, 'admin', true)
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/menus.php(27): Kohana_ORM_Validation_Exception->errors('admin')
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/menus.php(49): Model_Admin_Menus->admin_menus_add()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(121): Controller_Admin_Menus->menus_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('menus/add')
#9 [internal function]: Controller_Admin->action_route()
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#14 {main}
2013-08-16 16:16:47 --- ERROR: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Arr::merge() must be of the type array, integer given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/core.php on line 931 and defined ~ SYSPATH/classes/kohana/arr.php [ 419 ]
2013-08-16 16:16:47 --- STRACE: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Arr::merge() must be of the type array, integer given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/core.php on line 931 and defined ~ SYSPATH/classes/kohana/arr.php [ 419 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/arr.php(419): Kohana_Core::error_handler(4096, 'Argument 2 pass...', '/var/www/zelora...', 419, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/core.php(931): Kohana_Arr::merge(Array, 1)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(564): Kohana_Core::message('admin/menus', 'name.check_name')
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm/validation/exception.php(172): Kohana_Validation->errors('admin/menus', true)
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm/validation/exception.php(133): Kohana_ORM_Validation_Exception->generate_errors('menus', Array, 'admin', true)
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/menus.php(27): Kohana_ORM_Validation_Exception->errors('admin')
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/menus.php(49): Model_Admin_Menus->admin_menus_add()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(121): Controller_Admin_Menus->menus_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('menus/add')
#9 [internal function]: Controller_Admin->action_route()
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#14 {main}
2013-08-16 16:18:03 --- ERROR: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Arr::merge() must be of the type array, integer given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/core.php on line 931 and defined ~ SYSPATH/classes/kohana/arr.php [ 419 ]
2013-08-16 16:18:03 --- STRACE: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Arr::merge() must be of the type array, integer given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/core.php on line 931 and defined ~ SYSPATH/classes/kohana/arr.php [ 419 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/arr.php(419): Kohana_Core::error_handler(4096, 'Argument 2 pass...', '/var/www/zelora...', 419, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/core.php(931): Kohana_Arr::merge(Array, 1)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(564): Kohana_Core::message('admin/menus', 'name.check_name')
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm/validation/exception.php(172): Kohana_Validation->errors('admin/menus', true)
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm/validation/exception.php(133): Kohana_ORM_Validation_Exception->generate_errors('menus', Array, 'admin', true)
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/menus.php(27): Kohana_ORM_Validation_Exception->errors('admin')
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/menus.php(49): Model_Admin_Menus->admin_menus_add()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(121): Controller_Admin_Menus->menus_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('menus/add')
#9 [internal function]: Controller_Admin->action_route()
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#14 {main}
2013-08-16 16:18:04 --- ERROR: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Arr::merge() must be of the type array, integer given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/core.php on line 931 and defined ~ SYSPATH/classes/kohana/arr.php [ 419 ]
2013-08-16 16:18:04 --- STRACE: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Arr::merge() must be of the type array, integer given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/core.php on line 931 and defined ~ SYSPATH/classes/kohana/arr.php [ 419 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/arr.php(419): Kohana_Core::error_handler(4096, 'Argument 2 pass...', '/var/www/zelora...', 419, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/core.php(931): Kohana_Arr::merge(Array, 1)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(564): Kohana_Core::message('admin/menus', 'name.check_name')
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm/validation/exception.php(172): Kohana_Validation->errors('admin/menus', true)
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm/validation/exception.php(133): Kohana_ORM_Validation_Exception->generate_errors('menus', Array, 'admin', true)
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/menus.php(27): Kohana_ORM_Validation_Exception->errors('admin')
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/menus.php(49): Model_Admin_Menus->admin_menus_add()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(121): Controller_Admin_Menus->menus_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('menus/add')
#9 [internal function]: Controller_Admin->action_route()
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#14 {main}
2013-08-16 16:18:09 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 16:18:09 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 16:18:10 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 16:18:10 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 16:18:21 --- ERROR: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Arr::merge() must be of the type array, integer given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/core.php on line 931 and defined ~ SYSPATH/classes/kohana/arr.php [ 419 ]
2013-08-16 16:18:21 --- STRACE: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Arr::merge() must be of the type array, integer given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/core.php on line 931 and defined ~ SYSPATH/classes/kohana/arr.php [ 419 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/arr.php(419): Kohana_Core::error_handler(4096, 'Argument 2 pass...', '/var/www/zelora...', 419, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/core.php(931): Kohana_Arr::merge(Array, 1)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(564): Kohana_Core::message('admin/menus', 'name.check_name')
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm/validation/exception.php(172): Kohana_Validation->errors('admin/menus', true)
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm/validation/exception.php(133): Kohana_ORM_Validation_Exception->generate_errors('menus', Array, 'admin', true)
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/menus.php(27): Kohana_ORM_Validation_Exception->errors('admin')
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/menus.php(49): Model_Admin_Menus->admin_menus_add()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(121): Controller_Admin_Menus->menus_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('menus/add')
#9 [internal function]: Controller_Admin->action_route()
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#14 {main}
2013-08-16 16:27:56 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 16:27:56 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 16:27:57 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 16:27:57 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 16:28:01 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 16:28:01 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 16:28:01 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 16:28:01 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 16:28:01 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 16:28:01 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 16:28:02 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 16:28:02 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 16:34:11 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 16:34:11 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 16:34:12 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 16:34:12 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 16:55:00 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 16:55:00 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:14:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:14:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:14:17 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:14:17 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:22:05 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:22:05 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:22:05 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:22:05 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:22:06 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:22:06 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:22:07 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:22:07 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:22:17 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:22:17 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:22:18 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:22:18 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:22:21 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:22:21 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:22:22 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:22:22 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:33:46 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:33:46 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:33:46 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:33:46 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:33:47 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:33:47 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:33:48 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:33:48 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:33:57 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:33:57 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:33:58 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:33:58 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:33:59 --- ERROR: ErrorException [ 8 ]: Undefined variable: menu_id ~ APPPATH/views/admin/menus/data/create.php [ 10 ]
2013-08-16 17:33:59 --- STRACE: ErrorException [ 8 ]: Undefined variable: menu_id ~ APPPATH/views/admin/menus/data/create.php [ 10 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/menus/data/create.php(10): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 10, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-08-16 17:33:59 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:33:59 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:34:00 --- ERROR: ErrorException [ 8 ]: Undefined variable: menu_id ~ APPPATH/views/admin/menus/data/create.php [ 10 ]
2013-08-16 17:34:00 --- STRACE: ErrorException [ 8 ]: Undefined variable: menu_id ~ APPPATH/views/admin/menus/data/create.php [ 10 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/menus/data/create.php(10): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 10, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-08-16 17:34:00 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:34:00 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:34:01 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:34:01 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:34:23 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:34:23 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:34:24 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:34:24 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:37:18 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:37:18 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:37:19 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:37:19 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:37:23 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:37:23 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:37:41 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:37:41 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:37:42 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:37:42 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:46:58 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:46:58 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:46:59 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:46:59 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:48:35 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:48:35 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:48:36 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:48:36 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:48:49 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:48:49 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:48:50 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:48:50 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:49:13 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:49:13 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 17:49:15 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 17:49:15 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:11:47 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:11:47 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:11:49 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:11:49 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:12:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:12:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:12:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:12:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:14:32 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:14:32 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:14:33 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:14:33 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:14:48 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:14:48 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:14:49 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:14:49 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:15:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:15:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:15:28 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:15:28 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:15:40 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:15:40 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:15:41 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:15:41 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:16:04 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:16:04 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:16:05 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:16:05 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:16:22 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:16:22 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:16:23 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:16:23 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:17:24 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:17:24 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:17:27 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:17:27 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:20:53 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:20:53 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:20:54 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:20:54 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:21:11 --- ERROR: Kohana_Exception [ 0 ]: The parent property does not exist in the Model_Links class ~ MODPATH/orm/classes/kohana/orm.php [ 692 ]
2013-08-16 18:21:11 --- STRACE: Kohana_Exception [ 0 ]: The parent property does not exist in the Model_Links class ~ MODPATH/orm/classes/kohana/orm.php [ 692 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(643): Kohana_ORM->set('parent', '0')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/menus.php(87): Kohana_ORM->__set('parent', '0')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/menus.php(28): Model_Admin_Menus->admin_link_add()
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(148): Controller_Admin_Menus->menus_data_add('1')
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('menus_data/add/...')
#5 [internal function]: Controller_Admin->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-16 18:25:49 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:25:49 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:25:50 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:25:50 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:27:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:27:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:27:17 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:27:17 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:27:29 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:27:29 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:27:29 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:27:29 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:27:30 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:27:30 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:27:31 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:27:31 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:27:37 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:27:37 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:27:38 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:27:38 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:27:38 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:27:38 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:27:39 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:27:39 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:27:47 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:27:47 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:27:47 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:27:47 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:27:47 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:27:47 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:27:48 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:27:48 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:27:55 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:27:55 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:27:56 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:27:56 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:27:58 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:27:58 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:27:58 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:27:58 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:27:59 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:27:59 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:28:00 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:28:00 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:28:14 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:28:14 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:28:15 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:28:15 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:28:21 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:28:21 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:28:21 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:28:21 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:28:21 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:28:22 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:28:23 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:28:23 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:28:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:28:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:28:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:28:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:29:22 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:29:22 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:29:23 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:29:23 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:29:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:29:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:29:27 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:29:27 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:29:29 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:29:29 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:29:29 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:29:29 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:29:29 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:29:29 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:29:30 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:29:30 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:29:37 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:29:37 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 18:29:37 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 18:29:37 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 19:07:11 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 19:07:11 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 19:07:30 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 19:07:30 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 19:36:55 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 19:36:55 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 20:20:30 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 20:20:30 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 21:03:54 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 21:03:54 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 21:24:02 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 21:24:02 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 21:24:03 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 21:24:03 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 21:31:36 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 21:31:36 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 21:31:36 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 21:31:36 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 21:47:18 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 21:47:18 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-16 23:42:02 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-16 23:42:02 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}