<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2013-08-07 00:24:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 00:24:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 00:24:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 00:24:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 00:24:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 00:24:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 00:24:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 00:24:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:58:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:58:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:58:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:58:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:58:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:58:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:58:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: params ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:58:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: params ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:58:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:58:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:58:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:58:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:58:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: products ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:58:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: products ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:58:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:58:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:59:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: products ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:59:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: products ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:59:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:59:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:59:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: products ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:59:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: products ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:59:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:59:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:59:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: products ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:59:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: products ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:59:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:59:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:59:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: products ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:59:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: products ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:59:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:59:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:59:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: products ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:59:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: products ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:59:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:59:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:59:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: products ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:59:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: products ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:59:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: products ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:59:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:59:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: products ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:59:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:59:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:59:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:59:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: products ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:59:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: products ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:59:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:59:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:59:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: products ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:59:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: products ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:59:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:59:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:59:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: products ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:59:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: products ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:59:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:59:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:59:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: products ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:59:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: products ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:59:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:59:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:59:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: products ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:59:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: products ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:59:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:59:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:59:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: products ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:59:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: products ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:59:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:59:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 01:59:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 01:59:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 02:00:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 02:00:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 02:00:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 02:00:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 02:00:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 02:00:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 02:00:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 02:00:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 02:00:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: param/1 ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 02:00:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: param/1 ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 02:00:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-07 02:00:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-07 03:07:40 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:40 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:40 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:40 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:41 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:41 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:41 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:41 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:41 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:41 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:42 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:42 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:42 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:42 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:42 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:42 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:42 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:42 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:42 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:42 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:42 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:42 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:43 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:43 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:43 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:43 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:43 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:43 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:44 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:44 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:44 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:44 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:44 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:44 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:44 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:44 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:44 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:44 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:44 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:44 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:44 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:44 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:44 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:44 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:44 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:44 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:44 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:44 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:44 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:44 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:44 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:44 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:44 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:44 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:44 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:44 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:44 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:44 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:44 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:44 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:44 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:44 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:44 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:44 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:44 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:44 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:44 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:44 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:44 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:44 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:45 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:45 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:45 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:45 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:45 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:45 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:45 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:45 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:45 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:45 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:45 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:45 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:45 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:45 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:45 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:45 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:45 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:45 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:45 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:45 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:45 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:45 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:45 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:45 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:45 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:45 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:45 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:45 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:45 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:45 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:45 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:45 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:45 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:45 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:45 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:45 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:45 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:45 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:45 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:45 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:45 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:45 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:45 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:45 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:45 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:45 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:45 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:45 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:45 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:45 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:46 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:46 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:46 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:46 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:46 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:46 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:46 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:46 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:46 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:46 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:46 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:46 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:46 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:46 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:46 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:46 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:46 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:46 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:46 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:46 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:46 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:46 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:46 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:46 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:46 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:46 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:46 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:46 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:46 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:46 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:46 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:46 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:46 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:46 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:46 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:46 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:46 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:46 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:46 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:46 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:46 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:46 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:46 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:46 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:46 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:46 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:46 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:46 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:46 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:46 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:46 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:46 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:46 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:46 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:46 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:46 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:47 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:47 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:47 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:47 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:47 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:47 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:47 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:47 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:47 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:47 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:47 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:47 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:47 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:47 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:47 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:47 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:47 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:47 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:47 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:47 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:47 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:47 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:47 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:47 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:47 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:47 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:47 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:47 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:47 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:47 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:47 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:47 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:47 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:47 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:47 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:47 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:47 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:47 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:47 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:47 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:47 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:47 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:47 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:47 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:47 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:47 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:47 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:47 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:47 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:47 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:47 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:47 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:47 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:47 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:48 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:48 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:48 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:48 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:48 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:48 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:48 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:48 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:48 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:48 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:48 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:48 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:48 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:48 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:48 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:48 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:49 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:49 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:49 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:49 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:49 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:49 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:49 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:49 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:49 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:49 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:49 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:49 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:49 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:49 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:49 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:49 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:49 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:49 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:49 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:49 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:49 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:49 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:49 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:49 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:49 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:49 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:49 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:49 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:49 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:49 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:49 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:49 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:49 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:49 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:49 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:49 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:49 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:49 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:49 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:49 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:49 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:49 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:49 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:49 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:49 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:49 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:49 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:49 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:49 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:49 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:50 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:50 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:50 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:50 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:50 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:50 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:50 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:50 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:50 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:50 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:50 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:50 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:50 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:50 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:50 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:50 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:50 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:50 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:50 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:50 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:50 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:50 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:50 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:50 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:50 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:50 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:50 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:50 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:50 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:50 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:50 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:50 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:50 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:50 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:50 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:50 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:50 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:50 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:50 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:50 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:50 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:50 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:50 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:50 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:50 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:50 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:50 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:50 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:50 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:50 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:50 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:50 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:50 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:50 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:50 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:50 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:51 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:51 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:51 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:51 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:51 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:51 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:51 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:51 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:51 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:51 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:51 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:51 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:51 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:51 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:51 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:51 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:51 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:51 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:51 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:51 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:51 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:51 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:51 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:51 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:51 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:51 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:51 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:51 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:51 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:51 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:51 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:51 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:51 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:51 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:51 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:51 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:51 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:51 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:51 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:51 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:51 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:51 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:51 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:51 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:51 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:51 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:51 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:51 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:51 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:51 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:51 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:51 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:51 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:51 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:51 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:51 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:52 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:52 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:52 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:52 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:52 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:52 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:52 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:52 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:52 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:52 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:52 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:52 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:52 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:52 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:52 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:52 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:52 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:52 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:52 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:52 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:52 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:52 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:52 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:52 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:52 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:52 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:52 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:52 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:52 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:52 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:52 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:52 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:52 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:52 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:52 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:52 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:52 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:52 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:52 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:52 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:52 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:52 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:52 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:52 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:52 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:52 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:52 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:52 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:54 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:54 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:54 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:54 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:54 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:54 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:54 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:54 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:54 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:54 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:54 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:54 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:07:54 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
2013-08-07 03:07:54 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Public::$uri ~ APPPATH/classes/controller/public.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:12:06 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 03:12:06 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 03:12:06 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 03:12:06 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 03:12:07 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 03:12:07 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 03:12:17 --- ERROR: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/controller/public.php [ 17 ]
2013-08-07 03:12:17 --- STRACE: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/controller/public.php [ 17 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(17): Kohana_Core::error_handler(8, 'Undefined offse...', '/var/www/zelora...', 17, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 03:12:17 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 03:12:17 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 03:12:41 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 03:12:41 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 03:12:42 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 03:12:42 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 03:22:14 --- ERROR: Database_Exception [ 1146 ]: Table 'zeloras_def.sxcategorys' doesn't exist [ SHOW FULL COLUMNS FROM `sxcategorys` ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-07 03:22:14 --- STRACE: Database_Exception [ 1146 ]: Table 'zeloras_def.sxcategorys' doesn't exist [ SHOW FULL COLUMNS FROM `sxcategorys` ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/mysql.php(358): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1538): Kohana_Database_MySQL->list_columns('categorys')
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(392): Kohana_ORM->list_columns()
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(337): Kohana_ORM->reload_columns()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(246): Kohana_ORM->_initialize()
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(37): Kohana_ORM->__construct(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(21): Kohana_ORM::factory('categorys')
#7 [internal function]: Controller_Public->action_route()
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#12 {main}
2013-08-07 03:22:14 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 03:22:14 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 03:23:56 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 03:23:56 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 03:26:59 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 03:26:59 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 03:38:53 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 03:38:53 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 03:38:53 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 03:38:53 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 03:39:18 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 03:39:18 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 03:42:30 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 03:42:30 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 05:54:40 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 05:54:40 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 08:25:13 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 08:25:13 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 08:25:14 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 08:25:14 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 08:25:15 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 08:25:15 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 08:25:17 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 08:25:17 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 09:00:11 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 09:00:11 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 09:01:00 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 09:01:00 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 09:04:06 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 09:04:06 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 10:04:07 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 10:04:07 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 12:00:45 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 12:00:45 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 12:00:46 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 12:00:46 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 16:37:43 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 16:37:43 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 16:38:57 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 16:38:57 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 16:39:58 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 16:39:58 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 17:39:59 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 17:39:59 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 18:20:24 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 18:20:24 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 19:05:51 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 19:05:51 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 19:48:00 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 19:48:00 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 19:49:04 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 19:49:04 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 19:50:05 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 19:50:05 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 20:34:28 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 20:34:28 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 20:50:06 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 20:50:06 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 21:45:43 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 21:45:43 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:01:19 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:01:19 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:01:20 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:01:20 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:01:21 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:01:21 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:01:27 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:01:27 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:01:27 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:01:27 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:01:34 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:01:34 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:02:35 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:02:35 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:02:36 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:02:36 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:02:36 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:02:36 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:02:37 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:02:37 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:02:37 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:02:37 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:02:38 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:02:38 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:05:19 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:05:19 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:05:20 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:05:20 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:05:20 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:05:20 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:05:21 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:05:21 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:05:21 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:05:21 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:05:22 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:05:22 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:05:40 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:05:40 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:05:41 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:05:41 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:15:13 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:15:13 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:15:13 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:15:13 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:15:15 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:15:15 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:15:16 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:15:16 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:15:16 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:15:16 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:15:16 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:15:16 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:15:17 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:15:17 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:15:17 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:15:17 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:15:17 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:15:17 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:15:17 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:15:17 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:15:18 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:15:18 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:15:18 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:15:18 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:15:18 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:15:18 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:18:38 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:18:38 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:18:39 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
2013-08-07 22:18:39 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 36 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 36, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:19:02 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 74 ]
2013-08-07 22:19:02 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 74 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 22:19:04 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 74 ]
2013-08-07 22:19:04 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 74 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 22:19:04 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 74 ]
2013-08-07 22:19:04 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 74 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 22:30:17 --- ERROR: ErrorException [ 4096 ]: Argument 2 passed to Kohana_View::factory() must be of the type array, integer given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php on line 92 and defined ~ SYSPATH/classes/kohana/view.php [ 28 ]
2013-08-07 22:30:17 --- STRACE: ErrorException [ 4096 ]: Argument 2 passed to Kohana_View::factory() must be of the type array, integer given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php on line 92 and defined ~ SYSPATH/classes/kohana/view.php [ 28 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(28): Kohana_Core::error_handler(4096, 'Argument 2 pass...', '/var/www/zelora...', 28, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(92): Kohana_View::factory('public/default/...', 123)
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(7): Controller_Public->display_tpl('category', 123)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(80): Controller_Public_Category->category(Array)
#4 [internal function]: Controller_Public->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-07 22:30:17 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 84 ]
2013-08-07 22:30:17 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 84 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 22:30:35 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 84 ]
2013-08-07 22:30:35 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 84 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 22:31:56 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 84 ]
2013-08-07 22:31:56 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 84 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 22:34:25 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 84 ]
2013-08-07 22:34:25 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 84 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 22:34:27 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 84 ]
2013-08-07 22:34:27 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 84 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 22:36:29 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 84 ]
2013-08-07 22:36:29 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 84 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 22:36:30 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 84 ]
2013-08-07 22:36:30 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 84 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 22:36:32 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 84 ]
2013-08-07 22:36:32 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 84 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 22:36:34 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 84 ]
2013-08-07 22:36:34 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 84 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 22:37:24 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 84 ]
2013-08-07 22:37:24 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 84 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 22:39:00 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 55 ]
2013-08-07 22:39:00 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 55 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(55): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 55, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 22:39:00 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 84 ]
2013-08-07 22:39:00 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 84 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 22:39:15 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 84 ]
2013-08-07 22:39:15 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 84 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 22:47:15 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 92 ]
2013-08-07 22:47:15 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 92 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 22:47:18 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 41 ]
2013-08-07 22:47:18 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 41 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(41): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 41, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 22:47:18 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 92 ]
2013-08-07 22:47:18 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 92 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 22:47:22 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 92 ]
2013-08-07 22:47:22 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 92 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 22:54:00 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 92 ]
2013-08-07 22:54:00 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 92 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 22:56:11 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 92 ]
2013-08-07 22:56:11 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 92 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 22:56:37 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 92 ]
2013-08-07 22:56:37 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 92 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 22:56:38 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 92 ]
2013-08-07 22:56:38 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 92 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 22:56:39 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 92 ]
2013-08-07 22:56:39 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 92 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 22:56:41 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 92 ]
2013-08-07 22:56:41 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 92 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 22:59:34 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 92 ]
2013-08-07 22:59:34 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 92 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 22:59:44 --- ERROR: ErrorException [ 8 ]: Undefined variable: pages ~ APPPATH/views/public/default/category.php [ 16 ]
2013-08-07 22:59:44 --- STRACE: ErrorException [ 8 ]: Undefined variable: pages ~ APPPATH/views/public/default/category.php [ 16 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/category.php(16): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 16, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(36): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-08-07 22:59:45 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 92 ]
2013-08-07 22:59:45 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 92 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 23:03:38 --- ERROR: ErrorException [ 8 ]: Undefined variable: categorii ~ APPPATH/classes/controller/public.php [ 89 ]
2013-08-07 23:03:38 --- STRACE: ErrorException [ 8 ]: Undefined variable: categorii ~ APPPATH/classes/controller/public.php [ 89 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(89): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 89, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 23:03:38 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 98 ]
2013-08-07 23:03:38 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 98 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 23:03:39 --- ERROR: ErrorException [ 8 ]: Undefined variable: categorii ~ APPPATH/classes/controller/public.php [ 89 ]
2013-08-07 23:03:39 --- STRACE: ErrorException [ 8 ]: Undefined variable: categorii ~ APPPATH/classes/controller/public.php [ 89 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(89): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 89, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 23:03:39 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 98 ]
2013-08-07 23:03:39 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 98 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 23:03:55 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 98 ]
2013-08-07 23:03:55 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 98 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 23:28:58 --- ERROR: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/classes/controller/public/category.php [ 7 ]
2013-08-07 23:28:58 --- STRACE: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/classes/controller/public/category.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(7): Kohana_Core::error_handler(8, 'Undefined offse...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(94): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-07 23:28:59 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 98 ]
2013-08-07 23:28:59 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 98 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 23:29:00 --- ERROR: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/classes/controller/public/category.php [ 7 ]
2013-08-07 23:29:00 --- STRACE: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/classes/controller/public/category.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(7): Kohana_Core::error_handler(8, 'Undefined offse...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(94): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-07 23:29:00 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 98 ]
2013-08-07 23:29:00 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 98 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 23:29:00 --- ERROR: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/classes/controller/public/category.php [ 7 ]
2013-08-07 23:29:00 --- STRACE: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/classes/controller/public/category.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(7): Kohana_Core::error_handler(8, 'Undefined offse...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(94): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-07 23:29:01 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 98 ]
2013-08-07 23:29:01 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 98 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 23:29:22 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 98 ]
2013-08-07 23:29:22 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 98 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 23:29:26 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 98 ]
2013-08-07 23:29:26 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 98 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 23:30:00 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 98 ]
2013-08-07 23:30:00 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 98 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 23:30:02 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 98 ]
2013-08-07 23:30:02 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 98 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 23:30:06 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 98 ]
2013-08-07 23:30:06 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Public::page() ~ APPPATH/classes/controller/public.php [ 98 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 23:38:26 --- ERROR: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/public.php [ 98 ]
2013-08-07 23:38:26 --- STRACE: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/public.php [ 98 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(98): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 98, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 23:38:26 --- ERROR: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/public.php [ 98 ]
2013-08-07 23:38:26 --- STRACE: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/public.php [ 98 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(98): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 98, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 23:40:16 --- ERROR: ErrorException [ 1 ]: Class 'Controller_Public_Page' not found ~ APPPATH/classes/controller/public/category.php [ 3 ]
2013-08-07 23:40:16 --- STRACE: ErrorException [ 1 ]: Class 'Controller_Public_Page' not found ~ APPPATH/classes/controller/public/category.php [ 3 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 23:40:16 --- ERROR: ErrorException [ 1 ]: Class 'Controller_Public_Page' not found ~ APPPATH/classes/controller/public/category.php [ 3 ]
2013-08-07 23:40:16 --- STRACE: ErrorException [ 1 ]: Class 'Controller_Public_Page' not found ~ APPPATH/classes/controller/public/category.php [ 3 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-07 23:40:34 --- ERROR: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/public.php [ 98 ]
2013-08-07 23:40:34 --- STRACE: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/public.php [ 98 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(98): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 98, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 23:40:34 --- ERROR: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/public.php [ 98 ]
2013-08-07 23:40:34 --- STRACE: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/public.php [ 98 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(98): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 98, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-07 23:42:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
2013-08-07 23:42:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(7): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-07 23:42:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
2013-08-07 23:42:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(7): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-07 23:45:23 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
2013-08-07 23:45:23 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(7): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-07 23:45:23 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
2013-08-07 23:45:23 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(7): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-07 23:45:24 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
2013-08-07 23:45:24 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(7): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-07 23:45:24 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
2013-08-07 23:45:24 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(7): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-07 23:45:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
2013-08-07 23:45:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(7): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-07 23:45:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
2013-08-07 23:45:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(7): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-07 23:45:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
2013-08-07 23:45:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(7): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-07 23:45:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
2013-08-07 23:45:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(7): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-07 23:45:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
2013-08-07 23:45:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(7): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-07 23:45:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
2013-08-07 23:45:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(7): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-07 23:45:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
2013-08-07 23:45:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(7): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-07 23:45:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
2013-08-07 23:45:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(7): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-07 23:45:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
2013-08-07 23:45:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(7): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-07 23:45:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
2013-08-07 23:45:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(7): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-07 23:45:27 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
2013-08-07 23:45:27 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(7): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-07 23:45:27 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
2013-08-07 23:45:27 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(7): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-07 23:45:27 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
2013-08-07 23:45:27 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(7): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-07 23:45:28 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
2013-08-07 23:45:28 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(7): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-07 23:45:28 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
2013-08-07 23:45:28 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(7): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-07 23:45:28 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
2013-08-07 23:45:28 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/page.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(7): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-07 23:46:04 --- ERROR: ErrorException [ 8 ]: Undefined variable: title ~ APPPATH/views/public/default/meta_tags.php [ 1 ]
2013-08-07 23:46:04 --- STRACE: ErrorException [ 8 ]: Undefined variable: title ~ APPPATH/views/public/default/meta_tags.php [ 1 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/meta_tags.php(1): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 1, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(5): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-08-07 23:46:05 --- ERROR: ErrorException [ 8 ]: Undefined variable: title ~ APPPATH/views/public/default/meta_tags.php [ 1 ]
2013-08-07 23:46:05 --- STRACE: ErrorException [ 8 ]: Undefined variable: title ~ APPPATH/views/public/default/meta_tags.php [ 1 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/meta_tags.php(1): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 1, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(5): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-08-07 23:49:03 --- ERROR: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/public.php [ 125 ]
2013-08-07 23:49:03 --- STRACE: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/public.php [ 125 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(125): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 125, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(23): Controller_Public->display_error('404')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#3 [internal function]: Controller_Public->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-08-07 23:49:03 --- ERROR: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/public.php [ 125 ]
2013-08-07 23:49:03 --- STRACE: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/public.php [ 125 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(125): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 125, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(23): Controller_Public->display_error('404')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#3 [internal function]: Controller_Public->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-08-07 23:49:05 --- ERROR: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/public.php [ 125 ]
2013-08-07 23:49:05 --- STRACE: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/public.php [ 125 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(125): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 125, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(23): Controller_Public->display_error('404')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#3 [internal function]: Controller_Public->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-08-07 23:49:05 --- ERROR: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/public.php [ 125 ]
2013-08-07 23:49:05 --- STRACE: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/public.php [ 125 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(125): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 125, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(23): Controller_Public->display_error('404')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#3 [internal function]: Controller_Public->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-08-07 23:49:05 --- ERROR: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/public.php [ 125 ]
2013-08-07 23:49:05 --- STRACE: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/public.php [ 125 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(125): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 125, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(23): Controller_Public->display_error('404')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#3 [internal function]: Controller_Public->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-08-07 23:49:05 --- ERROR: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/public.php [ 125 ]
2013-08-07 23:49:05 --- STRACE: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/public.php [ 125 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(125): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 125, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(23): Controller_Public->display_error('404')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#3 [internal function]: Controller_Public->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-08-07 23:49:06 --- ERROR: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/public.php [ 125 ]
2013-08-07 23:49:06 --- STRACE: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/public.php [ 125 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(125): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 125, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(23): Controller_Public->display_error('404')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#3 [internal function]: Controller_Public->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-08-07 23:49:06 --- ERROR: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/public.php [ 125 ]
2013-08-07 23:49:06 --- STRACE: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/public.php [ 125 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(125): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 125, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(23): Controller_Public->display_error('404')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(101): Controller_Public_Page->page(Array)
#3 [internal function]: Controller_Public->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}