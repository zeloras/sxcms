<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2013-11-06 22:15:45 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Admin_Menus::renderList() ~ APPPATH/classes/controller/admin/menus.php [ 19 ]
2013-11-06 22:15:45 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Admin_Menus::renderList() ~ APPPATH/classes/controller/admin/menus.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-11-06 22:16:35 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Admin_Menus::get_access() ~ APPPATH/classes/model/admin/menus.php [ 482 ]
2013-11-06 22:16:35 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Admin_Menus::get_access() ~ APPPATH/classes/model/admin/menus.php [ 482 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-11-06 22:17:27 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/admin/menus/data/index.php [ 45 ]
2013-11-06 22:17:27 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/admin/menus/data/index.php [ 45 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/menus/data/index.php(45): Kohana_Core::error_handler(2, 'Invalid argumen...', '/var/www/zelora...', 45, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(74): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}