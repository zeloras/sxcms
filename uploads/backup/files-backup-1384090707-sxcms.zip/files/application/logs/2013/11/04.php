<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2013-11-04 01:49:26 --- ERROR: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, boolean given ~ APPPATH/classes/controller/admin.php [ 30 ]
2013-11-04 01:49:26 --- STRACE: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, boolean given ~ APPPATH/classes/controller/admin.php [ 30 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'in_array() expe...', '/var/www/zelora...', 30, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(30): in_array(71, false)
#2 [internal function]: Controller_Admin->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-11-04 01:49:34 --- ERROR: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, boolean given ~ APPPATH/classes/controller/admin.php [ 30 ]
2013-11-04 01:49:34 --- STRACE: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, boolean given ~ APPPATH/classes/controller/admin.php [ 30 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'in_array() expe...', '/var/www/zelora...', 30, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(30): in_array(71, false)
#2 [internal function]: Controller_Admin->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-11-04 01:49:37 --- ERROR: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, boolean given ~ APPPATH/classes/controller/admin.php [ 30 ]
2013-11-04 01:49:37 --- STRACE: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, boolean given ~ APPPATH/classes/controller/admin.php [ 30 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'in_array() expe...', '/var/www/zelora...', 30, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(30): in_array(71, false)
#2 [internal function]: Controller_Admin->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-11-04 13:20:03 --- ERROR: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, boolean given ~ APPPATH/classes/controller/admin.php [ 30 ]
2013-11-04 13:20:03 --- STRACE: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, boolean given ~ APPPATH/classes/controller/admin.php [ 30 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'in_array() expe...', '/var/www/zelora...', 30, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(30): in_array(71, false)
#2 [internal function]: Controller_Admin->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-11-04 17:39:36 --- ERROR: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, boolean given ~ APPPATH/classes/controller/admin.php [ 30 ]
2013-11-04 17:39:36 --- STRACE: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, boolean given ~ APPPATH/classes/controller/admin.php [ 30 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'in_array() expe...', '/var/www/zelora...', 30, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(30): in_array(71, false)
#2 [internal function]: Controller_Admin->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-11-04 17:39:38 --- ERROR: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, boolean given ~ APPPATH/classes/controller/admin.php [ 30 ]
2013-11-04 17:39:38 --- STRACE: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, boolean given ~ APPPATH/classes/controller/admin.php [ 30 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'in_array() expe...', '/var/www/zelora...', 30, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(30): in_array(71, false)
#2 [internal function]: Controller_Admin->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}