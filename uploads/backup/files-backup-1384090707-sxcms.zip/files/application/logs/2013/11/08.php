<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2013-11-08 07:27:33 --- DEBUG: FTP Class Initialized
2013-11-08 07:27:33 --- DEBUG: FTP Class Initialized
2013-11-08 07:27:39 --- DEBUG: FTP Class Initialized
2013-11-08 07:27:40 --- DEBUG: FTP Class Initialized
2013-11-08 07:27:51 --- DEBUG: FTP Class Initialized
2013-11-08 07:27:52 --- DEBUG: FTP Class Initialized