<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2013-10-31 18:58:23 --- DEBUG: FTP Class Initialized
2013-10-31 18:58:23 --- DEBUG: FTP Class Initialized
2013-10-31 19:14:52 --- DEBUG: FTP Class Initialized
2013-10-31 19:15:39 --- DEBUG: FTP Class Initialized
2013-10-31 19:16:45 --- DEBUG: FTP Class Initialized
2013-10-31 19:16:45 --- DEBUG: FTP Class Initialized
2013-10-31 19:27:36 --- DEBUG: FTP Class Initialized
2013-10-31 19:30:07 --- DEBUG: FTP Class Initialized
2013-10-31 19:30:30 --- DEBUG: FTP Class Initialized
2013-10-31 19:30:33 --- DEBUG: FTP Class Initialized
2013-10-31 19:39:08 --- DEBUG: FTP Class Initialized
2013-10-31 19:39:09 --- DEBUG: FTP Class Initialized
2013-10-31 19:39:10 --- DEBUG: FTP Class Initialized
2013-10-31 19:39:11 --- DEBUG: FTP Class Initialized
2013-10-31 19:39:24 --- DEBUG: FTP Class Initialized
2013-10-31 19:39:26 --- DEBUG: FTP Class Initialized
2013-10-31 19:44:29 --- DEBUG: FTP Class Initialized
2013-10-31 19:44:32 --- DEBUG: FTP Class Initialized
2013-10-31 19:44:35 --- DEBUG: FTP Class Initialized
2013-10-31 19:46:15 --- DEBUG: FTP Class Initialized
2013-10-31 19:47:11 --- DEBUG: FTP Class Initialized
2013-10-31 19:47:13 --- DEBUG: FTP Class Initialized
2013-10-31 19:47:25 --- DEBUG: FTP Class Initialized
2013-10-31 19:47:28 --- DEBUG: FTP Class Initialized
2013-10-31 19:49:50 --- DEBUG: FTP Class Initialized
2013-10-31 19:49:51 --- DEBUG: FTP Class Initialized
2013-10-31 19:49:54 --- DEBUG: FTP Class Initialized
2013-10-31 19:49:55 --- DEBUG: FTP Class Initialized
2013-10-31 19:49:57 --- DEBUG: FTP Class Initialized
2013-10-31 19:49:57 --- DEBUG: FTP Class Initialized
2013-10-31 19:49:58 --- DEBUG: FTP Class Initialized
2013-10-31 19:49:59 --- DEBUG: FTP Class Initialized
2013-10-31 19:50:00 --- DEBUG: FTP Class Initialized
2013-10-31 19:50:00 --- DEBUG: FTP Class Initialized
2013-10-31 20:26:18 --- DEBUG: FTP Class Initialized
2013-10-31 20:26:18 --- DEBUG: FTP Class Initialized
2013-10-31 20:26:30 --- DEBUG: FTP Class Initialized
2013-10-31 20:32:21 --- DEBUG: FTP Class Initialized
2013-10-31 21:12:48 --- ERROR: ErrorException [ 2 ]: unserialize() expects exactly 1 parameter, 0 given ~ APPPATH/classes/controller/public.php [ 160 ]
2013-10-31 21:12:48 --- STRACE: ErrorException [ 2 ]: unserialize() expects exactly 1 parameter, 0 given ~ APPPATH/classes/controller/public.php [ 160 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'unserialize() e...', '/var/www/zelora...', 160, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(160): unserialize()
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(19): Controller_Public->display_tpl('page', Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(151): Controller_Public_Page->page(Array)
#4 [internal function]: Controller_Public->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-31 22:01:04 --- DEBUG: FTP Class Initialized
2013-10-31 22:01:17 --- DEBUG: FTP Class Initialized
2013-10-31 22:05:00 --- DEBUG: FTP Class Initialized
2013-10-31 22:05:02 --- DEBUG: FTP Class Initialized
2013-10-31 22:33:00 --- DEBUG: FTP Class Initialized
2013-10-31 22:33:06 --- DEBUG: FTP Class Initialized
2013-10-31 23:12:12 --- DEBUG: FTP Class Initialized
2013-10-31 23:12:12 --- DEBUG: FTP Class Initialized
2013-10-31 23:12:17 --- DEBUG: FTP Class Initialized
2013-10-31 23:12:18 --- DEBUG: FTP Class Initialized
2013-10-31 23:14:51 --- DEBUG: FTP Class Initialized
2013-10-31 23:14:51 --- DEBUG: FTP Class Initialized
2013-10-31 23:14:55 --- DEBUG: FTP Class Initialized
2013-10-31 23:14:57 --- DEBUG: FTP Class Initialized
2013-10-31 23:16:14 --- DEBUG: FTP Class Initialized
2013-10-31 23:16:14 --- DEBUG: FTP Class Initialized