<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2013-10-28 13:01:38 --- DEBUG: FTP Class Initialized
2013-10-28 13:01:39 --- DEBUG: FTP Class Initialized
2013-10-28 13:01:52 --- DEBUG: FTP Class Initialized