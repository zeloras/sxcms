<?php defined('SYSPATH') or die('No direct script access.'); ?>

2011-06-27 06:34:07 --- ERROR: ErrorException [ 1 ]: Call to undefined method Kohana::config() ~ MODPATH/unittest/classes/kohana/unittest/tests.php [ 75 ]
2011-06-27 06:34:07 --- STRACE: ErrorException [ 1 ]: Call to undefined method Kohana::config() ~ MODPATH/unittest/classes/kohana/unittest/tests.php [ 75 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2011-06-27 06:35:03 --- ERROR: ErrorException [ 1 ]: Call to undefined method Kohana::config() ~ MODPATH/unittest/classes/kohana/unittest/tests.php [ 249 ]
2011-06-27 06:35:03 --- STRACE: ErrorException [ 1 ]: Call to undefined method Kohana::config() ~ MODPATH/unittest/classes/kohana/unittest/tests.php [ 249 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}