<?php defined('SYSPATH') or die('No direct script access.');

return array(
    'name' => array(
        'check_name' => 'Please check name, this name already use',
    ),
    'title' => array(
        'check_title' => 'Please check title, this title already use',
    ),
);
?>
