<?php defined('SYSPATH') or die('No direct script access.');

return array(
    'email' => array(
        'check_email' => 'Please check email, this mail isset in database',
    ),
);
?>
