<?php defined('SYSPATH') or die('No direct script access.');

return array(
    'name' => array(
        'check_name' => 'Please enter a different name for the menu',
    ),
);
?>
