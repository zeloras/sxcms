<h1><?=__('404 Error')?></h1>
<h3><?=_("Don't find this page")?></h3>