
<!DOCTYPE html>
<html lang="en">
<head>
<?php echo $metatags ?>
 
<link href="/application/views/public/default/bootstrap/css/bootstrap.css" rel="stylesheet">
<link href="/application/views/public/default/css/general.css" rel="stylesheet">
<link href="/application/views/public/default/bootstrap/css/bootstrap-responsive.css" rel="stylesheet">
 
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
</head>
<body>
    <div class="row-fluid">
        <div class="span3">
            <!--<ul class="nav nav-list sidebar">
                <li class="nav-header">Меню</li>-->
                <!--<li class="active"><a href="/"><i class="icon-white icon-home"></i> Главная</a></li>
                <li><a href="/category"><i class="icon-book"></i> Категории</a></li>
                <li><a href="/contacts"><i class="icon-pencil"></i> Контакты</a></li>
                <li class="nav-header">Продукты</li>
                <li><a href="/about-myshop">MyShop магазин</a></li>
                <li><a href="/">SxCms</a></li>
                <li><a href="/">ExWork</a></li>
                <li class="divider"></li>
                <li><a href="/for-clients"><i class="icon-flag"></i> Для клиентов</a></li>
            </ul>-->
        </div>
        
        <div class="span9">
            <div class="container-narrow">
                <div class="masthead">
                    <!--<ul class="nav nav-pills pull-right">
                        <li class="active"><a href="/">Главная</a></li>
                        <li><a href="http://shop.sxservice.ru/">Демо</a></li>
                        <li><a href="http://wiki.sxservice.ru/">Wiki</a></li>
                    </ul>-->
                    <?=Helper_Public::load_menu('top_menu')?>
                    <h3 class="muted">WAAAAT name</h3>
                </div>

                <div class="body-container">
                    <hr>
                    <div class="jumbotron">
                        <h1>SxService lab</h1>
                        <p class="lead">Сайт в стадии создания.</p>
                    </div>
                    <hr>
                    <?echo $content;?>
                    <hr>
                </div>
                <div class="footer">
                    <p>&copy; SxService 2013</p>
                </div>
            </div>  
        </div>
</div>
 
<script src="/application/views/public/default/js/jquery.js" type="text/javascript"></script>
<script src="/application/views/public/default/bootstrap/js/bootstrap.js" type="text/javascript"></script>
</body>
</html>
