<?echo $breadcrumbs;?>
<div class="center">
    <ul>
        <?if (sizeof($cats) > 0) {?>
            <li style="list-style: none;">Категории</li>
            <?foreach ($cats as $ct) {?>
                <li>
                    <a href="/<?echo Helper_Common::get_category_path($ct->id);?>"><?echo $ct->title;?></a>
                </li>
            <?}?>
        <?}else{?>
            <li>Нет категорий</li>     
        <?}?>
    </ul>
    <hr />
    <ul>
        <?if (sizeof($pages) > 0) {?>
            <li style="list-style: none;">Страницы</li>
            <?foreach ($pages as $pg) {?>
                <li>
                    <a href="<?echo $pg->cat_url.$pg->url;?>"><?echo $pg->title;?></a>
                </li>
            <?}?>
        <?}else{?>
            <li>В этой категории нет страниц.</li>
        <?}?>
    </ul>
</div>