function showMessage($message, $title, $type)
{
    $title = ($title == null) ? 'Информация' : $title;
    $type = ($type == null) ? 'info' : $type;
    $.msgGrowl ({type: $type, title: $title, text: $message});
}

function initElrte()
{
elRTE.prototype.options.panels.mypanelbar = [
     'bold', 'italic', 'underline', 'forecolor', 'justifyleft', 'justifyright',
     'justifycenter', 'justifyfull', 'formatblock', 'fontsize', 'fontname', 'insertorderedlist', 'insertunorderedlist',
     'link', 'image'
];
    elRTE.prototype.options.toolbars.mypanelbar = ['mypanelbar'];
    var opts = {
            cssClass : 'el-rte',
            lang     : $base_language,
            height   : 250,
            fmAllow  : true,
            width    : 700,
            toolbar  : 'mypanelbar',
            cssfiles : ['css/elrte-inner.css']
    }

    var elrite = $('.load_texteditor').elrte(opts);
}

function initTinyMce()
{
tinymce.triggerSave(); 
tinymce.init({
    skin: "lightgray",
    skin_url: '/application/views/admin/js/tinymce/skins/lightgray',
    selector: ".load_texteditor",
    language_url: "/application/views/admin/js/tinymce/langs/"+$base_language+".js",
    relative_urls: false,
    convert_urls: true,
    document_base_url: "/application/views/admin/js/tinymce/",
    plugins: [
        "lists link image charmap print preview hr anchor",
        "searchreplace wordcount code fullscreen",
        "insertdatetime media table contextmenu",
        "textcolor"
    ],
    toolbar1: "undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
    toolbar2: "print preview media | forecolor backcolor",
    image_advtab: true,
});
}