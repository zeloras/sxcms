<div class="main">
    <div class="container">
        <div class="row">
            <div class="span12">
                <div class="widget stacked">	
                    <div class="widget-header">
                        <i class="icon-file"></i>
                        <h3>Главная страница</h3>
                    </div>

                    <div class="widget-content">
                        Главная страница
                    </div>	
                </div>
            </div>
        </div>
    </div>
</div>