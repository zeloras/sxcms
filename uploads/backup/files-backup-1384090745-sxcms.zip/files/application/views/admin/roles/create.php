<div class="main">
    <div class="container">
        <div class="row">
            <div class="span12">
                <div class="widget stacked">
<div class="widget-header">
    <i class="icon-file"></i>
    <h3><?=__('Role create')?></h3>
    <span class="action_buttons">
        <button class="btn pull-right formSubmit" data-form="#submit-form" data-after="exit" data-action="/admin/roles/add">
            <i class=" icon-save icon-large"></i> <?=__('Save and exit')?>
        </button>
        <button class="btn btn-success pull-right formSubmit" data-form="#submit-form" data-after="save" data-action="/admin/roles/add">
            <i class=" icon-save icon-large"></i> <?=__('Save')?>
        </button>
        <button data-href="/admin/roles" data-container="#base-container" class="btn pull-right btn-info pjax_button">
            <i class="icon-arrow-left"></i> <?=__('Back')?>
        </button>
    </span>
</div>
                    
<div class="widget-content">
    <?if (isset($success)) {?>
        <div id="success_block">
            <p id="status_success">showMessage('<?=__('Success create role')?>', '<?=__('Status role create')?>', 'success')</p>
            <p id="url_success">/admin/roles/edit/<?=$success?></p>
            <p id="url_success_exit">/admin/roles/</p>
        </div>
    <?}?>
    <div id="errors_block">
        <?if (isset($errors)) {?>
        <div class="alert alert-error">
            <strong><?=__('Error')?></strong>
            <ul>
                <?foreach ($errors as $error) {?>
                    <li><?=__($error)?></li>
                <?}?>
            </ul>
        </div>
        <?}?>
    </div>
    <form id="submit-form" method="post" class="form-horizontal">
        <input type="hidden" name="submit_this_form" value="1">
            <div class="control-group">
                <label class="control-label" for="title_p"><?=__('Title')?></label>
                <div class="controls">
                    <input type="text" class="input-xxlarge" name="title" id="title_p">
                </div>
            </div>

            <div class="control-group">
                <label class="control-label" for="name_p"><?=__('Name')?></label>
                <div class="controls">
                    <input type="text" class="input-xxlarge" name="name" id="name_p">
                </div>
            </div>

            <div class="control-group">
                <label class="control-label" for="description_p"><?=__('Description')?></label>
                <div class="controls">
                    <input type="text" class="input-xxlarge" name="description" id="description_p">
                </div>
            </div>
                
            <div class="control-group">
                
                <div class="span3 pull-left">
                    <div class="widget stacked widget-table">
                        <div class="widget-header">
                            <span class="icon-key"></span>
                            <h3><?=__('Administrative')?></h3>
                        </div>

                        <div class="widget-content">
                            <div class="checkbox-row">
                                <span class="niceCheck">
                                    <input type="checkbox" name="access[]" value="71">
                                </span> <?=__('Login in admin panel')?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="span3 pull-left">
                    <div class="widget stacked widget-table">
                        <div class="widget-header">
                            <span class="icon-th"></span>
                            <h3><?=__('Pages')?></h3>
                        </div>

                        <div class="widget-content">
                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="11"></span> <?=__('View a list of pages')?>
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="12"></span> <?=__('Create pages')?>
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="13"></span> <?=__('Edit pages')?>
                            </div>
                            
                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="14"></span> <?=__('Remove pages')?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="span3 pull-left">
                    <div class="widget stacked widget-table">
                        <div class="widget-header">
                            <span class="icon-list-alt"></span>
                            <h3><?=__('Categories')?></h3>
                        </div>

                        <div class="widget-content">
                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="21"></span> <?=__('View categories list')?>
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="22"></span> <?=__('Create categories')?>
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="23"></span> <?=__('Edit categories')?>
                            </div>
                            
                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="24"></span> <?=__('Remove categories')?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="span3 pull-left">
                    <div class="widget stacked widget-table">
                        <div class="widget-header">
                            <span class="icon-link"></span>
                            <h3><?=__('Menu')?></h3>
                        </div>

                        <div class="widget-content">
                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="31"></span> <?=__('View lists menu')?>
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="32"></span> <?=__('Create menu')?>
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="33"></span> <?=__('Edit menu')?>
                            </div>
                            
                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="34"></span> <?=__('Remove menu')?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="span3 pull-left">
                    <div class="widget stacked widget-table">
                        <div class="widget-header">
                            <span class="icon-group"></span>
                            <h3><?=__('Groups')?></h3>
                        </div>

                        <div class="widget-content">
                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="41"></span> <?=__('View lists groups')?>
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="42"></span> <?=__('Create groups')?>
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="43"></span> <?=__('Edit groups')?>
                            </div>
                            
                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="44"></span> <?=__('Remove groups')?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="span3 pull-left">
                    <div class="widget stacked widget-table">
                        <div class="widget-header">
                            <span class="icon-user"></span>
                            <h3><?=__('Users')?></h3>
                        </div>

                        <div class="widget-content">
                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="51"></span> <?=__('View users lists')?>
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="52"></span> <?=__('Create users')?>
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="53"></span> <?=__('Edit users')?>
                            </div>
                            
                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="54"></span> <?=__('Remove users')?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="span3 pull-left">
                    <div class="widget stacked widget-table">
                        <div class="widget-header">
                            <span class="icon-user"></span>
                            <h3><?=__('For users')?></h3>
                        </div>

                        <div class="widget-content">
                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="61"></span> <?=__('View pages')?>
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="62"></span> <?=__('Comment')?>
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="63"></span> <?=__('Login')?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>  
        </form>
    </div>
                </div>
            </div>
        </div>
    </div>
</div>