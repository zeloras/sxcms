<?php
class Helper_Admin
{
    public static function get_settings()
    {
        $config_file = 'config.xml';
        $get_config = file_get_contents($config_file);
        $get_xml_config = new SimpleXMLElement($get_config);
        $xml_template = $get_xml_config->base->template;
        
        $settings = ORM::factory('settings')->find()->as_array();
        $cloud = unserialize($settings['cloud']);
        $general = unserialize($settings['general']);
        $seo = unserialize($settings['seo']);
        $data['yandex_cloud'] = $cloud['yandex'];
        $data['ftp'] = $cloud['ftp'];
        $data['general'] = $general;
        $data['seo'] = $seo;
        $data['template'] = $xml_template;
        return $data;
    }
    
    public static function get_categories_sidebar()
    {
        $cat_model = new Model_Admin_Categorys();
        $tree = $cat_model->buildForAdmin();
        $cat_tree = $cat_model->renderCatList($tree, 'sidebar-list');
        return $cat_tree;
    }
 }