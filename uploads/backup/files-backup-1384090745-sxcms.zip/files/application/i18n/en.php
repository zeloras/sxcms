<?php defined('SYSPATH') or die('No direct script access.');
 
return array(
   'Привет мир' => 'Hello world',
   'Название проекта' => 'Project Name',
);