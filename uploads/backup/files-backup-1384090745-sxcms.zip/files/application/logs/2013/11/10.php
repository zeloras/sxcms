<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2013-11-10 00:27:58 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Pages::sort_by() ~ APPPATH/classes/controller/admin/pages.php [ 27 ]
2013-11-10 00:27:58 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Pages::sort_by() ~ APPPATH/classes/controller/admin/pages.php [ 27 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-11-10 00:28:14 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Pages::sortby() ~ APPPATH/classes/controller/admin/pages.php [ 27 ]
2013-11-10 00:28:14 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Pages::sortby() ~ APPPATH/classes/controller/admin/pages.php [ 27 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-11-10 00:28:15 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Pages::sortby() ~ APPPATH/classes/controller/admin/pages.php [ 27 ]
2013-11-10 00:28:15 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Pages::sortby() ~ APPPATH/classes/controller/admin/pages.php [ 27 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-11-10 06:54:19 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'lastlogin' in 'order clause' [ SELECT `sx_users`.`id` AS `id`, `sx_users`.`email` AS `email`, `sx_users`.`username` AS `username`, `sx_users`.`password` AS `password`, `sx_users`.`logins` AS `logins`, `sx_users`.`last_login` AS `last_login` FROM `sx_users` AS `sx_users` ORDER BY `lastlogin` ASC LIMIT 25 OFFSET 0 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-11-10 06:54:19 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'lastlogin' in 'order clause' [ SELECT `sx_users`.`id` AS `id`, `sx_users`.`email` AS `email`, `sx_users`.`username` AS `username`, `sx_users`.`password` AS `password`, `sx_users`.`logins` AS `logins`, `sx_users`.`last_login` AS `last_login` FROM `sx_users` AS `sx_users` ORDER BY `lastlogin` ASC LIMIT 25 OFFSET 0 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `sx_user...', 'Model_Users', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/users.php(30): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(218): Controller_Admin_Users->users_list('users', 0)
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(46): Controller_Admin->routes('users')
#6 [internal function]: Controller_Admin->action_route()
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#10 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#11 {main}
2013-11-10 07:22:40 --- DEBUG: FTP Class Initialized
2013-11-10 07:22:41 --- DEBUG: FTP Class Initialized
2013-11-10 07:28:46 --- DEBUG: FTP Class Initialized
2013-11-10 07:28:48 --- DEBUG: FTP Class Initialized
2013-11-10 07:33:09 --- DEBUG: FTP Class Initialized
2013-11-10 07:34:00 --- DEBUG: FTP Class Initialized
2013-11-10 07:34:21 --- DEBUG: FTP Class Initialized
2013-11-10 07:34:48 --- DEBUG: FTP Class Initialized
2013-11-10 07:37:04 --- DEBUG: FTP Class Initialized
2013-11-10 07:37:04 --- DEBUG: FTP Class Initialized
2013-11-10 07:37:38 --- DEBUG: FTP Class Initialized
2013-11-10 07:38:16 --- DEBUG: FTP Class Initialized
2013-11-10 07:38:22 --- INFO: Zip Compression Class Initialized
2013-11-10 07:38:27 --- DEBUG: FTP Class Initialized