<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2013-11-02 00:20:43 --- DEBUG: FTP Class Initialized
2013-11-02 00:20:43 --- DEBUG: FTP Class Initialized
2013-11-02 01:37:25 --- ERROR: ErrorException [ 1 ]: Call to a member function update() on a non-object ~ APPPATH/classes/controller/admin/special.php [ 465 ]
2013-11-02 01:37:25 --- STRACE: ErrorException [ 1 ]: Call to a member function update() on a non-object ~ APPPATH/classes/controller/admin/special.php [ 465 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-11-02 01:39:51 --- ERROR: ErrorException [ 1 ]: Call to a member function update() on a non-object ~ APPPATH/classes/controller/admin/special.php [ 465 ]
2013-11-02 01:39:51 --- STRACE: ErrorException [ 1 ]: Call to a member function update() on a non-object ~ APPPATH/classes/controller/admin/special.php [ 465 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-11-02 19:20:27 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_User as array ~ APPPATH/classes/controller/admin.php [ 382 ]
2013-11-02 19:20:27 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_User as array ~ APPPATH/classes/controller/admin.php [ 382 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-11-02 19:25:42 --- ERROR: ErrorException [ 2 ]: Attempt to assign property of non-object ~ APPPATH/classes/controller/admin.php [ 388 ]
2013-11-02 19:25:42 --- STRACE: ErrorException [ 2 ]: Attempt to assign property of non-object ~ APPPATH/classes/controller/admin.php [ 388 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(388): Kohana_Core::error_handler(2, 'Attempt to assi...', '/var/www/zelora...', 388, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(47): Controller_Admin->display_tpl('index/home')
#2 [internal function]: Controller_Admin->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-11-02 19:28:17 --- DEBUG: FTP Class Initialized
2013-11-02 19:28:17 --- DEBUG: FTP Class Initialized
2013-11-02 19:28:21 --- DEBUG: FTP Class Initialized
2013-11-02 19:28:22 --- DEBUG: FTP Class Initialized
2013-11-02 23:38:25 --- ERROR: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, boolean given ~ APPPATH/classes/controller/admin.php [ 30 ]
2013-11-02 23:38:25 --- STRACE: ErrorException [ 2 ]: in_array() expects parameter 2 to be array, boolean given ~ APPPATH/classes/controller/admin.php [ 30 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'in_array() expe...', '/var/www/zelora...', 30, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(30): in_array(71, false)
#2 [internal function]: Controller_Admin->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}