<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2013-11-03 00:07:23 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected '$this' (T_VARIABLE) ~ APPPATH/classes/controller/admin/users.php [ 34 ]
2013-11-03 00:07:23 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected '$this' (T_VARIABLE) ~ APPPATH/classes/controller/admin/users.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-11-03 00:07:24 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected '$this' (T_VARIABLE) ~ APPPATH/classes/controller/admin/users.php [ 34 ]
2013-11-03 00:07:24 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected '$this' (T_VARIABLE) ~ APPPATH/classes/controller/admin/users.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}