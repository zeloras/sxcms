<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2013-10-22 09:26:26 --- ERROR: ErrorException [ 8 ]: Undefined variable: settings ~ APPPATH/views/admin/settings/index.php [ 31 ]
2013-10-22 09:26:26 --- STRACE: ErrorException [ 8 ]: Undefined variable: settings ~ APPPATH/views/admin/settings/index.php [ 31 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(31): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 31, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-22 09:28:06 --- ERROR: ErrorException [ 8 ]: Undefined variable: settings ~ APPPATH/views/admin/settings/index.php [ 31 ]
2013-10-22 09:28:06 --- STRACE: ErrorException [ 8 ]: Undefined variable: settings ~ APPPATH/views/admin/settings/index.php [ 31 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(31): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 31, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-22 09:28:37 --- ERROR: ErrorException [ 8 ]: Undefined variable: settings ~ APPPATH/views/admin/settings/index.php [ 31 ]
2013-10-22 09:28:37 --- STRACE: ErrorException [ 8 ]: Undefined variable: settings ~ APPPATH/views/admin/settings/index.php [ 31 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(31): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 31, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-22 09:28:49 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Settings as array ~ APPPATH/classes/controller/admin/settings.php [ 8 ]
2013-10-22 09:28:49 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Settings as array ~ APPPATH/classes/controller/admin/settings.php [ 8 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-22 09:29:03 --- ERROR: ErrorException [ 8 ]: Undefined variable: settings ~ APPPATH/views/admin/settings/index.php [ 31 ]
2013-10-22 09:29:03 --- STRACE: ErrorException [ 8 ]: Undefined variable: settings ~ APPPATH/views/admin/settings/index.php [ 31 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(31): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 31, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-22 09:29:28 --- ERROR: ErrorException [ 8 ]: Undefined variable: settings ~ APPPATH/views/admin/settings/index.php [ 31 ]
2013-10-22 09:29:28 --- STRACE: ErrorException [ 8 ]: Undefined variable: settings ~ APPPATH/views/admin/settings/index.php [ 31 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(31): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 31, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-22 09:29:48 --- ERROR: ErrorException [ 8 ]: Undefined variable: settings ~ APPPATH/views/admin/settings/index.php [ 31 ]
2013-10-22 09:29:48 --- STRACE: ErrorException [ 8 ]: Undefined variable: settings ~ APPPATH/views/admin/settings/index.php [ 31 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(31): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 31, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-22 09:29:49 --- ERROR: ErrorException [ 8 ]: Undefined variable: settings ~ APPPATH/views/admin/settings/index.php [ 31 ]
2013-10-22 09:29:49 --- STRACE: ErrorException [ 8 ]: Undefined variable: settings ~ APPPATH/views/admin/settings/index.php [ 31 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(31): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 31, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-22 09:30:32 --- ERROR: ErrorException [ 2 ]: Illegal string offset 'site_name' ~ APPPATH/views/admin/settings/index.php [ 31 ]
2013-10-22 09:30:32 --- STRACE: ErrorException [ 2 ]: Illegal string offset 'site_name' ~ APPPATH/views/admin/settings/index.php [ 31 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(31): Kohana_Core::error_handler(2, 'Illegal string ...', '/var/www/zelora...', 31, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-22 09:30:34 --- ERROR: ErrorException [ 2 ]: Illegal string offset 'site_name' ~ APPPATH/views/admin/settings/index.php [ 31 ]
2013-10-22 09:30:34 --- STRACE: ErrorException [ 2 ]: Illegal string offset 'site_name' ~ APPPATH/views/admin/settings/index.php [ 31 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(31): Kohana_Core::error_handler(2, 'Illegal string ...', '/var/www/zelora...', 31, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-22 09:38:00 --- ERROR: ErrorException [ 2 ]: Illegal string offset 'site_name' ~ APPPATH/views/admin/settings/index.php [ 31 ]
2013-10-22 09:38:00 --- STRACE: ErrorException [ 2 ]: Illegal string offset 'site_name' ~ APPPATH/views/admin/settings/index.php [ 31 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(31): Kohana_Core::error_handler(2, 'Illegal string ...', '/var/www/zelora...', 31, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-22 09:39:16 --- ERROR: ErrorException [ 2 ]: Illegal string offset 'site_name' ~ APPPATH/views/admin/settings/index.php [ 31 ]
2013-10-22 09:39:16 --- STRACE: ErrorException [ 2 ]: Illegal string offset 'site_name' ~ APPPATH/views/admin/settings/index.php [ 31 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(31): Kohana_Core::error_handler(2, 'Illegal string ...', '/var/www/zelora...', 31, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-22 09:39:35 --- ERROR: ErrorException [ 2 ]: Illegal string offset 'site_name' ~ APPPATH/views/admin/settings/index.php [ 31 ]
2013-10-22 09:39:35 --- STRACE: ErrorException [ 2 ]: Illegal string offset 'site_name' ~ APPPATH/views/admin/settings/index.php [ 31 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(31): Kohana_Core::error_handler(2, 'Illegal string ...', '/var/www/zelora...', 31, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-22 09:39:36 --- ERROR: ErrorException [ 2 ]: Illegal string offset 'site_name' ~ APPPATH/views/admin/settings/index.php [ 31 ]
2013-10-22 09:39:36 --- STRACE: ErrorException [ 2 ]: Illegal string offset 'site_name' ~ APPPATH/views/admin/settings/index.php [ 31 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(31): Kohana_Core::error_handler(2, 'Illegal string ...', '/var/www/zelora...', 31, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-22 09:40:11 --- ERROR: ErrorException [ 2 ]: Illegal string offset 'site_name' ~ APPPATH/views/admin/settings/index.php [ 31 ]
2013-10-22 09:40:11 --- STRACE: ErrorException [ 2 ]: Illegal string offset 'site_name' ~ APPPATH/views/admin/settings/index.php [ 31 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(31): Kohana_Core::error_handler(2, 'Illegal string ...', '/var/www/zelora...', 31, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-22 09:41:47 --- ERROR: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
2013-10-22 09:41:47 --- STRACE: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(80): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 80, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-22 09:42:06 --- ERROR: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
2013-10-22 09:42:06 --- STRACE: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(80): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 80, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-22 09:44:43 --- ERROR: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
2013-10-22 09:44:43 --- STRACE: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(80): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 80, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-22 09:55:01 --- ERROR: ErrorException [ 8 ]: Undefined variable: templates ~ APPPATH/views/admin/settings/index.php [ 116 ]
2013-10-22 09:55:01 --- STRACE: ErrorException [ 8 ]: Undefined variable: templates ~ APPPATH/views/admin/settings/index.php [ 116 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(116): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 116, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-22 10:07:52 --- ERROR: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
2013-10-22 10:07:52 --- STRACE: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(80): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 80, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-22 10:08:48 --- ERROR: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
2013-10-22 10:08:48 --- STRACE: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(80): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 80, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-22 10:09:36 --- ERROR: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
2013-10-22 10:09:36 --- STRACE: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(80): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 80, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-22 10:10:09 --- ERROR: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
2013-10-22 10:10:09 --- STRACE: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(80): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 80, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-22 10:46:45 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Admin::$input ~ APPPATH/classes/controller/admin/settings.php [ 13 ]
2013-10-22 10:46:45 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Admin::$input ~ APPPATH/classes/controller/admin/settings.php [ 13 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(13): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 13, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-10-22 10:48:24 --- ERROR: ErrorException [ 8 ]: Undefined property: Controller_Admin::$input ~ APPPATH/classes/controller/admin/settings.php [ 13 ]
2013-10-22 10:48:24 --- STRACE: ErrorException [ 8 ]: Undefined property: Controller_Admin::$input ~ APPPATH/classes/controller/admin/settings.php [ 13 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(13): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 13, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-10-22 11:26:41 --- ERROR: ErrorException [ 8 ]: Undefined variable: backup_mysql ~ APPPATH/views/admin/settings/index.php [ 223 ]
2013-10-22 11:26:41 --- STRACE: ErrorException [ 8 ]: Undefined variable: backup_mysql ~ APPPATH/views/admin/settings/index.php [ 223 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(223): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 223, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-22 11:32:39 --- ERROR: ErrorException [ 8 ]: Undefined variable: backups ~ APPPATH/classes/controller/admin/settings.php [ 56 ]
2013-10-22 11:32:39 --- STRACE: ErrorException [ 8 ]: Undefined variable: backups ~ APPPATH/classes/controller/admin/settings.php [ 56 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(56): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 56, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-10-22 11:33:09 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/admin/settings/index.php [ 223 ]
2013-10-22 11:33:09 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/admin/settings/index.php [ 223 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(223): Kohana_Core::error_handler(2, 'Invalid argumen...', '/var/www/zelora...', 223, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-22 13:41:21 --- ERROR: ErrorException [ 1 ]: Undefined class constant '_table_columns' ~ APPPATH/classes/controller/admin/settings.php [ 8 ]
2013-10-22 13:41:21 --- STRACE: ErrorException [ 1 ]: Undefined class constant '_table_columns' ~ APPPATH/classes/controller/admin/settings.php [ 8 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-22 13:41:32 --- ERROR: ErrorException [ 1 ]: Cannot access protected property Model_Users::$_table_columns ~ APPPATH/classes/controller/admin/settings.php [ 8 ]
2013-10-22 13:41:32 --- STRACE: ErrorException [ 1 ]: Cannot access protected property Model_Users::$_table_columns ~ APPPATH/classes/controller/admin/settings.php [ 8 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-22 13:41:33 --- ERROR: ErrorException [ 1 ]: Cannot access protected property Model_Users::$_table_columns ~ APPPATH/classes/controller/admin/settings.php [ 8 ]
2013-10-22 13:41:33 --- STRACE: ErrorException [ 1 ]: Cannot access protected property Model_Users::$_table_columns ~ APPPATH/classes/controller/admin/settings.php [ 8 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-22 13:41:40 --- ERROR: ErrorException [ 1 ]: Undefined class constant 'table_columns' ~ APPPATH/classes/controller/admin/settings.php [ 8 ]
2013-10-22 13:41:40 --- STRACE: ErrorException [ 1 ]: Undefined class constant 'table_columns' ~ APPPATH/classes/controller/admin/settings.php [ 8 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-22 13:41:41 --- ERROR: ErrorException [ 1 ]: Undefined class constant 'table_columns' ~ APPPATH/classes/controller/admin/settings.php [ 8 ]
2013-10-22 13:41:41 --- STRACE: ErrorException [ 1 ]: Undefined class constant 'table_columns' ~ APPPATH/classes/controller/admin/settings.php [ 8 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-22 13:45:08 --- ERROR: ErrorException [ 1 ]: Cannot access protected property ORM::$_column_cache ~ APPPATH/classes/controller/admin/settings.php [ 8 ]
2013-10-22 13:45:08 --- STRACE: ErrorException [ 1 ]: Cannot access protected property ORM::$_column_cache ~ APPPATH/classes/controller/admin/settings.php [ 8 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-22 14:50:46 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Admin_Settings::backup_system() ~ APPPATH/classes/controller/admin/settings.php [ 8 ]
2013-10-22 14:50:46 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Admin_Settings::backup_system() ~ APPPATH/classes/controller/admin/settings.php [ 8 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-22 14:51:41 --- ERROR: ErrorException [ 1 ]: Class 'Model_Myshop_banners' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
2013-10-22 14:51:41 --- STRACE: ErrorException [ 1 ]: Class 'Model_Myshop_banners' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-22 14:51:59 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/model/admin/settings.php [ 69 ]
2013-10-22 14:51:59 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/model/admin/settings.php [ 69 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(69): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 69, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-22 14:52:15 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/model/admin/settings.php [ 70 ]
2013-10-22 14:52:15 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/model/admin/settings.php [ 70 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(70): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 70, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-22 14:52:41 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/model/admin/settings.php [ 70 ]
2013-10-22 14:52:41 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/model/admin/settings.php [ 70 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(70): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 70, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-22 14:53:45 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/model/admin/settings.php [ 73 ]
2013-10-22 14:53:45 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/model/admin/settings.php [ 73 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(73): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 73, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-22 14:59:38 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/model/admin/settings.php [ 73 ]
2013-10-22 14:59:38 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/model/admin/settings.php [ 73 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(73): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 73, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-22 14:59:40 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/model/admin/settings.php [ 73 ]
2013-10-22 14:59:40 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/model/admin/settings.php [ 73 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(73): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 73, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-22 15:07:17 --- ERROR: ErrorException [ 2 ]: Attempt to assign property of non-object ~ APPPATH/classes/model/admin/settings.php [ 90 ]
2013-10-22 15:07:17 --- STRACE: ErrorException [ 2 ]: Attempt to assign property of non-object ~ APPPATH/classes/model/admin/settings.php [ 90 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(90): Kohana_Core::error_handler(2, 'Attempt to assi...', '/var/www/zelora...', 90, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-22 15:08:01 --- ERROR: ErrorException [ 8 ]: Undefined index: display ~ APPPATH/classes/model/admin/settings.php [ 90 ]
2013-10-22 15:08:01 --- STRACE: ErrorException [ 8 ]: Undefined index: display ~ APPPATH/classes/model/admin/settings.php [ 90 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(90): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 90, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-22 15:12:10 --- ERROR: ErrorException [ 8 ]: Undefined index: display ~ APPPATH/classes/model/admin/settings.php [ 90 ]
2013-10-22 15:12:10 --- STRACE: ErrorException [ 8 ]: Undefined index: display ~ APPPATH/classes/model/admin/settings.php [ 90 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(90): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 90, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-22 15:14:27 --- ERROR: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 102 ]
2013-10-22 15:14:27 --- STRACE: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 102 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'array_keys() ex...', '/var/www/zelora...', 102, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(102): array_keys(Object(Model_Users))
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#5 [internal function]: Controller_Admin->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-10-22 15:14:57 --- ERROR: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 102 ]
2013-10-22 15:14:57 --- STRACE: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 102 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'array_keys() ex...', '/var/www/zelora...', 102, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(102): array_keys(Object(Model_Users))
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#5 [internal function]: Controller_Admin->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-10-22 15:16:20 --- ERROR: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 102 ]
2013-10-22 15:16:20 --- STRACE: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 102 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'array_keys() ex...', '/var/www/zelora...', 102, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(102): array_keys(Object(Model_Users))
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#5 [internal function]: Controller_Admin->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-10-22 15:16:21 --- ERROR: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 102 ]
2013-10-22 15:16:21 --- STRACE: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 102 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'array_keys() ex...', '/var/www/zelora...', 102, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(102): array_keys(Object(Model_Users))
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#5 [internal function]: Controller_Admin->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-10-22 15:16:22 --- ERROR: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 102 ]
2013-10-22 15:16:22 --- STRACE: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 102 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'array_keys() ex...', '/var/www/zelora...', 102, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(102): array_keys(Object(Model_Users))
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#5 [internal function]: Controller_Admin->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-10-22 15:16:22 --- ERROR: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 102 ]
2013-10-22 15:16:22 --- STRACE: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 102 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'array_keys() ex...', '/var/www/zelora...', 102, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(102): array_keys(Object(Model_Users))
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#5 [internal function]: Controller_Admin->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-10-22 15:16:22 --- ERROR: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 102 ]
2013-10-22 15:16:22 --- STRACE: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 102 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'array_keys() ex...', '/var/www/zelora...', 102, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(102): array_keys(Object(Model_Users))
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#5 [internal function]: Controller_Admin->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-10-22 15:18:13 --- ERROR: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 102 ]
2013-10-22 15:18:13 --- STRACE: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 102 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'array_keys() ex...', '/var/www/zelora...', 102, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(102): array_keys(Object(Model_Users))
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#5 [internal function]: Controller_Admin->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-10-22 15:18:36 --- ERROR: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 102 ]
2013-10-22 15:18:36 --- STRACE: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 102 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'array_keys() ex...', '/var/www/zelora...', 102, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(102): array_keys(Object(Model_Users))
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#5 [internal function]: Controller_Admin->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-10-22 15:21:11 --- ERROR: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 102 ]
2013-10-22 15:21:11 --- STRACE: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 102 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'array_keys() ex...', '/var/www/zelora...', 102, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(102): array_keys(Object(Model_Users))
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#5 [internal function]: Controller_Admin->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-10-22 15:21:45 --- ERROR: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 102 ]
2013-10-22 15:21:45 --- STRACE: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 102 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'array_keys() ex...', '/var/www/zelora...', 102, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(102): array_keys(Object(Model_Users))
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#5 [internal function]: Controller_Admin->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-10-22 15:21:56 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Users as array ~ APPPATH/classes/model/admin/settings.php [ 100 ]
2013-10-22 15:21:56 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Users as array ~ APPPATH/classes/model/admin/settings.php [ 100 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-22 15:22:02 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Users as array ~ APPPATH/classes/model/admin/settings.php [ 100 ]
2013-10-22 15:22:02 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Users as array ~ APPPATH/classes/model/admin/settings.php [ 100 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-22 15:22:03 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Users as array ~ APPPATH/classes/model/admin/settings.php [ 100 ]
2013-10-22 15:22:03 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Users as array ~ APPPATH/classes/model/admin/settings.php [ 100 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-22 15:25:49 --- ERROR: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 105 ]
2013-10-22 15:25:49 --- STRACE: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 105 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'array_keys() ex...', '/var/www/zelora...', 105, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(105): array_keys(Object(Model_Users))
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#5 [internal function]: Controller_Admin->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-10-22 15:27:20 --- ERROR: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 105 ]
2013-10-22 15:27:20 --- STRACE: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 105 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'array_keys() ex...', '/var/www/zelora...', 105, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(105): array_keys(Object(Model_Users))
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#5 [internal function]: Controller_Admin->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-10-22 15:34:08 --- ERROR: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 102 ]
2013-10-22 15:34:08 --- STRACE: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 102 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'array_keys() ex...', '/var/www/zelora...', 102, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(102): array_keys(Object(Model_Users))
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#5 [internal function]: Controller_Admin->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-10-22 15:34:10 --- ERROR: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 102 ]
2013-10-22 15:34:10 --- STRACE: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 102 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'array_keys() ex...', '/var/www/zelora...', 102, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(102): array_keys(Object(Model_Users))
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#5 [internal function]: Controller_Admin->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-10-22 15:34:15 --- ERROR: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 105 ]
2013-10-22 15:34:15 --- STRACE: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 105 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'array_keys() ex...', '/var/www/zelora...', 105, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(105): array_keys(Object(Model_Users))
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#5 [internal function]: Controller_Admin->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-10-22 15:36:39 --- ERROR: Kohana_Exception [ 0 ]: The _object property does not exist in the Model_Users class ~ MODPATH/orm/classes/kohana/orm.php [ 621 ]
2013-10-22 15:36:39 --- STRACE: Kohana_Exception [ 0 ]: The _object property does not exist in the Model_Users class ~ MODPATH/orm/classes/kohana/orm.php [ 621 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(102): Kohana_ORM->__get('_object')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-22 15:36:50 --- ERROR: ErrorException [ 1 ]: Undefined class constant '_object' ~ APPPATH/classes/model/admin/settings.php [ 102 ]
2013-10-22 15:36:50 --- STRACE: ErrorException [ 1 ]: Undefined class constant '_object' ~ APPPATH/classes/model/admin/settings.php [ 102 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-22 15:36:51 --- ERROR: ErrorException [ 1 ]: Undefined class constant '_object' ~ APPPATH/classes/model/admin/settings.php [ 102 ]
2013-10-22 15:36:51 --- STRACE: ErrorException [ 1 ]: Undefined class constant '_object' ~ APPPATH/classes/model/admin/settings.php [ 102 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-22 15:36:56 --- ERROR: ErrorException [ 1 ]: Undefined class constant 'object' ~ APPPATH/classes/model/admin/settings.php [ 102 ]
2013-10-22 15:36:56 --- STRACE: ErrorException [ 1 ]: Undefined class constant 'object' ~ APPPATH/classes/model/admin/settings.php [ 102 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-22 15:36:57 --- ERROR: ErrorException [ 1 ]: Undefined class constant 'object' ~ APPPATH/classes/model/admin/settings.php [ 102 ]
2013-10-22 15:36:57 --- STRACE: ErrorException [ 1 ]: Undefined class constant 'object' ~ APPPATH/classes/model/admin/settings.php [ 102 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-22 15:37:20 --- ERROR: ErrorException [ 1 ]: Cannot access protected property Model_Users::$_object ~ APPPATH/classes/model/admin/settings.php [ 102 ]
2013-10-22 15:37:20 --- STRACE: ErrorException [ 1 ]: Cannot access protected property Model_Users::$_object ~ APPPATH/classes/model/admin/settings.php [ 102 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-22 15:37:38 --- ERROR: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 105 ]
2013-10-22 15:37:38 --- STRACE: ErrorException [ 2 ]: array_keys() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 105 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'array_keys() ex...', '/var/www/zelora...', 105, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(105): array_keys(Object(Model_Users))
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#5 [internal function]: Controller_Admin->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-10-22 15:37:56 --- ERROR: ErrorException [ 2 ]: array_values() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 130 ]
2013-10-22 15:37:56 --- STRACE: ErrorException [ 2 ]: array_values() expects parameter 1 to be array, object given ~ APPPATH/classes/model/admin/settings.php [ 130 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'array_values() ...', '/var/www/zelora...', 130, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(130): array_values(Object(Model_Users))
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#5 [internal function]: Controller_Admin->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-10-22 15:38:27 --- ERROR: ErrorException [ 8 ]: Undefined variable: return ~ APPPATH/classes/model/admin/settings.php [ 154 ]
2013-10-22 15:38:27 --- STRACE: ErrorException [ 8 ]: Undefined variable: return ~ APPPATH/classes/model/admin/settings.php [ 154 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(154): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 154, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-22 15:40:30 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Users as array ~ APPPATH/classes/model/admin/settings.php [ 131 ]
2013-10-22 15:40:30 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Users as array ~ APPPATH/classes/model/admin/settings.php [ 131 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-22 15:42:01 --- ERROR: ErrorException [ 8 ]: Use of undefined constant link - assumed 'link' ~ APPPATH/views/admin/settings/index.php [ 238 ]
2013-10-22 15:42:01 --- STRACE: ErrorException [ 8 ]: Use of undefined constant link - assumed 'link' ~ APPPATH/views/admin/settings/index.php [ 238 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(238): Kohana_Core::error_handler(8, 'Use of undefine...', '/var/www/zelora...', 238, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-22 15:44:09 --- ERROR: ErrorException [ 1 ]: Class 'Model_Menus_data' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
2013-10-22 15:44:09 --- STRACE: ErrorException [ 1 ]: Class 'Model_Menus_data' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-22 15:46:54 --- ERROR: ErrorException [ 8 ]: Use of undefined constant link - assumed 'link' ~ APPPATH/views/admin/settings/index.php [ 238 ]
2013-10-22 15:46:54 --- STRACE: ErrorException [ 8 ]: Use of undefined constant link - assumed 'link' ~ APPPATH/views/admin/settings/index.php [ 238 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(238): Kohana_Core::error_handler(8, 'Use of undefine...', '/var/www/zelora...', 238, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-22 16:05:20 --- ERROR: ErrorException [ 1 ]: Class 'KOZip' not found ~ APPPATH/classes/model/libs/zipper.php [ 3 ]
2013-10-22 16:05:20 --- STRACE: ErrorException [ 1 ]: Class 'KOZip' not found ~ APPPATH/classes/model/libs/zipper.php [ 3 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-22 16:07:10 --- INFO: Zip Compression Class Initialized
2013-10-22 16:07:10 --- ERROR: ErrorException [ 2 ]: closedir() expects parameter 1 to be resource, boolean given ~ APPPATH/classes/model/libs/zipper.php [ 45 ]
2013-10-22 16:07:10 --- STRACE: ErrorException [ 2 ]: closedir() expects parameter 1 to be resource, boolean given ~ APPPATH/classes/model/libs/zipper.php [ 45 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'closedir() expe...', '/var/www/zelora...', 45, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/libs/zipper.php(45): closedir(false)
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(178): Model_Libs_Zipper->get_files_from_folder('', 'files/')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#6 [internal function]: Controller_Admin->action_route()
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#10 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#11 {main}
2013-10-22 16:08:59 --- INFO: Zip Compression Class Initialized
2013-10-22 16:08:59 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-22 16:08:59 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('uploads/backup/...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-22 16:11:54 --- INFO: Zip Compression Class Initialized
2013-10-22 16:11:54 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-22 16:11:54 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('uploads/backup/...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-22 16:11:58 --- INFO: Zip Compression Class Initialized
2013-10-22 16:11:58 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-22 16:11:58 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('uploads/backup/...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-22 16:11:59 --- INFO: Zip Compression Class Initialized
2013-10-22 16:11:59 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-22 16:11:59 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('uploads/backup/...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-22 16:12:29 --- INFO: Zip Compression Class Initialized
2013-10-22 16:12:29 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-22 16:12:29 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('uploads/backup/...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-22 16:12:31 --- INFO: Zip Compression Class Initialized
2013-10-22 16:12:31 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-22 16:12:31 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('uploads/backup/...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-22 16:14:13 --- ERROR: ErrorException [ 8 ]: Undefined property: Model_Libs_Zipper::$response ~ APPPATH/classes/model/libs/zipper.php [ 18 ]
2013-10-22 16:14:13 --- STRACE: ErrorException [ 8 ]: Undefined property: Model_Libs_Zipper::$response ~ APPPATH/classes/model/libs/zipper.php [ 18 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/libs/zipper.php(18): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 18, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(178): Model_Libs_Zipper->get_files_from_folder('', 'files/')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#5 [internal function]: Controller_Admin->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-10-22 16:14:35 --- INFO: Zip Compression Class Initialized
2013-10-22 16:14:35 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Libs_Zipper::add_data() ~ APPPATH/classes/model/admin/settings.php [ 179 ]
2013-10-22 16:14:35 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Libs_Zipper::add_data() ~ APPPATH/classes/model/admin/settings.php [ 179 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-22 16:16:51 --- ERROR: ErrorException [ 8 ]: Undefined property: Model_Admin_Settings::$response ~ APPPATH/classes/model/admin/settings.php [ 163 ]
2013-10-22 16:16:51 --- STRACE: ErrorException [ 8 ]: Undefined property: Model_Admin_Settings::$response ~ APPPATH/classes/model/admin/settings.php [ 163 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(163): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 163, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-22 16:17:16 --- INFO: Zip Compression Class Initialized
2013-10-22 16:17:16 --- INFO: Zip Compression Class Initialized
2013-10-22 16:17:16 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-22 16:17:16 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(182): KOZip->archive('uploads/backup/...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-22 16:19:26 --- INFO: Zip Compression Class Initialized
2013-10-22 16:19:26 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-22 16:19:26 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(181): KOZip->archive('uploads/backup/...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-22 16:19:28 --- INFO: Zip Compression Class Initialized
2013-10-22 16:19:28 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-22 16:19:28 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(181): KOZip->archive('uploads/backup/...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}