<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2013-10-11 15:54:57 --- ERROR: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
2013-10-11 15:54:57 --- STRACE: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(80): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 80, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-11 15:54:57 --- ERROR: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
2013-10-11 15:54:57 --- STRACE: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(80): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 80, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-11 15:57:27 --- ERROR: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
2013-10-11 15:57:27 --- STRACE: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(80): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 80, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-11 15:57:27 --- ERROR: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
2013-10-11 15:57:27 --- STRACE: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(80): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 80, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}