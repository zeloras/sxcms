<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2013-10-27 10:48:22 --- ERROR: Kohana_Exception [ 0 ]: Cannot update settings model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1284 ]
2013-10-27 10:48:22 --- STRACE: Kohana_Exception [ 0 ]: Cannot update settings model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1284 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(22): Kohana_ORM->update()
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(146): Model_Admin_Settings->admin_settings_update()
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-27 10:48:22 --- ERROR: Kohana_Exception [ 0 ]: Cannot update settings model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1284 ]
2013-10-27 10:48:22 --- STRACE: Kohana_Exception [ 0 ]: Cannot update settings model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1284 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(22): Kohana_ORM->update()
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(146): Model_Admin_Settings->admin_settings_update()
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-27 13:18:36 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Libs_Webdev::ftp_connect() ~ APPPATH/classes/controller/admin/special.php [ 311 ]
2013-10-27 13:18:36 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Libs_Webdev::ftp_connect() ~ APPPATH/classes/controller/admin/special.php [ 311 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-27 13:18:37 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Libs_Webdev::ftp_connect() ~ APPPATH/classes/controller/admin/special.php [ 311 ]
2013-10-27 13:18:37 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Libs_Webdev::ftp_connect() ~ APPPATH/classes/controller/admin/special.php [ 311 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-27 13:18:38 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Libs_Webdev::ftp_connect() ~ APPPATH/classes/controller/admin/special.php [ 311 ]
2013-10-27 13:18:38 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Libs_Webdev::ftp_connect() ~ APPPATH/classes/controller/admin/special.php [ 311 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-27 13:18:38 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Libs_Webdev::ftp_connect() ~ APPPATH/classes/controller/admin/special.php [ 311 ]
2013-10-27 13:18:38 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Libs_Webdev::ftp_connect() ~ APPPATH/classes/controller/admin/special.php [ 311 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-27 13:19:52 --- ERROR: ErrorException [ 1 ]: Call to a member function connect() on a non-object ~ APPPATH/classes/model/libs/api.php [ 112 ]
2013-10-27 13:19:52 --- STRACE: ErrorException [ 1 ]: Call to a member function connect() on a non-object ~ APPPATH/classes/model/libs/api.php [ 112 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-27 13:19:53 --- ERROR: ErrorException [ 1 ]: Call to a member function connect() on a non-object ~ APPPATH/classes/model/libs/api.php [ 112 ]
2013-10-27 13:19:53 --- STRACE: ErrorException [ 1 ]: Call to a member function connect() on a non-object ~ APPPATH/classes/model/libs/api.php [ 112 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-27 13:19:54 --- ERROR: ErrorException [ 1 ]: Call to a member function connect() on a non-object ~ APPPATH/classes/model/libs/api.php [ 112 ]
2013-10-27 13:19:54 --- STRACE: ErrorException [ 1 ]: Call to a member function connect() on a non-object ~ APPPATH/classes/model/libs/api.php [ 112 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-27 15:22:51 --- ERROR: ErrorException [ 1 ]: Call to a member function connect() on a non-object ~ APPPATH/classes/model/libs/api.php [ 114 ]
2013-10-27 15:22:51 --- STRACE: ErrorException [ 1 ]: Call to a member function connect() on a non-object ~ APPPATH/classes/model/libs/api.php [ 114 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-27 15:29:40 --- ERROR: ErrorException [ 1 ]: Call to a member function connect() on a non-object ~ APPPATH/classes/model/libs/api.php [ 114 ]
2013-10-27 15:29:40 --- STRACE: ErrorException [ 1 ]: Call to a member function connect() on a non-object ~ APPPATH/classes/model/libs/api.php [ 114 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-27 15:29:44 --- ERROR: ErrorException [ 1 ]: Call to a member function connect() on a non-object ~ APPPATH/classes/model/libs/api.php [ 114 ]
2013-10-27 15:29:44 --- STRACE: ErrorException [ 1 ]: Call to a member function connect() on a non-object ~ APPPATH/classes/model/libs/api.php [ 114 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-27 15:31:20 --- ERROR: ErrorException [ 1 ]: Call to undefined function log_message() ~ APPPATH/classes/model/libs/ftp.php [ 27 ]
2013-10-27 15:31:20 --- STRACE: ErrorException [ 1 ]: Call to undefined function log_message() ~ APPPATH/classes/model/libs/ftp.php [ 27 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-27 15:36:34 --- DEBUG: FTP Class Initialized
2013-10-27 15:45:37 --- DEBUG: FTP Class Initialized
2013-10-27 15:48:09 --- ERROR: ErrorException [ 1 ]: Call to a member function connect() on a non-object ~ APPPATH/classes/model/libs/api.php [ 114 ]
2013-10-27 15:48:09 --- STRACE: ErrorException [ 1 ]: Call to a member function connect() on a non-object ~ APPPATH/classes/model/libs/api.php [ 114 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-27 15:48:10 --- ERROR: ErrorException [ 1 ]: Call to a member function connect() on a non-object ~ APPPATH/classes/model/libs/api.php [ 114 ]
2013-10-27 15:48:10 --- STRACE: ErrorException [ 1 ]: Call to a member function connect() on a non-object ~ APPPATH/classes/model/libs/api.php [ 114 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-27 15:48:26 --- ERROR: ErrorException [ 1 ]: Call to a member function connect() on a non-object ~ APPPATH/classes/model/libs/api.php [ 114 ]
2013-10-27 15:48:26 --- STRACE: ErrorException [ 1 ]: Call to a member function connect() on a non-object ~ APPPATH/classes/model/libs/api.php [ 114 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-27 15:48:27 --- ERROR: ErrorException [ 1 ]: Call to a member function connect() on a non-object ~ APPPATH/classes/model/libs/api.php [ 114 ]
2013-10-27 15:48:27 --- STRACE: ErrorException [ 1 ]: Call to a member function connect() on a non-object ~ APPPATH/classes/model/libs/api.php [ 114 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-27 15:56:53 --- DEBUG: FTP Class Initialized
2013-10-27 16:04:04 --- DEBUG: FTP Class Initialized
2013-10-27 16:06:58 --- DEBUG: FTP Class Initialized
2013-10-27 16:07:07 --- DEBUG: FTP Class Initialized
2013-10-27 17:39:15 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Settings as array ~ APPPATH/classes/helper/admin.php [ 7 ]
2013-10-27 17:39:15 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Settings as array ~ APPPATH/classes/helper/admin.php [ 7 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-27 18:23:23 --- DEBUG: FTP Class Initialized
2013-10-27 18:23:45 --- DEBUG: FTP Class Initialized
2013-10-27 18:45:40 --- ERROR: ErrorException [ 1 ]: Call to a member function webdev_connect() on a non-object ~ APPPATH/classes/controller/admin/settings.php [ 150 ]
2013-10-27 18:45:40 --- STRACE: ErrorException [ 1 ]: Call to a member function webdev_connect() on a non-object ~ APPPATH/classes/controller/admin/settings.php [ 150 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-27 18:46:11 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/classes/model/libs/api.php [ 93 ]
2013-10-27 18:46:11 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/classes/model/libs/api.php [ 93 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/libs/api.php(93): Kohana_Core::error_handler(2, 'Invalid argumen...', '/var/www/zelora...', 93, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(151): Model_Libs_Api->webdev_list_short()
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-27 18:51:03 --- DEBUG: FTP Class Initialized
2013-10-27 18:51:09 --- DEBUG: FTP Class Initialized
2013-10-27 18:51:10 --- DEBUG: FTP Class Initialized
2013-10-27 19:10:09 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/classes/model/libs/api.php [ 93 ]
2013-10-27 19:10:09 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/classes/model/libs/api.php [ 93 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/libs/api.php(93): Kohana_Core::error_handler(2, 'Invalid argumen...', '/var/www/zelora...', 93, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(152): Model_Libs_Api->webdev_list_short()
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-27 19:10:42 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/classes/model/libs/api.php [ 93 ]
2013-10-27 19:10:42 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/classes/model/libs/api.php [ 93 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/libs/api.php(93): Kohana_Core::error_handler(2, 'Invalid argumen...', '/var/www/zelora...', 93, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(152): Model_Libs_Api->webdev_list_short()
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-27 19:11:04 --- DEBUG: FTP Class Initialized
2013-10-27 19:11:50 --- DEBUG: FTP Class Initialized
2013-10-27 19:15:03 --- DEBUG: FTP Class Initialized
2013-10-27 19:16:11 --- DEBUG: FTP Class Initialized
2013-10-27 19:16:12 --- DEBUG: FTP Class Initialized
2013-10-27 19:16:13 --- DEBUG: FTP Class Initialized
2013-10-27 19:16:13 --- DEBUG: FTP Class Initialized