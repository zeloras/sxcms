
2013-10-24 14:22:29 --- ERROR: ErrorException [ 8 ]: Undefined variable: cloud ~ APPPATH/views/admin/settings/index.php [ 305 ]
2013-10-24 14:22:29 --- STRACE: ErrorException [ 8 ]: Undefined variable: cloud ~ APPPATH/views/admin/settings/index.php [ 305 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(305): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 305, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-24 14:27:25 --- ERROR: ErrorException [ 8 ]: unserialize(): Error at offset 0 of 2 bytes ~ APPPATH/classes/controller/admin/settings.php [ 141 ]
2013-10-24 14:27:25 --- STRACE: ErrorException [ 8 ]: unserialize(): Error at offset 0 of 2 bytes ~ APPPATH/classes/controller/admin/settings.php [ 141 ]
--
#0 [internal function]: Kohana_Core::error_handler(8, 'unserialize(): ...', '/var/www/zelora...', 141, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(141): unserialize('44')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-24 14:28:37 --- ERROR: ErrorException [ 8 ]: unserialize(): Error at offset 0 of 2 bytes ~ APPPATH/classes/controller/admin/settings.php [ 142 ]
2013-10-24 14:28:37 --- STRACE: ErrorException [ 8 ]: unserialize(): Error at offset 0 of 2 bytes ~ APPPATH/classes/controller/admin/settings.php [ 142 ]
--
#0 [internal function]: Kohana_Core::error_handler(8, 'unserialize(): ...', '/var/www/zelora...', 142, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(142): unserialize('44')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-24 14:30:35 --- ERROR: ErrorException [ 8 ]: Undefined index: active ~ APPPATH/views/admin/settings/index.php [ 322 ]
2013-10-24 14:30:35 --- STRACE: ErrorException [ 8 ]: Undefined index: active ~ APPPATH/views/admin/settings/index.php [ 322 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(322): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 322, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-24 14:31:35 --- ERROR: ErrorException [ 8 ]: Undefined index: active ~ APPPATH/views/admin/settings/index.php [ 322 ]
2013-10-24 14:31:35 --- STRACE: ErrorException [ 8 ]: Undefined index: active ~ APPPATH/views/admin/settings/index.php [ 322 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(322): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 322, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-24 21:07:38 --- ERROR: Database_Exception [ 1030 ]: Got error 122 from storage engine [ SHOW FULL COLUMNS FROM `sx_pages` ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-10-24 21:07:38 --- STRACE: Database_Exception [ 1030 ]: Got error 122 from storage engine [ SHOW FULL COLUMNS FROM `sx_pages` ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/mysql.php(358): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1538): Kohana_Database_MySQL->list_columns('pages')
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(392): Kohana_ORM->list_columns()
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(337): Kohana_ORM->reload_columns()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(246): Kohana_ORM->_initialize()
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(37): Kohana_ORM->__construct(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(136): Kohana_ORM::factory('pages')
#7 [internal function]: Controller_Public->action_route()
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#12 {main}
2013-10-24 22:41:43 --- ERROR: Database_Exception [ 2 ]: mysql_connect(): Too many connections ~ MODPATH/database/classes/kohana/database/mysql.php [ 67 ]
2013-10-24 22:41:43 --- STRACE: Database_Exception [ 2 ]: mysql_connect(): Too many connections ~ MODPATH/database/classes/kohana/database/mysql.php [ 67 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/mysql.php(171): Kohana_Database_MySQL->connect()
#1 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/mysql.php(358): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1538): Kohana_Database_MySQL->list_columns('categorys')
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(392): Kohana_ORM->list_columns()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(337): Kohana_ORM->reload_columns()
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(246): Kohana_ORM->_initialize()
#6 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(37): Kohana_ORM->__construct(NULL)
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(13): Kohana_ORM::factory('categorys')
#8 [internal function]: Controller_Public->action_route()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-24 23:59:44 --- ERROR: Database_Exception [ 2 ]: mysql_connect(): Too many connections ~ MODPATH/database/classes/kohana/database/mysql.php [ 67 ]
2013-10-24 23:59:44 --- STRACE: Database_Exception [ 2 ]: mysql_connect(): Too many connections ~ MODPATH/database/classes/kohana/database/mysql.php [ 67 ]
--
#0 /va