<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2013-08-08 00:15:12 --- ERROR: View_Exception [ 0 ]: The requested view public/default/page could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
2013-08-08 00:15:12 --- STRACE: View_Exception [ 0 ]: The requested view public/default/page could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(137): Kohana_View->set_filename('public/default/...')
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(30): Kohana_View->__construct('public/default/...', Array)
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(111): Kohana_View::factory('public/default/...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(19): Controller_Public->display_tpl('page', Array, Array)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(102): Controller_Public_Page->page(Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:15:13 --- ERROR: View_Exception [ 0 ]: The requested view public/default/page could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
2013-08-08 00:15:13 --- STRACE: View_Exception [ 0 ]: The requested view public/default/page could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(137): Kohana_View->set_filename('public/default/...')
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(30): Kohana_View->__construct('public/default/...', Array)
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(111): Kohana_View::factory('public/default/...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(19): Controller_Public->display_tpl('page', Array, Array)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(102): Controller_Public_Page->page(Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:15:13 --- ERROR: View_Exception [ 0 ]: The requested view public/default/page could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
2013-08-08 00:15:13 --- STRACE: View_Exception [ 0 ]: The requested view public/default/page could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(137): Kohana_View->set_filename('public/default/...')
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(30): Kohana_View->__construct('public/default/...', Array)
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(111): Kohana_View::factory('public/default/...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(19): Controller_Public->display_tpl('page', Array, Array)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(102): Controller_Public_Page->page(Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:15:14 --- ERROR: View_Exception [ 0 ]: The requested view public/default/page could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
2013-08-08 00:15:14 --- STRACE: View_Exception [ 0 ]: The requested view public/default/page could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(137): Kohana_View->set_filename('public/default/...')
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(30): Kohana_View->__construct('public/default/...', Array)
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(111): Kohana_View::factory('public/default/...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/page.php(19): Controller_Public->display_tpl('page', Array, Array)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(102): Controller_Public_Page->page(Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:54:09 --- ERROR: ErrorException [ 8 ]: Undefined variable: type ~ APPPATH/classes/helper/public.php [ 12 ]
2013-08-08 00:54:09 --- STRACE: ErrorException [ 8 ]: Undefined variable: type ~ APPPATH/classes/helper/public.php [ 12 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(12): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 12, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 00:55:24 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:24 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:26 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:26 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:27 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:27 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:29 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:29 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:30 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:30 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:31 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:31 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:31 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:31 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:32 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:32 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:32 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:32 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:32 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:32 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:32 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:32 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:32 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:32 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:32 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:32 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:32 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:32 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:33 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:33 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:33 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:33 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:33 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:33 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:33 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:33 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:33 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:33 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:33 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:33 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:33 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:33 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:33 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:33 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:33 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:33 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:33 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:33 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:33 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:33 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:33 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:33 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:33 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:33 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:33 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:33 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:33 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:33 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:33 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:33 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:34 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:34 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:34 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:34 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:34 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:34 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:34 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:34 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:34 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:34 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:34 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:34 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:34 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:34 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:34 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:34 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:34 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:34 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:34 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:34 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:34 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:34 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:34 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:34 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:34 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:34 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, name, parent_id, url' in 'field list' [ SELECT `id, name, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, nam...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:47 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, title, parent_id, url' in 'field list' [ SELECT `id, title, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:47 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, title, parent_id, url' in 'field list' [ SELECT `id, title, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, tit...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:48 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, title, parent_id, url' in 'field list' [ SELECT `id, title, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:48 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, title, parent_id, url' in 'field list' [ SELECT `id, title, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, tit...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 00:55:48 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, title, parent_id, url' in 'field list' [ SELECT `id, title, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-08 00:55:48 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, title, parent_id, url' in 'field list' [ SELECT `id, title, parent_id, url`, `sx_categorys`.`id` AS `id`, `sx_categorys`.`parent_id` AS `parent_id`, `sx_categorys`.`title` AS `title`, `sx_categorys`.`url` AS `url`, `sx_categorys`.`description` AS `description`, `sx_categorys`.`meta_keywords` AS `meta_keywords`, `sx_categorys`.`meta_description` AS `meta_description`, `sx_categorys`.`position` AS `position`, `sx_categorys`.`date` AS `date`, `sx_categorys`.`update` AS `update` FROM `sx_categorys` AS `sx_categorys` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, tit...', 'Model_Categorys', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(60): Helper_Public::breadcrumbs('category', Array)
#5 [internal function]: Controller_Public->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-08-08 01:07:42 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 41 ]
2013-08-08 01:07:42 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 41 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(41): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 41, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 01:09:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 41 ]
2013-08-08 01:09:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 41 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(41): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 41, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 01:12:57 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 41 ]
2013-08-08 01:12:57 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 41 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(41): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 41, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 01:19:36 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 41 ]
2013-08-08 01:19:36 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 41 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(41): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 41, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 01:20:30 --- ERROR: ErrorException [ 2 ]: Missing argument 3 for Kohana_ORM::where(), called in /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php on line 70 and defined ~ MODPATH/orm/classes/kohana/orm.php [ 1719 ]
2013-08-08 01:20:30 --- STRACE: ErrorException [ 2 ]: Missing argument 3 for Kohana_ORM::where(), called in /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php on line 70 and defined ~ MODPATH/orm/classes/kohana/orm.php [ 1719 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1719): Kohana_Core::error_handler(2, 'Missing argumen...', '/var/www/zelora...', 1719, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(70): Kohana_ORM->where('id', '2')
#2 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/category.php(8): Helper_Public::get_category_path('2')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#6 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(31): Kohana_View->__toString()
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#10 [internal function]: Kohana_Controller_Template->after()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-08 01:20:58 --- ERROR: ErrorException [ 1 ]: Using $this when not in object context ~ APPPATH/classes/helper/public.php [ 78 ]
2013-08-08 01:20:58 --- STRACE: ErrorException [ 1 ]: Using $this when not in object context ~ APPPATH/classes/helper/public.php [ 78 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-08 01:21:28 --- ERROR: ErrorException [ 8 ]: Undefined variable: breadcrumbs ~ APPPATH/views/public/default/category.php [ 1 ]
2013-08-08 01:21:28 --- STRACE: ErrorException [ 8 ]: Undefined variable: breadcrumbs ~ APPPATH/views/public/default/category.php [ 1 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/category.php(1): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 1, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(31): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-08-08 01:24:59 --- ERROR: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 59 ]
2013-08-08 01:24:59 --- STRACE: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 59 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(59): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 59, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(94): Helper_Public::breadcrumbs('category', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 01:25:00 --- ERROR: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 59 ]
2013-08-08 01:25:00 --- STRACE: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 59 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(59): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 59, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(94): Helper_Public::breadcrumbs('category', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 01:28:07 --- ERROR: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 45 ]
2013-08-08 01:28:07 --- STRACE: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 45 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(45): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 45, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(91): Helper_Public::breadcrumbs('category_list')
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 01:28:07 --- ERROR: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 45 ]
2013-08-08 01:28:07 --- STRACE: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 45 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(45): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 45, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(91): Helper_Public::breadcrumbs('category_list')
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 01:36:56 --- ERROR: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 45 ]
2013-08-08 01:36:56 --- STRACE: ErrorException [ 8 ]: Undefined variable: end_data ~ APPPATH/classes/helper/public.php [ 45 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(45): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 45, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(91): Helper_Public::breadcrumbs('category_list')
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 01:37:54 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 41 ]
2013-08-08 01:37:54 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 41 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(41): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 41, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 01:50:14 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 41 ]
2013-08-08 01:50:14 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 41 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(41): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 41, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 01:50:14 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 41 ]
2013-08-08 01:50:14 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 41 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(41): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 41, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 03:14:06 --- ERROR: ErrorException [ 8 ]: Undefined offset: 2 ~ APPPATH/classes/controller/public.php [ 20 ]
2013-08-08 03:14:06 --- STRACE: ErrorException [ 8 ]: Undefined offset: 2 ~ APPPATH/classes/controller/public.php [ 20 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(20): Kohana_Core::error_handler(8, 'Undefined offse...', '/var/www/zelora...', 20, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 03:24:19 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 66 ]
2013-08-08 03:24:19 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 66 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(66): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 66, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 03:27:14 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/category.php [ 7 ]
2013-08-08 03:27:14 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/category.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(7): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(78): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 03:27:15 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/category.php [ 7 ]
2013-08-08 03:27:15 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/category.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(7): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(78): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 03:27:20 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public/category.php [ 7 ]
2013-08-08 03:27:20 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public/category.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(78): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 03:27:33 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public/category.php [ 7 ]
2013-08-08 03:27:33 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public/category.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(78): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 03:27:34 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public/category.php [ 7 ]
2013-08-08 03:27:34 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public/category.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(78): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 03:27:35 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public/category.php [ 7 ]
2013-08-08 03:27:35 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public/category.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(78): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 03:27:35 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public/category.php [ 7 ]
2013-08-08 03:27:35 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public/category.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(78): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 03:27:36 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public/category.php [ 7 ]
2013-08-08 03:27:36 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public/category.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(78): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 03:27:36 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public/category.php [ 7 ]
2013-08-08 03:27:36 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public/category.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(7): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(78): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 03:27:55 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/category.php [ 7 ]
2013-08-08 03:27:55 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/category.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(7): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(78): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 03:40:52 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Categorys as array ~ APPPATH/classes/controller/public/category.php [ 9 ]
2013-08-08 03:40:52 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Categorys as array ~ APPPATH/classes/controller/public/category.php [ 9 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-08 03:40:53 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Categorys as array ~ APPPATH/classes/controller/public/category.php [ 9 ]
2013-08-08 03:40:53 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Categorys as array ~ APPPATH/classes/controller/public/category.php [ 9 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-08 03:40:54 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Categorys as array ~ APPPATH/classes/controller/public/category.php [ 9 ]
2013-08-08 03:40:54 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Categorys as array ~ APPPATH/classes/controller/public/category.php [ 9 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-08 03:43:09 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 66 ]
2013-08-08 03:43:09 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 66 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(66): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 66, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 03:43:10 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 66 ]
2013-08-08 03:43:10 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 66 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(66): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 66, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 03:43:11 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 66 ]
2013-08-08 03:43:11 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 66 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(66): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 66, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 04:00:02 --- ERROR: ErrorException [ 8 ]: Undefined variable: cat_isset ~ APPPATH/classes/controller/public/category.php [ 7 ]
2013-08-08 04:00:02 --- STRACE: ErrorException [ 8 ]: Undefined variable: cat_isset ~ APPPATH/classes/controller/public/category.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(7): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(80): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 04:00:04 --- ERROR: ErrorException [ 8 ]: Undefined variable: cat_isset ~ APPPATH/classes/controller/public/category.php [ 7 ]
2013-08-08 04:00:04 --- STRACE: ErrorException [ 8 ]: Undefined variable: cat_isset ~ APPPATH/classes/controller/public/category.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(7): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(80): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 04:00:05 --- ERROR: ErrorException [ 8 ]: Undefined variable: cat_isset ~ APPPATH/classes/controller/public/category.php [ 7 ]
2013-08-08 04:00:05 --- STRACE: ErrorException [ 8 ]: Undefined variable: cat_isset ~ APPPATH/classes/controller/public/category.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(7): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(80): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 04:00:05 --- ERROR: ErrorException [ 8 ]: Undefined variable: cat_isset ~ APPPATH/classes/controller/public/category.php [ 7 ]
2013-08-08 04:00:05 --- STRACE: ErrorException [ 8 ]: Undefined variable: cat_isset ~ APPPATH/classes/controller/public/category.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(7): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(80): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 04:00:06 --- ERROR: ErrorException [ 8 ]: Undefined variable: cat_isset ~ APPPATH/classes/controller/public/category.php [ 7 ]
2013-08-08 04:00:06 --- STRACE: ErrorException [ 8 ]: Undefined variable: cat_isset ~ APPPATH/classes/controller/public/category.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(7): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(80): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 04:00:06 --- ERROR: ErrorException [ 8 ]: Undefined variable: cat_isset ~ APPPATH/classes/controller/public/category.php [ 7 ]
2013-08-08 04:00:06 --- STRACE: ErrorException [ 8 ]: Undefined variable: cat_isset ~ APPPATH/classes/controller/public/category.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(7): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(80): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 04:00:07 --- ERROR: ErrorException [ 8 ]: Undefined variable: cat_isset ~ APPPATH/classes/controller/public/category.php [ 7 ]
2013-08-08 04:00:07 --- STRACE: ErrorException [ 8 ]: Undefined variable: cat_isset ~ APPPATH/classes/controller/public/category.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(7): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(80): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 04:00:07 --- ERROR: ErrorException [ 8 ]: Undefined variable: cat_isset ~ APPPATH/classes/controller/public/category.php [ 7 ]
2013-08-08 04:00:07 --- STRACE: ErrorException [ 8 ]: Undefined variable: cat_isset ~ APPPATH/classes/controller/public/category.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(7): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(80): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 04:00:08 --- ERROR: ErrorException [ 8 ]: Undefined variable: cat_isset ~ APPPATH/classes/controller/public/category.php [ 7 ]
2013-08-08 04:00:08 --- STRACE: ErrorException [ 8 ]: Undefined variable: cat_isset ~ APPPATH/classes/controller/public/category.php [ 7 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(7): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 7, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(80): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 04:01:47 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/category.php [ 9 ]
2013-08-08 04:01:47 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/category.php [ 9 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(9): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 9, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(80): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 04:01:48 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/category.php [ 9 ]
2013-08-08 04:01:48 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/category.php [ 9 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(9): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 9, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(80): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 04:01:48 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/category.php [ 9 ]
2013-08-08 04:01:48 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/category.php [ 9 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(9): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 9, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(80): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 04:01:50 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/category.php [ 9 ]
2013-08-08 04:01:50 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/category.php [ 9 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(9): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 9, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(80): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 04:01:50 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/category.php [ 9 ]
2013-08-08 04:01:50 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/category.php [ 9 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(9): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 9, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(80): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 04:01:51 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/category.php [ 9 ]
2013-08-08 04:01:51 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/category.php [ 9 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(9): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 9, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(80): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 04:01:51 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/category.php [ 9 ]
2013-08-08 04:01:51 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/category.php [ 9 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(9): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 9, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(80): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 04:01:52 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/category.php [ 9 ]
2013-08-08 04:01:52 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/category.php [ 9 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(9): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 9, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(80): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 04:02:42 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/category.php [ 9 ]
2013-08-08 04:02:42 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public/category.php [ 9 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(9): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 9, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(80): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 04:04:32 --- ERROR: ErrorException [ 8 ]: Undefined index: cat_data ~ APPPATH/classes/controller/public/category.php [ 9 ]
2013-08-08 04:04:32 --- STRACE: ErrorException [ 8 ]: Undefined index: cat_data ~ APPPATH/classes/controller/public/category.php [ 9 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public/category.php(9): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 9, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(97): Controller_Public_Category->category(Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 04:38:52 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 41 ]
2013-08-08 04:38:52 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 41 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(41): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 41, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 04:45:48 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 41 ]
2013-08-08 04:45:48 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 41 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(41): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 41, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 04:54:02 --- ERROR: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/public.php [ 84 ]
2013-08-08 04:54:02 --- STRACE: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/public.php [ 84 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(84): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 84, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 04:54:56 --- ERROR: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/public.php [ 83 ]
2013-08-08 04:54:56 --- STRACE: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/public.php [ 83 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(83): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 83, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 04:56:05 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 45 ]
2013-08-08 04:56:05 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 45 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(45): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 45, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 04:58:40 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 45 ]
2013-08-08 04:58:40 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 45 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(45): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 45, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 04:59:10 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 46 ]
2013-08-08 04:59:10 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 46 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(46): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 46, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 04:59:23 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 46 ]
2013-08-08 04:59:23 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 46 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(46): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 46, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 04:59:24 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 46 ]
2013-08-08 04:59:24 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 46 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(46): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 46, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 04:59:35 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 45 ]
2013-08-08 04:59:35 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 45 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(45): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 45, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 04:59:47 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 45 ]
2013-08-08 04:59:47 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 45 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(45): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 45, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 04:59:48 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 45 ]
2013-08-08 04:59:48 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 45 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(45): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 45, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 04:59:49 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 45 ]
2013-08-08 04:59:49 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 45 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(45): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 45, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 04:59:49 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 45 ]
2013-08-08 04:59:49 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 45 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(45): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 45, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 04:59:50 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 45 ]
2013-08-08 04:59:50 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 45 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(45): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 45, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 04:59:50 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 45 ]
2013-08-08 04:59:50 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 45 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(45): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 45, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 05:05:53 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 54 ]
2013-08-08 05:05:53 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 54 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(54): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 54, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 05:05:54 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 54 ]
2013-08-08 05:05:54 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 54 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(54): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 54, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 05:05:55 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 54 ]
2013-08-08 05:05:55 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 54 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(54): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 54, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 05:05:55 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 54 ]
2013-08-08 05:05:55 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 54 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(54): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 54, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 05:05:56 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 54 ]
2013-08-08 05:05:56 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 54 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(54): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 54, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 05:05:57 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 54 ]
2013-08-08 05:05:57 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 54 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(54): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 54, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 05:05:57 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 54 ]
2013-08-08 05:05:57 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 54 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(54): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 54, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 05:05:58 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 54 ]
2013-08-08 05:05:58 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_MySQL_Result::$id ~ APPPATH/classes/controller/public.php [ 54 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(54): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 54, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 05:09:01 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' ~ APPPATH/classes/controller/public.php [ 57 ]
2013-08-08 05:09:01 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' ~ APPPATH/classes/controller/public.php [ 57 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-08 05:09:02 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' ~ APPPATH/classes/controller/public.php [ 57 ]
2013-08-08 05:09:02 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' ~ APPPATH/classes/controller/public.php [ 57 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-08 05:16:19 --- ERROR: ErrorException [ 8 ]: Undefined variable: metatags ~ APPPATH/views/public/default/index.php [ 5 ]
2013-08-08 05:16:19 --- STRACE: ErrorException [ 8 ]: Undefined variable: metatags ~ APPPATH/views/public/default/index.php [ 5 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(5): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 5, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-08 05:16:20 --- ERROR: ErrorException [ 8 ]: Undefined variable: metatags ~ APPPATH/views/public/default/index.php [ 5 ]
2013-08-08 05:16:20 --- STRACE: ErrorException [ 8 ]: Undefined variable: metatags ~ APPPATH/views/public/default/index.php [ 5 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(5): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 5, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-08 05:16:21 --- ERROR: ErrorException [ 8 ]: Undefined variable: metatags ~ APPPATH/views/public/default/index.php [ 5 ]
2013-08-08 05:16:21 --- STRACE: ErrorException [ 8 ]: Undefined variable: metatags ~ APPPATH/views/public/default/index.php [ 5 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(5): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 5, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-08 05:16:21 --- ERROR: ErrorException [ 8 ]: Undefined variable: metatags ~ APPPATH/views/public/default/index.php [ 5 ]
2013-08-08 05:16:21 --- STRACE: ErrorException [ 8 ]: Undefined variable: metatags ~ APPPATH/views/public/default/index.php [ 5 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(5): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 5, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-08 05:19:22 --- ERROR: ErrorException [ 2 ]: Illegal string offset 'page' ~ APPPATH/classes/controller/public.php [ 63 ]
2013-08-08 05:19:22 --- STRACE: ErrorException [ 2 ]: Illegal string offset 'page' ~ APPPATH/classes/controller/public.php [ 63 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(63): Kohana_Core::error_handler(2, 'Illegal string ...', '/var/www/zelora...', 63, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 05:19:23 --- ERROR: ErrorException [ 2 ]: Illegal string offset 'page' ~ APPPATH/classes/controller/public.php [ 63 ]
2013-08-08 05:19:23 --- STRACE: ErrorException [ 2 ]: Illegal string offset 'page' ~ APPPATH/classes/controller/public.php [ 63 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(63): Kohana_Core::error_handler(2, 'Illegal string ...', '/var/www/zelora...', 63, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 05:19:23 --- ERROR: ErrorException [ 2 ]: Illegal string offset 'page' ~ APPPATH/classes/controller/public.php [ 63 ]
2013-08-08 05:19:23 --- STRACE: ErrorException [ 2 ]: Illegal string offset 'page' ~ APPPATH/classes/controller/public.php [ 63 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(63): Kohana_Core::error_handler(2, 'Illegal string ...', '/var/www/zelora...', 63, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:10:58 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 58 ]
2013-08-08 06:10:58 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 58 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(58): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 58, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:11:01 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 58 ]
2013-08-08 06:11:01 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 58 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(58): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 58, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:11:02 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 58 ]
2013-08-08 06:11:02 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 58 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(58): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 58, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:11:02 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 58 ]
2013-08-08 06:11:02 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 58 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(58): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 58, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:25:11 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:25:11 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:25:12 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:25:12 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:25:34 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:25:34 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:25:38 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:25:38 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:25:38 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:25:38 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:25:43 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:25:43 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:25:43 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:25:43 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:25:44 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:25:44 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:25:44 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:25:44 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:26:30 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:26:30 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:26:30 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:26:30 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:28:42 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:28:42 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:28:43 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:28:43 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:29:15 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:29:15 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:29:15 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:29:15 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:29:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:29:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:29:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:29:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:29:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:29:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:29:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:29:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:29:24 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:29:24 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:29:24 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:29:24 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:29:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:29:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:29:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:29:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:29:50 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:29:50 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:29:51 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:29:51 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:29:52 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:29:52 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:29:52 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:29:52 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:29:52 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:29:52 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:29:52 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:29:52 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:29:53 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:29:53 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:30:17 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:30:17 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:30:17 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:30:17 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:30:18 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:30:18 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:30:19 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:30:19 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:30:19 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:30:19 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:30:19 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:30:19 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:30:19 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:30:19 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:30:20 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:30:20 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:30:20 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:30:20 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:30:20 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:30:20 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:30:32 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:30:32 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:30:32 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:30:32 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:30:32 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:30:32 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:30:32 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:30:32 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:30:48 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:30:48 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:30:48 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:30:48 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:30:50 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:30:50 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:30:51 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:30:51 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:30:51 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:30:51 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:30:51 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:30:51 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:30:52 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:30:52 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:30:52 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:30:52 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:30:52 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:30:52 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:30:52 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:30:52 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:31:09 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:31:09 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:31:10 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:31:10 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:31:10 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:31:10 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:31:11 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:31:11 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:31:11 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:31:11 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:31:11 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:31:11 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:31:11 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:31:11 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:31:12 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:31:12 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:32:34 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:32:34 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:32:34 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:32:34 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:32:35 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:32:35 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:32:35 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:32:35 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:32:35 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:32:35 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:32:35 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:32:35 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:32:35 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:32:35 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:32:35 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:32:35 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:32:35 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:32:35 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:32:36 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:32:36 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:32:36 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:32:36 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:32:36 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:32:36 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:32:36 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:32:36 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:32:36 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:32:36 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:32:36 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:32:36 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:32:55 --- ERROR: ErrorException [ 8 ]: Undefined variable: cat_check ~ APPPATH/classes/controller/public.php [ 17 ]
2013-08-08 06:32:55 --- STRACE: ErrorException [ 8 ]: Undefined variable: cat_check ~ APPPATH/classes/controller/public.php [ 17 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(17): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 17, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:32:55 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:32:55 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:33:22 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:33:22 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:33:22 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:33:22 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:33:23 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:33:23 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:33:23 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:33:23 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:33:24 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:33:24 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:33:24 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:33:24 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:34:29 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:29 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:29 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:34:29 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:34:30 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:30 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:30 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:34:30 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:34:30 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:30 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:31 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:34:31 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:34:31 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:31 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:31 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:34:31 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:34:31 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:31 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:32 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:34:32 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:34:32 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:32 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:32 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:34:32 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:34:32 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:32 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:33 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:34:33 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:34:33 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:33 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:33 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:34:33 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:34:33 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:33 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:33 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:34:33 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:34:34 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:34 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:34 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:34:34 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:34:35 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:35 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:35 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:34:35 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:34:36 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:36 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:36 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:34:36 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:34:36 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:36 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:37 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:34:37 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:34:37 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:37 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:37 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:37 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:37 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:37 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:37 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:37 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:37 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:34:37 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:34:37 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:34:37 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:34:38 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:38 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:38 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:34:38 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:34:38 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:38 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:38 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:34:38 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:34:38 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:38 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:39 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:39 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:39 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:39 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:39 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:39 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:39 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:39 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:39 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:39 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:39 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:39 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:39 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:39 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:39 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:39 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:39 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:39 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:39 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:39 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:39 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:39 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:39 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:39 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:39 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:39 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:39 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:39 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:39 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:34:39 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:34:40 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:34:40 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:35:58 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:35:58 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:35:58 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:35:58 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:35:58 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:35:58 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:35:59 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:35:59 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:35:59 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:35:59 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:35:59 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 06:35:59 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:36:22 --- ERROR: ErrorException [ 8 ]: Undefined variable: breadcrumbs ~ APPPATH/views/public/default/page.php [ 1 ]
2013-08-08 06:36:22 --- STRACE: ErrorException [ 8 ]: Undefined variable: breadcrumbs ~ APPPATH/views/public/default/page.php [ 1 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/page.php(1): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 1, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(50): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-08-08 06:36:55 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:36:55 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:36:55 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-08 06:36:55 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:36:56 --- ERROR: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
2013-08-08 06:36:56 --- STRACE: ErrorException [ 8 ]: Undefined index: cid ~ APPPATH/classes/helper/public.php [ 19 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(19): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 19, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:36:56 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-08 06:36:56 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:37:38 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
2013-08-08 06:37:38 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 23 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(23): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 23, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:37:38 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-08 06:37:38 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:45:54 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 40 ]
2013-08-08 06:45:54 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 40 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(40): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 40, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:45:54 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-08 06:45:54 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:45:55 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 40 ]
2013-08-08 06:45:55 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 40 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(40): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 40, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:45:55 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-08 06:45:55 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:45:56 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 40 ]
2013-08-08 06:45:56 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 40 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(40): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 40, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:45:56 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-08 06:45:56 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:45:56 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 40 ]
2013-08-08 06:45:56 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 40 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(40): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 40, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:45:57 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-08 06:45:57 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:46:21 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 40 ]
2013-08-08 06:46:21 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/helper/public.php [ 40 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(40): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 40, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(147): Helper_Public::breadcrumbs('page', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:47:48 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-08 06:47:48 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:48:06 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-08 06:48:06 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:48:24 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-08 06:48:24 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:48:33 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-08 06:48:33 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:48:37 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-08 06:48:37 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:48:39 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-08 06:48:39 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:48:39 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-08 06:48:39 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:48:41 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-08 06:48:41 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:49:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-08 06:49:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:49:21 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-08 06:49:21 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:50:00 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
2013-08-08 06:50:00 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 141 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(141): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 141, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:51:32 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:51:32 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:51:35 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:51:35 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:51:37 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:51:37 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:51:37 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:51:37 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:53:24 --- ERROR: ErrorException [ 8 ]: Undefined index: uset ~ APPPATH/classes/helper/public.php [ 44 ]
2013-08-08 06:53:24 --- STRACE: ErrorException [ 8 ]: Undefined index: uset ~ APPPATH/classes/helper/public.php [ 44 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/helper/public.php(44): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 44, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(146): Helper_Public::breadcrumbs('index', Array)
#2 [internal function]: Controller_Public->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-08 06:53:24 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:53:24 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:54:13 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:54:13 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:54:45 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:54:45 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:54:45 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:54:45 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:55:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:55:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:55:27 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:55:27 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:57:55 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:57:55 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:57:57 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:57:57 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:57:58 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:57:58 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:57:58 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:57:58 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:57:59 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:57:59 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:58:30 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:58:30 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:58:31 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:58:31 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:58:32 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:58:32 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:58:33 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:58:33 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:58:57 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:58:57 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:58:57 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:58:57 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:58:57 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:58:57 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:58:58 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:58:58 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:58:58 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:58:58 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:58:58 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:58:58 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:58:59 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:58:59 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:58:59 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:58:59 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 06:58:59 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 06:58:59 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:00:47 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 07:00:47 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:00:48 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 07:00:48 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:01:33 --- ERROR: ErrorException [ 8 ]: Undefined variable: bread ~ APPPATH/views/public/default/system/breadcrumbs.php [ 4 ]
2013-08-08 07:01:33 --- STRACE: ErrorException [ 8 ]: Undefined variable: bread ~ APPPATH/views/public/default/system/breadcrumbs.php [ 4 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/system/breadcrumbs.php(4): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 4, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/page.php(1): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#8 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(50): Kohana_View->__toString()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#12 [internal function]: Kohana_Controller_Template->after()
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#14 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#15 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#16 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#17 {main}
2013-08-08 07:01:34 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 07:01:34 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:02:03 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/public/default/system/breadcrumbs.php [ 4 ]
2013-08-08 07:02:03 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/public/default/system/breadcrumbs.php [ 4 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/system/breadcrumbs.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', '/var/www/zelora...', 4, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/page.php(1): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#8 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(50): Kohana_View->__toString()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#12 [internal function]: Kohana_Controller_Template->after()
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#14 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#15 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#16 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#17 {main}
2013-08-08 07:02:04 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 07:02:04 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:02:15 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/public/default/system/breadcrumbs.php [ 4 ]
2013-08-08 07:02:15 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/public/default/system/breadcrumbs.php [ 4 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/system/breadcrumbs.php(4): Kohana_Core::error_handler(2, 'Invalid argumen...', '/var/www/zelora...', 4, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/page.php(1): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#8 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(50): Kohana_View->__toString()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#12 [internal function]: Kohana_Controller_Template->after()
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Public))
#14 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#15 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#16 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#17 {main}
2013-08-08 07:02:15 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 07:02:15 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:02:48 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 07:02:48 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:02:51 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 07:02:51 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:04:18 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 07:04:18 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:04:19 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 07:04:19 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:04:20 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
2013-08-08 07:04:20 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 143 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(143): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 143, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:12:03 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:12:03 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:12:04 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:12:04 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:12:05 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:12:05 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:12:06 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:12:06 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:12:06 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:12:06 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:12:07 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:12:07 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:12:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:12:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:12:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:12:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:12:09 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:12:09 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:12:19 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:12:19 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:14:00 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:14:00 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:14:01 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:14:01 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:14:02 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:14:02 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:14:03 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:14:03 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:14:05 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:14:05 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:14:06 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:14:06 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:14:07 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:14:07 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:14:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:14:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:14:11 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:14:11 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:14:13 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:14:13 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:14:15 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:14:15 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:14:15 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:14:15 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:14:21 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:14:21 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:17:47 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:17:47 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:18:02 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:18:02 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:18:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:18:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:18:09 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:18:09 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:18:53 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:18:53 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:19:30 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:19:30 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:19:31 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:19:31 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:19:31 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:19:31 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:20:03 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:20:03 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:20:03 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:20:03 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:20:09 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:20:09 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:20:09 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:20:09 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:20:10 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:20:10 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:20:10 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:20:10 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:20:12 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:20:12 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:20:12 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:20:12 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:20:13 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:20:13 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:20:13 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:20:13 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:20:14 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:20:14 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:20:14 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:20:14 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:20:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:20:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:20:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:20:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:20:18 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:20:18 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:20:19 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:20:19 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:20:21 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:20:21 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:20:21 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:20:21 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:20:21 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:20:21 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:20:22 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:20:22 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:20:24 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:20:24 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:20:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:20:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:41:41 --- ERROR: ErrorException [ 8 ]: Undefined variable: metatags ~ APPPATH/views/public/default/index.php [ 5 ]
2013-08-08 07:41:41 --- STRACE: ErrorException [ 8 ]: Undefined variable: metatags ~ APPPATH/views/public/default/index.php [ 5 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(5): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 5, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-08 07:41:42 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:41:42 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:41:42 --- ERROR: ErrorException [ 8 ]: Undefined variable: metatags ~ APPPATH/views/public/default/index.php [ 5 ]
2013-08-08 07:41:42 --- STRACE: ErrorException [ 8 ]: Undefined variable: metatags ~ APPPATH/views/public/default/index.php [ 5 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(5): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 5, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-08 07:41:42 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:41:42 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:43:26 --- ERROR: View_Exception [ 0 ]: The requested view admin could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
2013-08-08 07:43:26 --- STRACE: View_Exception [ 0 ]: The requested view admin could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(137): Kohana_View->set_filename('admin')
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(30): Kohana_View->__construct('admin', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(33): Kohana_View::factory('admin')
#3 [internal function]: Kohana_Controller_Template->before()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-08-08 07:43:27 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:43:27 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:43:27 --- ERROR: View_Exception [ 0 ]: The requested view admin could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
2013-08-08 07:43:27 --- STRACE: View_Exception [ 0 ]: The requested view admin could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(137): Kohana_View->set_filename('admin')
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(30): Kohana_View->__construct('admin', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(33): Kohana_View::factory('admin')
#3 [internal function]: Kohana_Controller_Template->before()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-08-08 07:43:28 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:43:28 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:46:37 --- ERROR: View_Exception [ 0 ]: The requested view admin could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
2013-08-08 07:46:37 --- STRACE: View_Exception [ 0 ]: The requested view admin could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(137): Kohana_View->set_filename('admin')
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(30): Kohana_View->__construct('admin', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(33): Kohana_View::factory('admin')
#3 [internal function]: Kohana_Controller_Template->before()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-08-08 07:46:37 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:46:37 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:46:38 --- ERROR: View_Exception [ 0 ]: The requested view admin could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
2013-08-08 07:46:38 --- STRACE: View_Exception [ 0 ]: The requested view admin could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(137): Kohana_View->set_filename('admin')
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(30): Kohana_View->__construct('admin', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(33): Kohana_View::factory('admin')
#3 [internal function]: Kohana_Controller_Template->before()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(103): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-08-08 07:46:38 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:46:38 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:47:51 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:47:51 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:55:50 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/admin/desktop.php [ 1 ]
2013-08-08 07:55:50 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/admin/desktop.php [ 1 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(1): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 1, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-08 07:55:50 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2013-08-08 07:55:50 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('session', NULL)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(202): Kohana_Cookie::get('session')
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#3 {main}
2013-08-08 07:56:45 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2013-08-08 07:56:45 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('session', NULL)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(202): Kohana_Cookie::get('session')
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#3 {main}
2013-08-08 07:56:45 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2013-08-08 07:56:45 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('session', NULL)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(202): Kohana_Cookie::get('session')
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#3 {main}
2013-08-08 07:58:42 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 07:58:42 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 07:58:48 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2013-08-08 07:58:48 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('session', NULL)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(202): Kohana_Cookie::get('session')
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#3 {main}
2013-08-08 07:58:48 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2013-08-08 07:58:48 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('session', NULL)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(202): Kohana_Cookie::get('session')
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#3 {main}
2013-08-08 07:58:49 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2013-08-08 07:58:49 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('session', NULL)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(202): Kohana_Cookie::get('session')
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#3 {main}
2013-08-08 07:58:49 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2013-08-08 07:58:49 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('session', NULL)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(202): Kohana_Cookie::get('session')
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#3 {main}
2013-08-08 07:58:50 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2013-08-08 07:58:50 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('session', NULL)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(202): Kohana_Cookie::get('session')
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#3 {main}
2013-08-08 07:58:50 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2013-08-08 07:58:50 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('session', NULL)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(202): Kohana_Cookie::get('session')
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#3 {main}
2013-08-08 07:58:51 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2013-08-08 07:58:51 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('session', NULL)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(202): Kohana_Cookie::get('session')
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#3 {main}
2013-08-08 07:58:51 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2013-08-08 07:58:51 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('session', NULL)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(202): Kohana_Cookie::get('session')
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#3 {main}
2013-08-08 07:59:35 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2013-08-08 07:59:35 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('session', NULL)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(202): Kohana_Cookie::get('session')
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#3 {main}
2013-08-08 07:59:35 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2013-08-08 07:59:35 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('session', NULL)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(202): Kohana_Cookie::get('session')
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#3 {main}
2013-08-08 07:59:36 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2013-08-08 07:59:36 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('session', NULL)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(202): Kohana_Cookie::get('session')
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#3 {main}
2013-08-08 07:59:36 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2013-08-08 07:59:36 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('session', NULL)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(202): Kohana_Cookie::get('session')
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#3 {main}
2013-08-08 07:59:36 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2013-08-08 07:59:36 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('session', NULL)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(202): Kohana_Cookie::get('session')
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#3 {main}
2013-08-08 07:59:36 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2013-08-08 07:59:36 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('session', NULL)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(202): Kohana_Cookie::get('session')
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#3 {main}
2013-08-08 07:59:37 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2013-08-08 07:59:37 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('session', NULL)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(202): Kohana_Cookie::get('session')
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#3 {main}
2013-08-08 07:59:37 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2013-08-08 07:59:37 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('session', NULL)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(202): Kohana_Cookie::get('session')
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#3 {main}
2013-08-08 07:59:37 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2013-08-08 07:59:37 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('session', NULL)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(202): Kohana_Cookie::get('session')
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#3 {main}
2013-08-08 07:59:37 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2013-08-08 07:59:37 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('session', NULL)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(202): Kohana_Cookie::get('session')
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#3 {main}
2013-08-08 08:00:13 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 08:00:13 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 08:00:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 08:00:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 08:00:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 08:00:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 08:02:44 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 08:02:44 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 08:02:45 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 08:02:45 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 08:02:45 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 08:02:45 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 08:02:46 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 08:02:46 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 08:02:46 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 08:02:46 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 08:03:06 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 08:03:06 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 08:03:07 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 08:03:07 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 08:03:18 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 08:03:18 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 08:03:19 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 08:03:19 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 08:03:19 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 08:03:19 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 08:03:19 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 08:03:19 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 08:03:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 08:03:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 08:03:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 08:03:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 08:03:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 08:03:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 08:03:32 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 08:03:32 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 08:03:33 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 08:03:33 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 08:03:33 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 08:03:33 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 08:03:44 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin/auth was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-08 08:03:44 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin/auth was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-08 08:03:44 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 08:03:44 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 08:07:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 08:07:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 08:07:09 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 08:07:09 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 08:07:10 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 08:07:10 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 08:07:10 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 08:07:10 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 08:07:12 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 08:07:12 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 08:08:07 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 08:08:07 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 08:08:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 08:08:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 08:23:57 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 08:23:57 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 09:21:23 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 09:21:23 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 09:50:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 09:50:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 12:29:42 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 12:29:42 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 12:29:46 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 12:29:46 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 12:39:50 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 12:39:50 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 12:49:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 12:49:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 13:41:40 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 13:41:40 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 14:57:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 14:57:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 15:05:45 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 15:05:45 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 15:30:09 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 15:30:09 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 15:59:01 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 15:59:01 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 19:05:21 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 19:05:21 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 20:19:21 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 20:19:21 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 20:40:47 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 20:40:47 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-08 20:50:06 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-08 20:50:06 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}