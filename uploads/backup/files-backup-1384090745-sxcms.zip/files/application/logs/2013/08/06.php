<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2013-08-06 18:22:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:22:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:22:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:22:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:40:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:40:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:45:08 --- ERROR: ErrorException [ 1 ]: Call to undefined method Route::set() ~ APPPATH/bootstrap.php [ 116 ]
2013-08-06 18:45:08 --- STRACE: ErrorException [ 1 ]: Call to undefined method Route::set() ~ APPPATH/bootstrap.php [ 116 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-06 18:45:08 --- ERROR: ErrorException [ 1 ]: Call to undefined method Route::set() ~ APPPATH/bootstrap.php [ 116 ]
2013-08-06 18:45:08 --- STRACE: ErrorException [ 1 ]: Call to undefined method Route::set() ~ APPPATH/bootstrap.php [ 116 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-06 18:45:09 --- ERROR: ErrorException [ 1 ]: Call to undefined method Route::set() ~ APPPATH/bootstrap.php [ 116 ]
2013-08-06 18:45:09 --- STRACE: ErrorException [ 1 ]: Call to undefined method Route::set() ~ APPPATH/bootstrap.php [ 116 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-06 18:45:09 --- ERROR: ErrorException [ 1 ]: Call to undefined method Route::set() ~ APPPATH/bootstrap.php [ 116 ]
2013-08-06 18:45:09 --- STRACE: ErrorException [ 1 ]: Call to undefined method Route::set() ~ APPPATH/bootstrap.php [ 116 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-06 18:45:09 --- ERROR: ErrorException [ 1 ]: Call to undefined method Route::set() ~ APPPATH/bootstrap.php [ 116 ]
2013-08-06 18:45:09 --- STRACE: ErrorException [ 1 ]: Call to undefined method Route::set() ~ APPPATH/bootstrap.php [ 116 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-06 18:45:09 --- ERROR: ErrorException [ 1 ]: Call to undefined method Route::set() ~ APPPATH/bootstrap.php [ 116 ]
2013-08-06 18:45:09 --- STRACE: ErrorException [ 1 ]: Call to undefined method Route::set() ~ APPPATH/bootstrap.php [ 116 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-06 18:45:09 --- ERROR: ErrorException [ 1 ]: Call to undefined method Route::set() ~ APPPATH/bootstrap.php [ 116 ]
2013-08-06 18:45:09 --- STRACE: ErrorException [ 1 ]: Call to undefined method Route::set() ~ APPPATH/bootstrap.php [ 116 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-06 18:45:09 --- ERROR: ErrorException [ 1 ]: Call to undefined method Route::set() ~ APPPATH/bootstrap.php [ 116 ]
2013-08-06 18:45:09 --- STRACE: ErrorException [ 1 ]: Call to undefined method Route::set() ~ APPPATH/bootstrap.php [ 116 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-06 18:47:13 --- ERROR: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Route::compile() must be of the type array, object given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php on line 342 and defined ~ SYSPATH/classes/kohana/route.php [ 227 ]
2013-08-06 18:47:13 --- STRACE: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Route::compile() must be of the type array, object given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php on line 342 and defined ~ SYSPATH/classes/kohana/route.php [ 227 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(227): Kohana_Core::error_handler(4096, 'Argument 2 pass...', '/var/www/zelora...', 227, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(342): Kohana_Route::compile(Object(Request), Object(Response))
#2 [internal function]: Kohana_Route->__construct(Object(Request), Object(Response))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(101): ReflectionClass->newInstance(Object(Request), Object(Response))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-06 18:47:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:47:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:47:15 --- ERROR: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Route::compile() must be of the type array, object given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php on line 342 and defined ~ SYSPATH/classes/kohana/route.php [ 227 ]
2013-08-06 18:47:15 --- STRACE: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Route::compile() must be of the type array, object given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php on line 342 and defined ~ SYSPATH/classes/kohana/route.php [ 227 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(227): Kohana_Core::error_handler(4096, 'Argument 2 pass...', '/var/www/zelora...', 227, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(342): Kohana_Route::compile(Object(Request), Object(Response))
#2 [internal function]: Kohana_Route->__construct(Object(Request), Object(Response))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(101): ReflectionClass->newInstance(Object(Request), Object(Response))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-06 18:47:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:47:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:47:42 --- ERROR: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Route::compile() must be of the type array, object given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php on line 342 and defined ~ SYSPATH/classes/kohana/route.php [ 227 ]
2013-08-06 18:47:42 --- STRACE: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Route::compile() must be of the type array, object given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php on line 342 and defined ~ SYSPATH/classes/kohana/route.php [ 227 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(227): Kohana_Core::error_handler(4096, 'Argument 2 pass...', '/var/www/zelora...', 227, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(342): Kohana_Route::compile(Object(Request), Object(Response))
#2 [internal function]: Kohana_Route->__construct(Object(Request), Object(Response))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(101): ReflectionClass->newInstance(Object(Request), Object(Response))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-06 18:47:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:47:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:47:44 --- ERROR: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Route::compile() must be of the type array, object given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php on line 342 and defined ~ SYSPATH/classes/kohana/route.php [ 227 ]
2013-08-06 18:47:44 --- STRACE: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Route::compile() must be of the type array, object given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php on line 342 and defined ~ SYSPATH/classes/kohana/route.php [ 227 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(227): Kohana_Core::error_handler(4096, 'Argument 2 pass...', '/var/www/zelora...', 227, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(342): Kohana_Route::compile(Object(Request), Object(Response))
#2 [internal function]: Kohana_Route->__construct(Object(Request), Object(Response))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(101): ReflectionClass->newInstance(Object(Request), Object(Response))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-06 18:47:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:47:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:47:44 --- ERROR: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Route::compile() must be of the type array, object given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php on line 342 and defined ~ SYSPATH/classes/kohana/route.php [ 227 ]
2013-08-06 18:47:44 --- STRACE: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Route::compile() must be of the type array, object given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php on line 342 and defined ~ SYSPATH/classes/kohana/route.php [ 227 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(227): Kohana_Core::error_handler(4096, 'Argument 2 pass...', '/var/www/zelora...', 227, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(342): Kohana_Route::compile(Object(Request), Object(Response))
#2 [internal function]: Kohana_Route->__construct(Object(Request), Object(Response))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(101): ReflectionClass->newInstance(Object(Request), Object(Response))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-06 18:47:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:47:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:47:44 --- ERROR: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Route::compile() must be of the type array, object given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php on line 342 and defined ~ SYSPATH/classes/kohana/route.php [ 227 ]
2013-08-06 18:47:44 --- STRACE: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Route::compile() must be of the type array, object given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php on line 342 and defined ~ SYSPATH/classes/kohana/route.php [ 227 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(227): Kohana_Core::error_handler(4096, 'Argument 2 pass...', '/var/www/zelora...', 227, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(342): Kohana_Route::compile(Object(Request), Object(Response))
#2 [internal function]: Kohana_Route->__construct(Object(Request), Object(Response))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(101): ReflectionClass->newInstance(Object(Request), Object(Response))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-06 18:47:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:47:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:47:45 --- ERROR: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Route::compile() must be of the type array, object given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php on line 342 and defined ~ SYSPATH/classes/kohana/route.php [ 227 ]
2013-08-06 18:47:45 --- STRACE: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Route::compile() must be of the type array, object given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php on line 342 and defined ~ SYSPATH/classes/kohana/route.php [ 227 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(227): Kohana_Core::error_handler(4096, 'Argument 2 pass...', '/var/www/zelora...', 227, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(342): Kohana_Route::compile(Object(Request), Object(Response))
#2 [internal function]: Kohana_Route->__construct(Object(Request), Object(Response))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(101): ReflectionClass->newInstance(Object(Request), Object(Response))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-06 18:47:45 --- ERROR: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Route::compile() must be of the type array, object given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php on line 342 and defined ~ SYSPATH/classes/kohana/route.php [ 227 ]
2013-08-06 18:47:45 --- STRACE: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Route::compile() must be of the type array, object given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php on line 342 and defined ~ SYSPATH/classes/kohana/route.php [ 227 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(227): Kohana_Core::error_handler(4096, 'Argument 2 pass...', '/var/www/zelora...', 227, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(342): Kohana_Route::compile(Object(Request), Object(Response))
#2 [internal function]: Kohana_Route->__construct(Object(Request), Object(Response))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(101): ReflectionClass->newInstance(Object(Request), Object(Response))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-06 18:47:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:47:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:47:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:47:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:47:45 --- ERROR: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Route::compile() must be of the type array, object given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php on line 342 and defined ~ SYSPATH/classes/kohana/route.php [ 227 ]
2013-08-06 18:47:45 --- STRACE: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Route::compile() must be of the type array, object given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php on line 342 and defined ~ SYSPATH/classes/kohana/route.php [ 227 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(227): Kohana_Core::error_handler(4096, 'Argument 2 pass...', '/var/www/zelora...', 227, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(342): Kohana_Route::compile(Object(Request), Object(Response))
#2 [internal function]: Kohana_Route->__construct(Object(Request), Object(Response))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(101): ReflectionClass->newInstance(Object(Request), Object(Response))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-06 18:47:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:47:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:47:46 --- ERROR: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Route::compile() must be of the type array, object given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php on line 342 and defined ~ SYSPATH/classes/kohana/route.php [ 227 ]
2013-08-06 18:47:46 --- STRACE: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Route::compile() must be of the type array, object given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php on line 342 and defined ~ SYSPATH/classes/kohana/route.php [ 227 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(227): Kohana_Core::error_handler(4096, 'Argument 2 pass...', '/var/www/zelora...', 227, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(342): Kohana_Route::compile(Object(Request), Object(Response))
#2 [internal function]: Kohana_Route->__construct(Object(Request), Object(Response))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(101): ReflectionClass->newInstance(Object(Request), Object(Response))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-06 18:47:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:47:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:47:47 --- ERROR: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Route::compile() must be of the type array, object given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php on line 342 and defined ~ SYSPATH/classes/kohana/route.php [ 227 ]
2013-08-06 18:47:47 --- STRACE: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Route::compile() must be of the type array, object given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php on line 342 and defined ~ SYSPATH/classes/kohana/route.php [ 227 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(227): Kohana_Core::error_handler(4096, 'Argument 2 pass...', '/var/www/zelora...', 227, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(342): Kohana_Route::compile(Object(Request), Object(Response))
#2 [internal function]: Kohana_Route->__construct(Object(Request), Object(Response))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(101): ReflectionClass->newInstance(Object(Request), Object(Response))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-06 18:47:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:47:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:47:47 --- ERROR: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Route::compile() must be of the type array, object given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php on line 342 and defined ~ SYSPATH/classes/kohana/route.php [ 227 ]
2013-08-06 18:47:47 --- STRACE: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Route::compile() must be of the type array, object given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php on line 342 and defined ~ SYSPATH/classes/kohana/route.php [ 227 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(227): Kohana_Core::error_handler(4096, 'Argument 2 pass...', '/var/www/zelora...', 227, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(342): Kohana_Route::compile(Object(Request), Object(Response))
#2 [internal function]: Kohana_Route->__construct(Object(Request), Object(Response))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(101): ReflectionClass->newInstance(Object(Request), Object(Response))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-06 18:47:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:47:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:47:48 --- ERROR: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Route::compile() must be of the type array, object given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php on line 342 and defined ~ SYSPATH/classes/kohana/route.php [ 227 ]
2013-08-06 18:47:48 --- STRACE: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Route::compile() must be of the type array, object given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php on line 342 and defined ~ SYSPATH/classes/kohana/route.php [ 227 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(227): Kohana_Core::error_handler(4096, 'Argument 2 pass...', '/var/www/zelora...', 227, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(342): Kohana_Route::compile(Object(Request), Object(Response))
#2 [internal function]: Kohana_Route->__construct(Object(Request), Object(Response))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(101): ReflectionClass->newInstance(Object(Request), Object(Response))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-06 18:47:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:47:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:47:49 --- ERROR: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Route::compile() must be of the type array, object given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php on line 342 and defined ~ SYSPATH/classes/kohana/route.php [ 227 ]
2013-08-06 18:47:49 --- STRACE: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Route::compile() must be of the type array, object given, called in /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php on line 342 and defined ~ SYSPATH/classes/kohana/route.php [ 227 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(227): Kohana_Core::error_handler(4096, 'Argument 2 pass...', '/var/www/zelora...', 227, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(342): Kohana_Route::compile(Object(Request), Object(Response))
#2 [internal function]: Kohana_Route->__construct(Object(Request), Object(Response))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(101): ReflectionClass->newInstance(Object(Request), Object(Response))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-08-06 18:47:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:47:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:48:05 --- ERROR: View_Exception [ 0 ]: The requested view basic could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
2013-08-06 18:48:05 --- STRACE: View_Exception [ 0 ]: The requested view basic could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(137): Kohana_View->set_filename('basic')
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(30): Kohana_View->__construct('basic', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(33): Kohana_View::factory('basic')
#3 [internal function]: Kohana_Controller_Template->before()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(103): ReflectionMethod->invoke(Object(Controller_Welcome))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-08-06 18:48:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:48:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:48:06 --- ERROR: View_Exception [ 0 ]: The requested view basic could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
2013-08-06 18:48:06 --- STRACE: View_Exception [ 0 ]: The requested view basic could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(137): Kohana_View->set_filename('basic')
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(30): Kohana_View->__construct('basic', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(33): Kohana_View::factory('basic')
#3 [internal function]: Kohana_Controller_Template->before()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(103): ReflectionMethod->invoke(Object(Controller_Welcome))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-08-06 18:48:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:48:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:48:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:48:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:48:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:48:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:48:56 --- ERROR: ErrorException [ 1 ]: Class 'Routepath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
2013-08-06 18:48:56 --- STRACE: ErrorException [ 1 ]: Class 'Routepath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-06 18:48:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:48:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:48:56 --- ERROR: ErrorException [ 1 ]: Class 'Routepath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
2013-08-06 18:48:56 --- STRACE: ErrorException [ 1 ]: Class 'Routepath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-06 18:48:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:48:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:48:57 --- ERROR: ErrorException [ 1 ]: Class 'Routepath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
2013-08-06 18:48:57 --- STRACE: ErrorException [ 1 ]: Class 'Routepath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-06 18:48:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:48:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:48:57 --- ERROR: ErrorException [ 1 ]: Class 'Routepath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
2013-08-06 18:48:57 --- STRACE: ErrorException [ 1 ]: Class 'Routepath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-06 18:48:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:48:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:48:57 --- ERROR: ErrorException [ 1 ]: Class 'Routepath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
2013-08-06 18:48:57 --- STRACE: ErrorException [ 1 ]: Class 'Routepath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-06 18:48:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:48:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:48:58 --- ERROR: ErrorException [ 1 ]: Class 'Routepath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
2013-08-06 18:48:58 --- STRACE: ErrorException [ 1 ]: Class 'Routepath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-06 18:48:58 --- ERROR: ErrorException [ 1 ]: Class 'Routepath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
2013-08-06 18:48:58 --- STRACE: ErrorException [ 1 ]: Class 'Routepath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-06 18:48:58 --- ERROR: ErrorException [ 1 ]: Class 'Routepath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
2013-08-06 18:48:58 --- STRACE: ErrorException [ 1 ]: Class 'Routepath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-06 18:48:58 --- ERROR: ErrorException [ 1 ]: Class 'Routepath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
2013-08-06 18:48:58 --- STRACE: ErrorException [ 1 ]: Class 'Routepath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-06 18:48:58 --- ERROR: ErrorException [ 1 ]: Class 'Routepath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
2013-08-06 18:48:58 --- STRACE: ErrorException [ 1 ]: Class 'Routepath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-06 18:48:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:48:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:48:58 --- ERROR: ErrorException [ 1 ]: Class 'Routepath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
2013-08-06 18:48:58 --- STRACE: ErrorException [ 1 ]: Class 'Routepath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-06 18:48:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:48:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:48:59 --- ERROR: ErrorException [ 1 ]: Class 'Routepath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
2013-08-06 18:48:59 --- STRACE: ErrorException [ 1 ]: Class 'Routepath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-06 18:48:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:48:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:49:07 --- ERROR: ErrorException [ 1 ]: Class 'RoutePath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
2013-08-06 18:49:07 --- STRACE: ErrorException [ 1 ]: Class 'RoutePath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-06 18:49:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:49:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:49:08 --- ERROR: ErrorException [ 1 ]: Class 'RoutePath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
2013-08-06 18:49:08 --- STRACE: ErrorException [ 1 ]: Class 'RoutePath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-06 18:49:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:49:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:49:08 --- ERROR: ErrorException [ 1 ]: Class 'RoutePath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
2013-08-06 18:49:08 --- STRACE: ErrorException [ 1 ]: Class 'RoutePath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-06 18:49:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:49:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:49:09 --- ERROR: ErrorException [ 1 ]: Class 'RoutePath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
2013-08-06 18:49:09 --- STRACE: ErrorException [ 1 ]: Class 'RoutePath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-06 18:49:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:49:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:49:09 --- ERROR: ErrorException [ 1 ]: Class 'RoutePath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
2013-08-06 18:49:09 --- STRACE: ErrorException [ 1 ]: Class 'RoutePath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-06 18:49:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:49:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:49:09 --- ERROR: ErrorException [ 1 ]: Class 'RoutePath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
2013-08-06 18:49:09 --- STRACE: ErrorException [ 1 ]: Class 'RoutePath' not found ~ APPPATH/classes/controller/welcome.php [ 3 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-06 18:49:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:49:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 18:55:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: robots.txt ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 18:55:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: robots.txt ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:00:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:00:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:00:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:00:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:00:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:00:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:00:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:00:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:00:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:00:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:01:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:01:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:01:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:01:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:01:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:01:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:01:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:01:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:01:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:01:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:14:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: bootstrap/css/bootstrap.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:14:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: bootstrap/css/bootstrap.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:14:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: bootstrap/css/bootstrap-responsive.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:14:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: bootstrap/css/bootstrap-responsive.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:14:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:14:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:14:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: bootstrap/js/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:14:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: bootstrap/js/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:14:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:14:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:16:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: bootstrap/css/bootstrap-responsive.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:16:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: bootstrap/css/bootstrap-responsive.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:16:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:16:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/jquery.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:16:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: bootstrap/js/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:16:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: bootstrap/js/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:16:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:16:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:16:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: application/views/public/default/js/jquery-2.0.3.min.map ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:16:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: application/views/public/default/js/jquery-2.0.3.min.map ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:16:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:16:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:34:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:34:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:35:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:35:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:35:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:35:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:35:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:35:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:36:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:36:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:38:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:38:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:39:56 --- ERROR: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 34 ]
2013-08-06 19:39:56 --- STRACE: ErrorException [ 8 ]: Undefined variable: content ~ APPPATH/views/public/default/index.php [ 34 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/public/default/index.php(34): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 34, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Welcome))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-06 19:39:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:39:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:42:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:42:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 19:44:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 19:44:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:07:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: robots.txt ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:07:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: robots.txt ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:09:32 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL contacts was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:09:32 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL contacts was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:24 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:24 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:30:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:30:25 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:25 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:30:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:30:26 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:26 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:30:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:30:27 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:27 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:30:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:30:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:31 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:31 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:31 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:31 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:31 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:31 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:31 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:31 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:31 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:31 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:31 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:31 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:31 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:31 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:31 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:31 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:31 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:31 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:30:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:30:32 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:32 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:30:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:30:33 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:33 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:30:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:30:34 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:34 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:30:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:30:34 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:34 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:34 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:34 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:34 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:34 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:34 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:34 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:30:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:30:34 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:30:34 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:30:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:30:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:31:33 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:33 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:31:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:31:33 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:33 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:31:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:31:34 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:34 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:31:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:31:34 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:34 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:31:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:31:34 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:34 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:34 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:34 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:31:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:31:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:31:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:31:35 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:35 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:31:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:31:45 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:45 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:31:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:31:45 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:45 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:31:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:31:46 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:46 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:31:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:31:46 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:46 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:31:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:31:46 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:46 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:31:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:31:46 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:46 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:31:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:31:47 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:47 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:31:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:31:47 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:47 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:31:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:31:48 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:48 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:31:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:31:48 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:48 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:31:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:31:49 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:49 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:49 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:49 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:49 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:49 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:49 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:49 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:49 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:49 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:31:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:31:49 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:49 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:31:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:31:50 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:50 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:50 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:50 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:50 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:50 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:50 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:50 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:50 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:50 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:50 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:50 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:50 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:50 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:50 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:50 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:50 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:50 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:50 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:50 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:50 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:50 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:50 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:50 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:50 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:50 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:50 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:50 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:50 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:50 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:50 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:50 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:50 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:50 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:50 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:50 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:31:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:31:51 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:51 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:31:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:31:51 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:51 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:51 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:51 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:51 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:51 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:51 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:51 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:51 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:51 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:51 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:51 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:51 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:51 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:51 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:51 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:51 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:51 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:31:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:31:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:31:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:31:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:31:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:31:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:31:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:31:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:31:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:32:17 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:32:17 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:32:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:32:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:32:18 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:32:18 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:32:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:32:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:32:18 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:32:18 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:32:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:32:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:32:18 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:32:18 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:32:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:32:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:32:19 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:32:19 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:32:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:32:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:34:15 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:34:15 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:35:27 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:35:27 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:35:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:35:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:35:31 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:35:31 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:35:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:35:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:35:35 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:35:35 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:35:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:35:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:35:35 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:35:35 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:35:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:35:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:35:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:35:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:35:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:35:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:36:04 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:36:04 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:36:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:36:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:36:05 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:36:05 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:36:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:36:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:36:06 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:36:06 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:36:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:36:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:36:06 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:36:06 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:36:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:36:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:36:21 --- ERROR: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 16 ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 20:36:21 --- STRACE: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 16 ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): C...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('#^(?:admin(?:(?...', '', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 20:36:21 --- ERROR: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 16 ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 20:36:21 --- STRACE: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 16 ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): C...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('#^(?:admin(?:(?...', 'favicon.ico', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('favicon.ico')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('favicon.ico', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/favicon.ico', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 20:36:22 --- ERROR: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 16 ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 20:36:22 --- STRACE: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 16 ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): C...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('#^(?:admin(?:(?...', '', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 20:36:22 --- ERROR: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 16 ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 20:36:22 --- STRACE: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 16 ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): C...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('#^(?:admin(?:(?...', 'favicon.ico', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('favicon.ico')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('favicon.ico', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/favicon.ico', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 20:36:23 --- ERROR: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 16 ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 20:36:23 --- STRACE: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 16 ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): C...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('#^(?:admin(?:(?...', '', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 20:36:23 --- ERROR: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 16 ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 20:36:23 --- STRACE: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 16 ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): C...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('#^(?:admin(?:(?...', 'favicon.ico', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('favicon.ico')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('favicon.ico', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/favicon.ico', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 20:36:23 --- ERROR: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 16 ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 20:36:23 --- STRACE: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 16 ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): C...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('#^(?:admin(?:(?...', '', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 20:36:23 --- ERROR: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 16 ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 20:36:23 --- STRACE: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 16 ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): C...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('#^(?:admin(?:(?...', 'favicon.ico', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('favicon.ico')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('favicon.ico', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/favicon.ico', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 20:36:23 --- ERROR: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 16 ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 20:36:23 --- STRACE: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 16 ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): C...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('#^(?:admin(?:(?...', '', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 20:36:23 --- ERROR: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 16 ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 20:36:23 --- STRACE: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 16 ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): C...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('#^(?:admin(?:(?...', 'favicon.ico', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('favicon.ico')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('favicon.ico', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/favicon.ico', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 20:36:24 --- ERROR: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 16 ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 20:36:24 --- STRACE: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 16 ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): C...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('#^(?:admin(?:(?...', '', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 20:36:24 --- ERROR: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 16 ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 20:36:24 --- STRACE: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 16 ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): C...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('#^(?:admin(?:(?...', 'favicon.ico', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('favicon.ico')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('favicon.ico', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/favicon.ico', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 20:36:35 --- ERROR: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 20:36:35 --- STRACE: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): C...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('#^(?:admin(?P</...', '', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 20:36:36 --- ERROR: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 20:36:36 --- STRACE: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): C...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('#^(?:admin(?P</...', 'favicon.ico', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('favicon.ico')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('favicon.ico', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/favicon.ico', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 20:36:36 --- ERROR: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 20:36:36 --- STRACE: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): C...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('#^(?:admin(?P</...', '', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 20:36:36 --- ERROR: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 20:36:36 --- STRACE: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): C...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('#^(?:admin(?P</...', 'favicon.ico', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('favicon.ico')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('favicon.ico', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/favicon.ico', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 20:36:37 --- ERROR: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 20:36:37 --- STRACE: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): C...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('#^(?:admin(?P</...', '', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 20:36:37 --- ERROR: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 20:36:37 --- STRACE: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): C...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('#^(?:admin(?P</...', 'favicon.ico', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('favicon.ico')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('favicon.ico', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/favicon.ico', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 20:36:37 --- ERROR: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 20:36:37 --- STRACE: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): C...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('#^(?:admin(?P</...', '', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 20:36:37 --- ERROR: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 20:36:37 --- STRACE: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): C...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('#^(?:admin(?P</...', 'favicon.ico', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('favicon.ico')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('favicon.ico', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/favicon.ico', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 20:36:37 --- ERROR: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 20:36:37 --- STRACE: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): C...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('#^(?:admin(?P</...', '', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 20:36:37 --- ERROR: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 20:36:37 --- STRACE: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): C...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('#^(?:admin(?P</...', 'favicon.ico', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('favicon.ico')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('favicon.ico', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/favicon.ico', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 20:36:37 --- ERROR: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 20:36:37 --- STRACE: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): C...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('#^(?:admin(?P</...', '', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 20:36:38 --- ERROR: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 20:36:38 --- STRACE: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): C...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('#^(?:admin(?P</...', 'favicon.ico', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('favicon.ico')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('favicon.ico', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/favicon.ico', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 20:36:38 --- ERROR: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 20:36:38 --- STRACE: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): C...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('#^(?:admin(?P</...', '', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 20:36:38 --- ERROR: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 20:36:38 --- STRACE: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): C...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('#^(?:admin(?P</...', 'favicon.ico', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('favicon.ico')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('favicon.ico', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/favicon.ico', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 20:36:38 --- ERROR: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 20:36:38 --- STRACE: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): C...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('#^(?:admin(?P</...', '', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 20:36:38 --- ERROR: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 20:36:38 --- STRACE: ErrorException [ 2 ]: preg_match(): Compilation failed: syntax error in subpattern name (missing terminator) at offset 13 ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): C...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('#^(?:admin(?P</...', 'favicon.ico', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('favicon.ico')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('favicon.ico', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/favicon.ico', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 20:37:12 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:37:12 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:37:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:37:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:37:13 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:37:13 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:37:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:37:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:37:13 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:37:13 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:37:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:37:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:37:14 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:37:14 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:37:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:37:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:37:14 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:37:14 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:37:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:37:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:37:14 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:37:14 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:37:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:37:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:37:15 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:37:15 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:37:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:37:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:37:15 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:37:15 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:37:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:37:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:37:22 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:37:22 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:37:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:37:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:37:47 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:37:47 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:37:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:37:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:37:48 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:37:48 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:37:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:37:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:37:49 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:37:49 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:37:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:37:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:39:50 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:50 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:39:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:39:50 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:50 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:39:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:39:51 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:51 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:39:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:39:51 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:51 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:39:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:39:51 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:51 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:39:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:39:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:39:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:39:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:39:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:39:54 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:54 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:54 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:54 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:54 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:54 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:54 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:54 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:54 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:54 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:54 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:54 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:54 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:54 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:54 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:54 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:54 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:54 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:54 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:54 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:54 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:54 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:54 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:54 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:54 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:54 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:54 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:54 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:54 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:54 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:54 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:54 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:54 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:54 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:54 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:54 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:54 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:54 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:54 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:39:54 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL admin was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:39:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:39:57 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2013-08-06 20:39:57 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL / was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:39:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:39:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:40:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:40:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:40:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:40:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:40:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:40:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:40:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:40:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:40:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:40:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:40:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:40:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:40:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:40:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:40:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:40:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:41:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:41:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:41:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:41:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:41:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:41:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:41:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:41:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:41:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:41:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:44:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:44:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:44:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:44:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:44:58 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL category was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
2013-08-06 20:44:58 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL category was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 111 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#3 {main}
2013-08-06 20:44:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:44:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:50:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:50:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:50:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: category/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:50:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: category/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:50:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:50:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:51:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:51:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:57:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: category ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:57:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: category ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:57:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:57:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:57:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: category ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:57:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: category ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:57:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:57:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:57:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: category ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:57:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: category ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:57:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:57:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:57:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: category ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:57:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: category ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:57:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:57:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:57:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: category ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:57:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: category ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:57:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:57:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:57:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI:  ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:57:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI:  ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 20:57:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 20:57:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:03:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI:  ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:03:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI:  ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:03:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:03:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:03:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI:  ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:03:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI:  ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:03:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:03:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:03:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI:  ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:03:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI:  ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:03:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:03:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:03:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:03:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:03:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:03:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:03:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:03:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:03:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:03:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:03:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:03:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:03:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:03:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:03:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:03:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:04:05 --- ERROR: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 21:04:05 --- STRACE: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): E...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('', 'asd/asd', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('asd/asd')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('asd/asd', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/asd/asd', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 21:04:05 --- ERROR: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 21:04:05 --- STRACE: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): E...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('', 'favicon.ico', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('favicon.ico')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('favicon.ico', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/favicon.ico', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 21:04:06 --- ERROR: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 21:04:06 --- STRACE: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): E...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('', 'asd/asd', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('asd/asd')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('asd/asd', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/asd/asd', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 21:04:06 --- ERROR: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 21:04:06 --- STRACE: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): E...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('', 'favicon.ico', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('favicon.ico')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('favicon.ico', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/favicon.ico', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 21:04:06 --- ERROR: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 21:04:06 --- STRACE: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): E...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('', 'asd/asd', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('asd/asd')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('asd/asd', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/asd/asd', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 21:04:07 --- ERROR: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 21:04:07 --- STRACE: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): E...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('', 'favicon.ico', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('favicon.ico')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('favicon.ico', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/favicon.ico', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 21:04:07 --- ERROR: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 21:04:07 --- STRACE: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): E...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('', 'asd/asd', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('asd/asd')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('asd/asd', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/asd/asd', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 21:04:07 --- ERROR: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 21:04:07 --- STRACE: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): E...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('', 'favicon.ico', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('favicon.ico')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('favicon.ico', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/favicon.ico', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 21:04:07 --- ERROR: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 21:04:07 --- STRACE: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): E...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('', 'asd/asd', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('asd/asd')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('asd/asd', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/asd/asd', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 21:04:07 --- ERROR: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 21:04:07 --- STRACE: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): E...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('', 'favicon.ico', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('favicon.ico')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('favicon.ico', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/favicon.ico', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 21:04:08 --- ERROR: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 21:04:08 --- STRACE: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): E...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('', 'asd/asd', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('asd/asd')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('asd/asd', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/asd/asd', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 21:04:08 --- ERROR: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 21:04:08 --- STRACE: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): E...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('', 'favicon.ico', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('favicon.ico')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('favicon.ico', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/favicon.ico', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 21:04:08 --- ERROR: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 21:04:08 --- STRACE: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): E...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('', 'asd/asd', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('asd/asd')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('asd/asd', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/asd/asd', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 21:04:08 --- ERROR: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 21:04:08 --- STRACE: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): E...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('', 'asd/asd', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('asd/asd')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('asd/asd', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/asd/asd', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 21:04:08 --- ERROR: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 21:04:08 --- STRACE: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): E...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('', 'asd/asd', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('asd/asd')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('asd/asd', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/asd/asd', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 21:04:08 --- ERROR: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 21:04:08 --- STRACE: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): E...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('', 'asd/asd', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('asd/asd')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('asd/asd', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/asd/asd', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 21:04:08 --- ERROR: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 21:04:08 --- STRACE: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): E...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('', 'asd/asd', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('asd/asd')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('asd/asd', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/asd/asd', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 21:04:08 --- ERROR: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 21:04:08 --- STRACE: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): E...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('', 'asd/asd', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('asd/asd')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('asd/asd', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/asd/asd', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 21:04:08 --- ERROR: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 21:04:08 --- STRACE: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): E...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('', 'asd/asd', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('asd/asd')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('asd/asd', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/asd/asd', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 21:04:08 --- ERROR: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 21:04:08 --- STRACE: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): E...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('', 'asd/asd', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('asd/asd')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('asd/asd', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/asd/asd', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 21:04:08 --- ERROR: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 21:04:08 --- STRACE: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): E...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('', 'asd/asd', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('asd/asd')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('asd/asd', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/asd/asd', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 21:04:08 --- ERROR: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 21:04:08 --- STRACE: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): E...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('', 'asd/asd', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('asd/asd')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('asd/asd', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/asd/asd', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 21:04:08 --- ERROR: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 21:04:08 --- STRACE: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): E...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('', 'asd/asd', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('asd/asd')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('asd/asd', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/asd/asd', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 21:04:08 --- ERROR: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 21:04:08 --- STRACE: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): E...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('', 'asd/asd', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('asd/asd')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('asd/asd', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/asd/asd', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 21:04:09 --- ERROR: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 21:04:09 --- STRACE: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): E...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('', 'asd/asd', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('asd/asd')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('asd/asd', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/asd/asd', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 21:04:09 --- ERROR: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 21:04:09 --- STRACE: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): E...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('', 'asd/asd', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('asd/asd')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('asd/asd', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/asd/asd', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 21:04:09 --- ERROR: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 21:04:09 --- STRACE: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): E...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('', 'favicon.ico', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('favicon.ico')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('favicon.ico', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/favicon.ico', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 21:04:09 --- ERROR: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 21:04:09 --- STRACE: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): E...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('', 'asd/asd', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('asd/asd')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('asd/asd', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/asd/asd', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 21:04:09 --- ERROR: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
2013-08-06 21:04:09 --- STRACE: ErrorException [ 2 ]: preg_match(): Empty regular expression ~ SYSPATH/classes/kohana/route.php [ 402 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'preg_match(): E...', '/var/www/zelora...', 402, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/route.php(402): preg_match('', 'favicon.ico', NULL)
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(582): Kohana_Route->matches('favicon.ico')
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(800): Kohana_Request::process_uri('favicon.ico', Array)
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(208): Kohana_Request->__construct('/favicon.ico', NULL, Array)
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(108): Kohana_Request::factory()
#6 {main}
2013-08-06 21:40:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:40:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:40:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd/asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 21:41:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 21:41:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 22:01:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 22:01:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 22:01:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 22:01:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 22:01:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 22:01:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: asd ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 22:01:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 22:01:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}
2013-08-06 22:08:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: robots.txt ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2013-08-06 22:08:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: robots.txt ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#1 {main}