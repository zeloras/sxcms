<?php defined('SYSPATH') or die('No direct script access.');

class Controller_Public_Page extends Ropublic {

	public function page($data)
	{
            if (sizeof($data['page']) > 0)
            {
                $meta_title = $data['page'][0]->title;
                $meta_keywords = $data['page'][0]->meta_keywords;
                $meta_description = $data['page'][0]->meta_description;

                $data_metategs = array(
                    'title' => $meta_title,
                    'keywords' => $meta_keywords,
                    'description' => $meta_description,
                );

                $this->display_tpl('page', $data, $data_metategs);
            }
            else
            {
                $this->display_error('404');
            }
	}
        

} // End Welcome
