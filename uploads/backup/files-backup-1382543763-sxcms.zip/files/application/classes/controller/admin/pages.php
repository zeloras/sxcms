<?php defined('SYSPATH') or die('No direct script access.');

class Controller_Admin_Pages extends Controller_Admin_Menus {
	public function page_list()
	{
            $data = array();
            $pages = ORM::factory('pages')->find_all();
            foreach ($pages as $key => $page)
            {
                $category_info[$key] = Helper_Common::get_category_info($page->category);
            }
            
            $data['pages'] = $pages;
            $data['category_info'] = $category_info;
            $this->display_tpl('pages/index', $data);
	}
        
        public function page_add()
        {
            $data = array();
            
            $category_model = ORM::factory('admin_categorys');
            $tree = $category_model->buildForAdmin();
            $cats = $category_model->sub_cats($tree); 
            $data['tree'] = $cats;
            $data['catTreeHTML'] = $category_model->renderCatOptList($tree);
            
            if (Arr::get($_POST, 'submit_this_form'))
            {
                $page_model = new Model_Admin_Pages();
                $page_insert = $page_model->admin_page_add();
                if (is_array($page_insert))
                {
                    $data['errors'] = $page_insert;
                }
                else
                {
                    $data['success'] = $page_insert;
                }
            }
            $this->display_tpl('pages/create', $data);
        }
        
        
        public function page_edit($id = 0)
        {
            $data = array();
            $data['page_id'] = $id;
            $data['page'] = ORM::factory('pages')->where('id', '=', $id)->find()->as_array();
            
            $category_model = ORM::factory('admin_categorys');
            $tree = $category_model->buildForAdmin();
            $cats = $category_model->sub_cats($tree); 
            $data['tree'] = $cats;
            $data['catTreeHTML'] = $category_model->renderCatOptList($tree, array('sel_cat' => $data['page']['category']));
            
            if (Arr::get($_POST, 'submit_this_form'))
            {
                $page_model = new Model_Admin_Pages();
                $page_edit = $page_model->admin_page_edit($id);
                if (is_array($page_edit))
                {
                    $data['errors'] = $page_edit;
                }
                else
                {
                    $data['success'] = $page_edit;
                }
            }
            $this->display_tpl('pages/edit', $data);
        }
        

} // End Welcome
