<?php defined('SYSPATH') or die('No direct script access.');

class Controller_Admin_Special extends Roadmin {
        
    public function ajax_delete($type, $access_code = array())
    {
        $res_varchar = 0; //Резервная переменная что бы нотисы не вылетали
        $data = array(); //Тоже самое что и выше но только массив 
        $data_my = array( //В этом массиве находятся все данные с которыми мы будем работать
            'menu' => array(
                'dbs' => 'menus',
                'cmd' => 'menu_delete',
                'row' => 'id',
                'todelete' => (in_array(34, $access_code)) ? true : false,
                'getprop' => false,
                'cycle' => array( //Указывает что у нас будет задействован цикл на вложеные массивы
                    array(
                        'spec_type' => 'menu_data', // Это название основного ключа из которого мы будем выдирать dbs
                        'spec_type_data' => 'delete', //тип действий: update - обновление данных, delete - удаление данных, update_delete - (удаление и обновление) или (обновление или удаление)
                        'first' => 'menu_id', // обычно тут мы указываем поле с которым будем работать
                    ),
                    
                    ),
                ),
            
            'users' => array(
                'dbs' => 'users',
                'cmd' => 'user_delete',
                'row' => 'id',
                'todelete' => (in_array(54, $access_code)) ? true : false,
                'getprop' => false,
                ),
            
            'menu_data' => array(
                'dbs' => 'links',
                'cmd' => 'menu_data_delete',
                'row' => 'id',
                'todelete' => (in_array(34, $access_code)) ? true : false,
                'getprop' => false,
                ),
            
            'category' => array( //Это ключ для работы с таблицей myshop_category
                'dbs' => 'categorys',
                'cmd' => 'category_delete',
                'row' => 'id',
                'todelete' => (in_array(24, $access_code)) ? true : false,
                'getprop' => false,
                'cycle' => array(
                    array( //В этом блоке мы будем работать с таблицей myshop_products 
                        'spec_type' => 'pages',
                        'spec_type_data' => 'update',
                        'first' => 'category',
                        'first_data' => '0',
                    ),
                    
                    ),
                ),
            
            'pages' => array(
                'dbs' => 'pages',
                'cmd' => 'pages_update',
                'row' => 'id',
                'todelete' => (in_array(14, $access_code)) ? true : false,
                'getprop' => false,
                ),
                        
        );
        if (sizeof($data_my[$type]) < 2) return false; // Сразу проверям что в массиве с данными минимум 2 ключа, иначе уходим
        $data[$data_my[$type]['cmd']] = true; //Заранее активируем блок с сообщениями
        $ids = Arr::get($_POST, 'ids'); //А вот тут у нас массив с id эллементов которые мы будем использовать
        if ($ids != null && $data_my[$type]['todelete'])
        {
            foreach ($ids as $id) //Запускаем цикл и обрабатываем все id
            {
                if ($id > 0) //Малоли что, пустые значения заноситься не будут а вот 0 может влезть, по этому проверям
                {
                    if ($data_my[$type]['getprop'])
                    {
                        $spec_data = ORM::factory($data_my[$type]['dbs'])
                                ->where($data_my[$type]['row'], '=', $id)
                                ->find()
                                ->as_array();
                    }

                    $delete_dbs = ORM::factory($data_my[$type]['dbs'])
                            ->where($data_my[$type]['row'], '=', $id);
                            //->find();
                    $delete_dbs_count = $delete_dbs->count_all();

                    if ($delete_dbs_count > 0)
                    {
                        $delete_dbs->where($data_my[$type]['row'], '=', $id)->find();
                        $delete_dbs->delete(); //Тут мы используем наш массив и получаем базу данных из которой мы удалим полученый из цикла ID объекта
                        $data['updated'] = true; //Допустим удаление прошло успешно и в выбранном блоке выведется сообщение о том что все хорошо
                    }
                    if (isset($data_my[$type]['cycle'])) // Тут мы проверяем существует ли ключ cycle, если да, тот помимо стандартного удаления мы будем делать что то еще
                    {
                        foreach ($data_my[$type]['cycle'] as $prop) //Запускаем цикл и собираем инфу из блоков в cycle
                        {//для примера давайте поработаем с ключём 'category'
                            if ($data_my[$type]['getprop'])
                                $speid = $spec_data[$prop['first']];
                            else
                                $speid = $id;

                            $speid = ($speid == null) ? $id : $speid;

                            if ($prop['spec_type_data'] == 'update')// Если в $data_my['category']['cycle']['spec_type_data'] - передается значение update, значит будем что то обновлять (с)кэп
                            {
                                $update_dbs = ORM::factory($data_my[$prop['spec_type']]['dbs'])
                                        ->where($prop['first'], '=', $speid);
                                        //->find();
                                $update_dbs_count = $update_dbs->count_all();
                                if ($update_dbs_count > 0)
                                {
                                    $update_dbs->where($prop['first'], '=', $speid)->find();
                                    $update_dbs->$prop['first'] = $prop['first_data'];
                                    $update_dbs->update();
                                }
                            }

                            if ($prop['spec_type_data'] == 'delete')
                            {
                                $delete_dbs = ORM::factory($data_my[$prop['spec_type']]['dbs'])->where($prop['first'], '=', $speid);
                                $delete_dbs_count = $delete_dbs->count_all();
                                if ($delete_dbs_count > 0)
                                {
                                    $delspc = $delete_dbs->where($prop['first'], '=', $speid)->find_all();
                                    foreach ($delspc as $del_spc)
                                        $del_spc->delete();
                                }
                            }
                            if ($prop['spec_type_data'] === 'update_delete') //тут мы будем работать с (удалением и обновлением) или (удалением или обновлением)
                            {
                                if (isset($prop['spec_type']['update'])) //запрашиваем есть ли у нас массив $data_my['category']['cycle']['spec_type']['update'] если нет, то и делать тут нечего 
                                {
                                    $sync = ORM::factory($data_my[$prop['spec_type']['update']]['dbs'])->where($prop['first'], 'like', "%$id,%")->find_all();
                                    foreach ($sync as $db_sync) //Если что то есть то запускаем цикл
                                    {
                                        $to_db = preg_replace('@'.$id.',@', '', $db_sync->$prop['first']);// first - у нас содержит поле category в котором данные выглядят вот так: 2,66,9 
                                        $res_varchar = $db_sync->$prop['second']; //Сразу же заносим id строки в переменную т.к если будем еще работать и с удалением нам это понадобиться 
                                        if (isset($prop['spec_type']['delete'])) //Проверям есть ли массив с ключем delete если есть, значит надо что то удалять
                                        {
                                            $delete_dbs = ORM::factory($data_my[$prop['spec_type']['delete']]['dbs'])->where($prop['secod_data'], '=', $res_varchar);
                                            $delete_dbs_count = $delete_dbs->count_all();
                                            if ($delete_dbs_count > 0)
                                            {
                                                $spcdle = $delete_dbs->where($prop['secod_data'], '=', $res_varchar)->find_all();
                                                foreach ($spcdle as $spc_dle)
                                                $spc_dle->delete();//Если есть значения то удаляем
                                            }
                                        }

                                        $special_dbs = ORM::factory($data_my[$prop['spec_type']['update']]['dbs'])->where($prop['second'], '=', $res_varchar);
                                        $special_dbs_count = $special_dbs->count_all();
                                        $special_db = $special_dbs->where($prop['second'], '=', $res_varchar)->find_all();
                                        if ($special_dbs_count > 0)
                                        {
                                            if (strlen($to_db) > 1) //Если в $to_db символов болше чем 1 то обновляем, иначе просто удаляем строку это может быть если у нас было например в поле category 66, а нам как раз и нужно было исключить 66, из объекта 
                                            {
                                                $special_dbs->$prop['first'] = $to_db;
                                                $special_dbs->update();
                                            }
                                            else
                                            {
                                                foreach ($special_db as $specialdb)
                                                $specialdb->delete();
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        else
        {
            $data['no_ids'] = true;
        }
        $this->ajax_tpl($data);
    }
    
    
    public function ajax_getCategorys_opt()
    {
        $category_model = ORM::factory('admin_categorys');
        $tree = $category_model->buildForAdmin();
        $cats = $category_model->sub_cats($tree); 
        $data['getcats'] = true;
        $data['catTreeHTML'] = $category_model->renderCatOptList($tree);
        $this->ajax_tpl($data);
    }
    
    public function ajax_getPages_opt($cid = 0)
    {
        $pages_model = ORM::factory('pages');
        $pages_model->select('category', 'title', 'id', 'cat_url', 'url');
        $pages_model->where('category', '=', $cid);
        $page_list = $pages_model->find_all();
        foreach ($page_list as $key => $page)
        {
            $pages[$key]['id'] = $page->id;
            $pages[$key]['title'] = $page->title;
            $pages[$key]['url'] = $page->cat_url.$page->url;
        }
        
        $data['getpages'] = true;
        $data['pages'] = $pages;
        $this->ajax_tpl($data);
    }
    
    public function ajax_getSystem_opt()
    {
        $data['getsystem'] = true;
        $this->ajax_tpl($data);
    }
    
    public function ajax_translit_url()
    {
        $input_text = Arr::get($_POST, 'text_translit');
        $data['text'] = Helper_Common::translit_url($input_text);
        $data['url_translit'] = true;
        $this->ajax_tpl($data);
    }
    
    public function ajax_save_position($type = '')
    {
        $positions = Arr::get($_POST, 'positions');
        $data = array(
            'menu_links' => 'links',
        );
        
        $type = $data[$type];
        if (strlen($type) < 1)
            $data['no_type'] = true;
        
        if (sizeof($positions) == 0)
            $data['no_ids'] = true;

        if ($positions) 
        {
            foreach ($positions as $pos => $id) 
            {
                $mod_model = ORM::factory($type);
                $mod_model->where('id', '=', $id);
                $mod_res = $mod_model->find();

                $mod_res->position = $pos;
                $mod_res->update();
            }
            $data['complite'] = true;
        }
        $data['save_positions'] = true;
        $this->ajax_tpl($data);
    }

}