<?php defined('SYSPATH') or die('No direct script access.');

class Controller_Admin_Users extends Controller_Admin_Roles {
	public function users_list()
	{
            $data = array();
            $users = ORM::factory('users')->find_all();
            
            $roles_users = ORM::factory('userroles')->find_all();
            foreach ($roles_users as $urole)
            {
                $roles = ORM::factory('roles')
                        ->where('id', '=', $urole->role_id)
                        ->select('id', 'title')
                        ->find()
                        ->as_array();
                $ret_roles[$urole->user_id] = $roles;
            }
            
            $data['users_roles'] = $ret_roles;
            $data['users'] = $users;
            $this->display_tpl('users/index', $data);
	}
        
        public function users_add()
        {
            $data = array();
            $data['roles'] = ORM::factory('roles')->select('id', 'title')->find_all();
            if (Arr::get($_POST, 'submit_this_form'))
            {
                $users_model = new Model_Admin_Users();
                $users_insert = $users_model->admin_users_add();
                if (is_array($users_insert))
                {
                    $data['errors'] = $users_insert;
                }
                else
                {
                    $data['success'] = $users_insert;
                }
            }
            $this->display_tpl('users/create', $data);
        }
        
        
        public function users_edit($id = 0)
        {
            $data = array();
            $data['user_id'] = $id;
            $data['user'] = ORM::factory('users')->where('id', '=', $id)->find()->as_array();
            $data['roles'] = ORM::factory('roles')->select('id', 'title')->find_all();
            $role_id = ORM::factory('userroles')->where('user_id', '=', $id)->find();
            $data['user_role'] = $role_id->role_id;
           
            if (Arr::get($_POST, 'submit_this_form'))
            {
                $users_model = new Model_Admin_Users();
                $users_edit = $users_model->admin_users_edit($id);
                if (is_array($users_edit))
                {
                    $data['errors'] = $users_edit;
                }
                else
                {
                    $data['success'] = $users_edit;
                }
            }
            $this->display_tpl('users/edit', $data);
        }
        

} // End Welcome
