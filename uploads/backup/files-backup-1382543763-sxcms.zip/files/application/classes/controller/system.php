<?php defined('SYSPATH') or die('No direct script access.');

class Controller_System extends Base {
        public $template = 'system/blank';
        
	public function action_route()
	{
            $url_segment = $this->request->param('route');
            if (preg_match('/^showfile/', $url_segment))
            {
                $this->showFile($url_segment);
            }
	}
        
        private function showFile($data)
        {
            $explode = explode('/', $data);
            array_shift($explode);
            if (sizeof($explode) != 3)
            {
                $this->template->content = 'Error! Wrong path.';
                return false;
            }
            $tempdir_array = array(
                'admin' => 'application/views/admin',
                'public' => 'application/views/public',
            );
        
            $dir_array = array(
                'font' => '/css/font/',
                'scripts' => '/js/',
                'images' => '/css/img/',
            );
            
            $file_path = $_SERVER['DOCUMENT_ROOT'].'/'.$tempdir_array[$explode[0]].$dir_array[$explode[1]].$explode[2];
            if (file_exists($file_path))
            {
                $this->template->content = file_get_contents($file_path);
            }
            else
            {
                var_dump($file_path);
                $this->template->content = 'Error! Wrong file.';
            }
        }

} // End Welcome
