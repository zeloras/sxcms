<?php defined('SYSPATH') or die('No direct script access.');

class Roadmin extends Base {
    public $template = 'admin/desktop';

}