<?php defined('SYSPATH') or die('No direct script access.');

class Model_Admin_Auth extends ORM
{
    protected $_table_name = 'users';
    
    public function admin_auth()
    {
        $auth = Auth::instance();
        $login = Arr::get($_POST, 'username');
        $password = Arr::get($_POST, 'password');
        $remember = (Arr::get($_POST, 'remember')) ? TRUE : FALSE;
        
        return $auth->login($login, $password, $remember);
    }
}
