<?php defined('SYSPATH') or die('No direct script access.');

class Model_Admin_Menus
{    
    
    public function admin_menus_add()
    {
        $title = Arr::get($_POST, 'title');
        $name = Arr::get($_POST, 'name');
        $description = Arr::get($_POST, 'description');
        $template = Arr::get($_POST, 'template');
        $class = Arr::get($_POST, 'class');
        $parent_class = Arr::get($_POST, 'parent_class');
        $menus_query = new Model_Menus();
        
        try		
        {
            $menus_query->title = $title;
            $menus_query->name = $name;
            $menus_query->description = $description;
            $menus_query->template = $template;
            $menus_query->class = $class;
            $menus_query->parent_class = $parent_class;
            $menus_query->date = time();
            $menus_query->update = time();
            
            return $menus_query->save();
        }
        catch(ORM_Validation_Exception $e)
        {
                return $e->errors('admin');
        }
    }
    
    
    public function admin_menus_edit($id = 0)
    {
        $title = Arr::get($_POST, 'title');
        $name = Arr::get($_POST, 'name');
        $description = Arr::get($_POST, 'description');
        $template = Arr::get($_POST, 'template');
        $class = Arr::get($_POST, 'class');
        $parent_class = Arr::get($_POST, 'parent_class');
        $mid = Arr::get($_POST, 'menu_id');
        $menus_query = ORM::factory('menus');
        $menus_query->where('id', '=', $id);
        $menus_query_count = $menus_query->count_all();
        
        if ($menus_query_count > 0 && $mid == $id)
        {
            $menus_query->where('id', '=', $id);
            $menus_query->find();
            try		
            {
                $menus_query->id =  $mid;
                $menus_query->title = $title;
                $menus_query->name = $name;
                $menus_query->description = $description;
                $menus_query->template = $template;
                $menus_query->class = $class;
                $menus_query->parent_class = $parent_class;
                $menus_query->update = time();
                $menus_query->update();
                return $mid;
            }
            catch(ORM_Validation_Exception $e)
            {
                    return $e->errors('admin');
            }
        }
        else
        {
            if ($mid !== $id)
                return array(0 => 'Menu wrong');
            else
                return array(0 => "Menu not isset");
        }
    }
    
    
    public function admin_link_add($id = 0)
    {
        $title = Arr::get($_POST, 'title');
        $description = Arr::get($_POST, 'description');
        $icons = Arr::get($_POST, 'icons');
        $classes = Arr::get($_POST, 'classes');
        $parent = Arr::get($_POST, 'parent');
        $hidden = Arr::get($_POST, 'visible');
        $select_1 = Arr::get($_POST, 'linktype');
        $select_2 = Arr::get($_POST, 'first');
        $select_3 = Arr::get($_POST, 'second');
        $select_4 = Arr::get($_POST, 'threed');
        $menus_query = new Model_Links();
        
        switch ($select_1) 
        {
            case 1:
                $data_prop['type'] = $select_1;
                $data_prop['first'] = $select_2;
                $data_prop['second'] = 0;
                $data_prop['threed'] = '';
                $data_prop['url'] = Helper_Common::get_category_path($select_2);
            break;

            case 2:
                $data_prop['type'] = $select_1;
                $data_prop['first'] = $select_2;
                $data_prop['second'] = $select_3;
                $data_prop['threed'] = '';
                $data_prop['url'] = $select_3;
            break;

            case 3:
                $data_prop['type'] = $select_1;
                $data_prop['first'] = $select_2;
                $data_prop['second'] = 0;
                $data_prop['threed'] = '';
                $data_prop['url'] = $select_2;
            break;
        
            case 4:
                $data_prop['type'] = $select_1;
                $data_prop['first'] = $select_2;
                $data_prop['second'] = 0;
                $data_prop['threed'] = $select_4;
                $data_prop['url'] = $select_4;
            break;

        }
        
        try		
        {
            $menus_query->menu_id = $id;
            $menus_query->title = $title;
            $menus_query->hidden = $hidden;
            $menus_query->description = $description;
            $menus_query->icons = $icons;
            $menus_query->classes = $classes;
            $menus_query->parent_id = $parent;
            $menus_query->data = serialize($data_prop);
            $menus_query->date = time();
            
            return $menus_query->save();
        }
        catch(ORM_Validation_Exception $e)
        {
                return $e->errors('admin');
        }
    }
    
    public function admin_link_edit($id = 0, $item = 0)
    {
        $iid = Arr::get($_POST, 'item_id');
        $mid = Arr::get($_POST,'menu_id');
        $title = Arr::get($_POST, 'title');
        $description = Arr::get($_POST, 'description');
        $icons = Arr::get($_POST, 'icons');
        $classes = Arr::get($_POST, 'classes');
        $parent = Arr::get($_POST, 'parent');
        $hidden = Arr::get($_POST, 'visible');
        $select_1 = Arr::get($_POST, 'linktype');
        $select_2 = Arr::get($_POST, 'first');
        $select_3 = Arr::get($_POST, 'second');
        $select_4 = Arr::get($_POST, 'threed');
        $menus_query = ORM::factory('links')->where('id', '=', $item)->where('menu_id', '=', $id)->find();
        
        switch ($select_1) 
        {
            case 1:
                $data_prop['type'] = $select_1;
                $data_prop['first'] = $select_2;
                $data_prop['second'] = 0;
                $data_prop['threed'] = '';
                $data_prop['url'] = Helper_Common::get_category_path($select_2);
            break;

            case 2:
                $data_prop['type'] = $select_1;
                $data_prop['first'] = $select_2;
                $data_prop['second'] = $select_3;
                $data_prop['threed'] = '';
                $data_prop['url'] = $select_3;
            break;

            case 3:
                $data_prop['type'] = $select_1;
                $data_prop['first'] = $select_2;
                $data_prop['second'] = 0;
                $data_prop['threed'] = '';
                $data_prop['url'] = $select_2;
            break;
        
            case 4:
                $data_prop['type'] = $select_1;
                $data_prop['first'] = 0;
                $data_prop['second'] = 0;
                $data_prop['threed'] = $select_4;
                $data_prop['url'] = $select_4;
            break;

        }
        
        try		
        {
            $menus_query->id = $item;
            $menus_query->menu_id = $id;
            $menus_query->title = $title;
            $menus_query->hidden = $hidden;
            $menus_query->icons = $icons;
            $menus_query->classes = $classes;
            $menus_query->description = $description;
            $menus_query->parent_id = $parent;
            $menus_query->data = serialize($data_prop);
            $menus_query->date = time();
            
            return $menus_query->update();
        }
        catch(ORM_Validation_Exception $e)
        {
                return $e->errors('admin');
        }
    }
}
