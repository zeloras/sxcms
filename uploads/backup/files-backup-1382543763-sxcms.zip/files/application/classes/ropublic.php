<?php defined('SYSPATH') or die('No direct script access.');

class Ropublic extends Base {
    public $template = 'public/default/index';
}