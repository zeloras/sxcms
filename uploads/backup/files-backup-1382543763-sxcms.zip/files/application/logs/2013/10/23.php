<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2013-10-23 08:52:23 --- INFO: Zip Compression Class Initialized
2013-10-23 08:52:23 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 08:52:23 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(181): KOZip->archive('uploads/backup/...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 08:52:23 --- INFO: Zip Compression Class Initialized
2013-10-23 08:52:23 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 08:52:23 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(181): KOZip->archive('uploads/backup/...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 08:54:48 --- INFO: Zip Compression Class Initialized
2013-10-23 08:54:48 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Libs_Zipper::get_files_from_folder() ~ APPPATH/classes/model/admin/settings.php [ 179 ]
2013-10-23 08:54:48 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Libs_Zipper::get_files_from_folder() ~ APPPATH/classes/model/admin/settings.php [ 179 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-23 08:55:21 --- INFO: Zip Compression Class Initialized
2013-10-23 08:55:21 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 08:55:21 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(181): KOZip->archive('uploads/backup/...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 08:57:11 --- INFO: Zip Compression Class Initialized
2013-10-23 08:57:11 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 08:57:11 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(181): KOZip->archive('uploads/backup/...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 09:03:49 --- INFO: Zip Compression Class Initialized
2013-10-23 09:03:49 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 09:03:49 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('uploads/backup/...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(9): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 09:04:34 --- INFO: Zip Compression Class Initialized
2013-10-23 09:04:34 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 09:04:34 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(9): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 09:04:38 --- INFO: Zip Compression Class Initialized
2013-10-23 09:04:38 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 09:04:38 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(9): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 09:05:55 --- INFO: Zip Compression Class Initialized
2013-10-23 09:05:55 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 09:05:55 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 09:05:56 --- INFO: Zip Compression Class Initialized
2013-10-23 09:05:56 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 09:05:56 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 09:05:56 --- INFO: Zip Compression Class Initialized
2013-10-23 09:05:56 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 09:05:56 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 09:05:57 --- INFO: Zip Compression Class Initialized
2013-10-23 09:05:57 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 09:05:57 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 09:05:57 --- INFO: Zip Compression Class Initialized
2013-10-23 09:05:57 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 09:05:57 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 09:06:10 --- INFO: Zip Compression Class Initialized
2013-10-23 09:06:10 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 09:06:10 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 09:06:11 --- INFO: Zip Compression Class Initialized
2013-10-23 09:06:11 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 09:06:11 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 09:06:11 --- INFO: Zip Compression Class Initialized
2013-10-23 09:06:11 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 09:06:11 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 09:06:56 --- INFO: Zip Compression Class Initialized
2013-10-23 09:06:56 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 09:06:56 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 09:06:57 --- INFO: Zip Compression Class Initialized
2013-10-23 09:06:57 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 09:06:57 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 09:07:22 --- INFO: Zip Compression Class Initialized
2013-10-23 09:07:22 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 09:07:22 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 09:07:23 --- INFO: Zip Compression Class Initialized
2013-10-23 09:07:23 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 09:07:23 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 09:07:24 --- INFO: Zip Compression Class Initialized
2013-10-23 09:07:24 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 09:07:24 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 09:07:24 --- INFO: Zip Compression Class Initialized
2013-10-23 09:07:24 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 09:07:24 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 09:12:40 --- INFO: Zip Compression Class Initialized
2013-10-23 09:12:40 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 09:12:40 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 09:12:41 --- INFO: Zip Compression Class Initialized
2013-10-23 09:12:41 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 09:12:41 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 09:12:53 --- INFO: Zip Compression Class Initialized
2013-10-23 09:12:53 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 09:12:53 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 09:12:54 --- INFO: Zip Compression Class Initialized
2013-10-23 09:12:54 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 09:12:54 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 09:12:55 --- INFO: Zip Compression Class Initialized
2013-10-23 09:12:55 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 09:12:55 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 09:12:55 --- INFO: Zip Compression Class Initialized
2013-10-23 09:12:55 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 09:12:55 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 09:12:55 --- INFO: Zip Compression Class Initialized
2013-10-23 09:12:55 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 09:12:55 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 09:12:55 --- INFO: Zip Compression Class Initialized
2013-10-23 09:12:55 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 09:12:55 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 09:13:07 --- INFO: Zip Compression Class Initialized
2013-10-23 09:13:07 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 09:13:07 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 09:13:08 --- INFO: Zip Compression Class Initialized
2013-10-23 09:13:08 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 09:13:08 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(180): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 09:15:43 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected '*' ~ APPPATH/classes/model/admin/settings.php [ 178 ]
2013-10-23 09:15:43 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected '*' ~ APPPATH/classes/model/admin/settings.php [ 178 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-23 09:15:59 --- INFO: Zip Compression Class Initialized
2013-10-23 09:15:59 --- ERROR: ErrorException [ 8 ]: Undefined property: Model_Admin_Settings::$response ~ APPPATH/classes/model/admin/settings.php [ 182 ]
2013-10-23 09:15:59 --- STRACE: ErrorException [ 8 ]: Undefined property: Model_Admin_Settings::$response ~ APPPATH/classes/model/admin/settings.php [ 182 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/settings.php(182): Kohana_Core::error_handler(8, 'Undefined prope...', '/var/www/zelora...', 182, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Admin_Settings->admin_backup_create('sql_files')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 09:16:18 --- INFO: Zip Compression Class Initialized
2013-10-23 09:16:18 --- ERROR: ErrorException [ 8 ]: Use of undefined constant link - assumed 'link' ~ APPPATH/views/admin/settings/index.php [ 238 ]
2013-10-23 09:16:18 --- STRACE: ErrorException [ 8 ]: Use of undefined constant link - assumed 'link' ~ APPPATH/views/admin/settings/index.php [ 238 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(238): Kohana_Core::error_handler(8, 'Use of undefine...', '/var/www/zelora...', 238, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-23 09:16:29 --- INFO: Zip Compression Class Initialized
2013-10-23 09:16:29 --- ERROR: ErrorException [ 8 ]: Use of undefined constant link - assumed 'link' ~ APPPATH/views/admin/settings/index.php [ 238 ]
2013-10-23 09:16:29 --- STRACE: ErrorException [ 8 ]: Use of undefined constant link - assumed 'link' ~ APPPATH/views/admin/settings/index.php [ 238 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(238): Kohana_Core::error_handler(8, 'Use of undefine...', '/var/www/zelora...', 238, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-23 09:16:31 --- INFO: Zip Compression Class Initialized
2013-10-23 09:16:31 --- ERROR: ErrorException [ 8 ]: Use of undefined constant link - assumed 'link' ~ APPPATH/views/admin/settings/index.php [ 238 ]
2013-10-23 09:16:31 --- STRACE: ErrorException [ 8 ]: Use of undefined constant link - assumed 'link' ~ APPPATH/views/admin/settings/index.php [ 238 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(238): Kohana_Core::error_handler(8, 'Use of undefine...', '/var/www/zelora...', 238, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-23 09:17:49 --- INFO: Zip Compression Class Initialized
2013-10-23 09:17:49 --- INFO: Zip Compression Class Initialized
2013-10-23 09:17:49 --- ERROR: ErrorException [ 8 ]: Use of undefined constant link - assumed 'link' ~ APPPATH/views/admin/settings/index.php [ 238 ]
2013-10-23 09:17:49 --- STRACE: ErrorException [ 8 ]: Use of undefined constant link - assumed 'link' ~ APPPATH/views/admin/settings/index.php [ 238 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(238): Kohana_Core::error_handler(8, 'Use of undefine...', '/var/www/zelora...', 238, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-23 09:17:50 --- INFO: Zip Compression Class Initialized
2013-10-23 09:17:50 --- INFO: Zip Compression Class Initialized
2013-10-23 09:17:50 --- ERROR: ErrorException [ 8 ]: Use of undefined constant link - assumed 'link' ~ APPPATH/views/admin/settings/index.php [ 238 ]
2013-10-23 09:17:50 --- STRACE: ErrorException [ 8 ]: Use of undefined constant link - assumed 'link' ~ APPPATH/views/admin/settings/index.php [ 238 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(238): Kohana_Core::error_handler(8, 'Use of undefine...', '/var/www/zelora...', 238, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-23 09:18:06 --- INFO: Zip Compression Class Initialized
2013-10-23 09:18:06 --- INFO: Zip Compression Class Initialized
2013-10-23 09:18:06 --- ERROR: ErrorException [ 8 ]: Use of undefined constant link - assumed 'link' ~ APPPATH/views/admin/settings/index.php [ 238 ]
2013-10-23 09:18:06 --- STRACE: ErrorException [ 8 ]: Use of undefined constant link - assumed 'link' ~ APPPATH/views/admin/settings/index.php [ 238 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(238): Kohana_Core::error_handler(8, 'Use of undefine...', '/var/www/zelora...', 238, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-23 09:18:33 --- INFO: Zip Compression Class Initialized
2013-10-23 09:18:33 --- INFO: Zip Compression Class Initialized
2013-10-23 09:18:33 --- ERROR: ErrorException [ 8 ]: Use of undefined constant link - assumed 'link' ~ APPPATH/views/admin/settings/index.php [ 238 ]
2013-10-23 09:18:33 --- STRACE: ErrorException [ 8 ]: Use of undefined constant link - assumed 'link' ~ APPPATH/views/admin/settings/index.php [ 238 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(238): Kohana_Core::error_handler(8, 'Use of undefine...', '/var/www/zelora...', 238, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-23 09:22:01 --- INFO: Zip Compression Class Initialized
2013-10-23 09:22:01 --- INFO: Zip Compression Class Initialized
2013-10-23 09:22:01 --- ERROR: ErrorException [ 8 ]: Use of undefined constant link - assumed 'link' ~ APPPATH/views/admin/settings/index.php [ 238 ]
2013-10-23 09:22:01 --- STRACE: ErrorException [ 8 ]: Use of undefined constant link - assumed 'link' ~ APPPATH/views/admin/settings/index.php [ 238 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(238): Kohana_Core::error_handler(8, 'Use of undefine...', '/var/www/zelora...', 238, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-23 09:22:11 --- INFO: Zip Compression Class Initialized
2013-10-23 09:22:11 --- INFO: Zip Compression Class Initialized
2013-10-23 09:22:11 --- ERROR: ErrorException [ 8 ]: Use of undefined constant link - assumed 'link' ~ APPPATH/views/admin/settings/index.php [ 238 ]
2013-10-23 09:22:11 --- STRACE: ErrorException [ 8 ]: Use of undefined constant link - assumed 'link' ~ APPPATH/views/admin/settings/index.php [ 238 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(238): Kohana_Core::error_handler(8, 'Use of undefine...', '/var/www/zelora...', 238, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-23 09:23:10 --- INFO: Zip Compression Class Initialized
2013-10-23 09:23:10 --- INFO: Zip Compression Class Initialized
2013-10-23 09:23:10 --- ERROR: ErrorException [ 8 ]: Use of undefined constant link - assumed 'link' ~ APPPATH/views/admin/settings/index.php [ 238 ]
2013-10-23 09:23:10 --- STRACE: ErrorException [ 8 ]: Use of undefined constant link - assumed 'link' ~ APPPATH/views/admin/settings/index.php [ 238 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(238): Kohana_Core::error_handler(8, 'Use of undefine...', '/var/www/zelora...', 238, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-23 09:23:31 --- INFO: Zip Compression Class Initialized
2013-10-23 09:23:31 --- INFO: Zip Compression Class Initialized
2013-10-23 09:23:31 --- ERROR: ErrorException [ 8 ]: Undefined offset: 2 ~ APPPATH/classes/controller/admin/settings.php [ 61 ]
2013-10-23 09:23:31 --- STRACE: ErrorException [ 8 ]: Undefined offset: 2 ~ APPPATH/classes/controller/admin/settings.php [ 61 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(61): Kohana_Core::error_handler(8, 'Undefined offse...', '/var/www/zelora...', 61, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-10-23 09:23:44 --- INFO: Zip Compression Class Initialized
2013-10-23 09:23:44 --- INFO: Zip Compression Class Initialized
2013-10-23 09:23:44 --- ERROR: ErrorException [ 8 ]: Undefined offset: 2 ~ APPPATH/classes/controller/admin/settings.php [ 61 ]
2013-10-23 09:23:44 --- STRACE: ErrorException [ 8 ]: Undefined offset: 2 ~ APPPATH/classes/controller/admin/settings.php [ 61 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(61): Kohana_Core::error_handler(8, 'Undefined offse...', '/var/www/zelora...', 61, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-10-23 09:32:32 --- ERROR: ErrorException [ 1 ]: Call to a member function open() on a non-object ~ APPPATH/classes/controller/admin/settings.php [ 11 ]
2013-10-23 09:32:32 --- STRACE: ErrorException [ 1 ]: Call to a member function open() on a non-object ~ APPPATH/classes/controller/admin/settings.php [ 11 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-23 09:32:42 --- ERROR: ErrorException [ 8 ]: Use of undefined constant FILENAME - assumed 'FILENAME' ~ APPPATH/classes/controller/admin/settings.php [ 14 ]
2013-10-23 09:32:42 --- STRACE: ErrorException [ 8 ]: Use of undefined constant FILENAME - assumed 'FILENAME' ~ APPPATH/classes/controller/admin/settings.php [ 14 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(14): Kohana_Core::error_handler(8, 'Use of undefine...', '/var/www/zelora...', 14, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-10-23 09:32:53 --- ERROR: ErrorException [ 8 ]: Undefined offset: 2 ~ APPPATH/classes/controller/admin/settings.php [ 63 ]
2013-10-23 09:32:53 --- STRACE: ErrorException [ 8 ]: Undefined offset: 2 ~ APPPATH/classes/controller/admin/settings.php [ 63 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(63): Kohana_Core::error_handler(8, 'Undefined offse...', '/var/www/zelora...', 63, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-10-23 09:38:09 --- ERROR: ErrorException [ 8 ]: Undefined offset: 2 ~ APPPATH/classes/controller/admin/settings.php [ 62 ]
2013-10-23 09:38:09 --- STRACE: ErrorException [ 8 ]: Undefined offset: 2 ~ APPPATH/classes/controller/admin/settings.php [ 62 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(62): Kohana_Core::error_handler(8, 'Undefined offse...', '/var/www/zelora...', 62, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-10-23 09:38:11 --- ERROR: ErrorException [ 8 ]: Undefined offset: 2 ~ APPPATH/classes/controller/admin/settings.php [ 62 ]
2013-10-23 09:38:11 --- STRACE: ErrorException [ 8 ]: Undefined offset: 2 ~ APPPATH/classes/controller/admin/settings.php [ 62 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(62): Kohana_Core::error_handler(8, 'Undefined offse...', '/var/www/zelora...', 62, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-10-23 09:38:12 --- ERROR: ErrorException [ 8 ]: Undefined offset: 2 ~ APPPATH/classes/controller/admin/settings.php [ 62 ]
2013-10-23 09:38:12 --- STRACE: ErrorException [ 8 ]: Undefined offset: 2 ~ APPPATH/classes/controller/admin/settings.php [ 62 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(62): Kohana_Core::error_handler(8, 'Undefined offse...', '/var/www/zelora...', 62, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-10-23 09:39:15 --- ERROR: ErrorException [ 8 ]: Undefined offset: 2 ~ APPPATH/classes/controller/admin/settings.php [ 62 ]
2013-10-23 09:39:15 --- STRACE: ErrorException [ 8 ]: Undefined offset: 2 ~ APPPATH/classes/controller/admin/settings.php [ 62 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(62): Kohana_Core::error_handler(8, 'Undefined offse...', '/var/www/zelora...', 62, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-10-23 09:39:16 --- ERROR: ErrorException [ 8 ]: Undefined offset: 2 ~ APPPATH/classes/controller/admin/settings.php [ 62 ]
2013-10-23 09:39:16 --- STRACE: ErrorException [ 8 ]: Undefined offset: 2 ~ APPPATH/classes/controller/admin/settings.php [ 62 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(62): Kohana_Core::error_handler(8, 'Undefined offse...', '/var/www/zelora...', 62, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-10-23 10:02:33 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected '$model_zipper' (T_VARIABLE) ~ APPPATH/classes/model/admin/settings.php [ 180 ]
2013-10-23 10:02:33 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected '$model_zipper' (T_VARIABLE) ~ APPPATH/classes/model/admin/settings.php [ 180 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-23 10:21:57 --- ERROR: ErrorException [ 8 ]: Undefined variable: file ~ APPPATH/classes/model/libs/zipper.php [ 17 ]
2013-10-23 10:21:57 --- STRACE: ErrorException [ 8 ]: Undefined variable: file ~ APPPATH/classes/model/libs/zipper.php [ 17 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/libs/zipper.php(17): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 17, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(9): Model_Libs_Zipper->do_backup_files('', 'files/')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 10:21:58 --- ERROR: ErrorException [ 8 ]: Undefined variable: file ~ APPPATH/classes/model/libs/zipper.php [ 17 ]
2013-10-23 10:21:58 --- STRACE: ErrorException [ 8 ]: Undefined variable: file ~ APPPATH/classes/model/libs/zipper.php [ 17 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/libs/zipper.php(17): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 17, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(9): Model_Libs_Zipper->do_backup_files('', 'files/')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-10-23 10:23:53 --- INFO: Zip Compression Class Initialized
2013-10-23 10:23:53 --- ERROR: ErrorException [ 2 ]: opendir(): open_basedir restriction in effect. File(/) is not within the allowed path(s): (/var/www/zeloras/data:.:/etc/ads) ~ APPPATH/classes/model/libs/zipper.php [ 18 ]
2013-10-23 10:23:53 --- STRACE: ErrorException [ 2 ]: opendir(): open_basedir restriction in effect. File(/) is not within the allowed path(s): (/var/www/zeloras/data:.:/etc/ads) ~ APPPATH/classes/model/libs/zipper.php [ 18 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'opendir(): open...', '/var/www/zelora...', 18, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/libs/zipper.php(18): opendir('/')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(8): Model_Libs_Zipper->get_files_from_folder('/', 'files/')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#5 [internal function]: Controller_Admin->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-10-23 10:24:19 --- INFO: Zip Compression Class Initialized
2013-10-23 10:24:23 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 10:24:23 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(9): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-10-23 10:25:55 --- INFO: Zip Compression Class Initialized
2013-10-23 10:25:57 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 10:25:57 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(9): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-10-23 10:25:58 --- INFO: Zip Compression Class Initialized
2013-10-23 10:26:00 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 10:26:00 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(9): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-10-23 10:26:55 --- INFO: Zip Compression Class Initialized
2013-10-23 10:26:57 --- ERROR: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
2013-10-23 10:26:57 --- STRACE: Exception [ 0 ]: KOZip: Could not open output file. ~ MODPATH/kozip/classes/kozip.php [ 377 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/settings.php(9): KOZip->archive('/var/www/zelora...')
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(295): Controller_Admin_Settings->settings('settings', 0)
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('settings')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-10-23 10:32:48 --- INFO: Zip Compression Class Initialized
2013-10-23 10:32:49 --- INFO: Zip Compression Class Initialized
2013-10-23 10:33:29 --- INFO: Zip Compression Class Initialized
2013-10-23 10:34:18 --- INFO: Zip Compression Class Initialized
2013-10-23 10:45:55 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Admin_Settings::backup_system() ~ APPPATH/classes/controller/admin/settings.php [ 8 ]
2013-10-23 10:45:55 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Admin_Settings::backup_system() ~ APPPATH/classes/controller/admin/settings.php [ 8 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-10-23 10:46:45 --- INFO: Zip Compression Class Initialized
2013-10-23 10:49:26 --- INFO: Zip Compression Class Initialized
2013-10-23 10:51:28 --- ERROR: ErrorException [ 8 ]: Use of undefined constant link - assumed 'link' ~ APPPATH/views/admin/settings/index.php [ 238 ]
2013-10-23 10:51:28 --- STRACE: ErrorException [ 8 ]: Use of undefined constant link - assumed 'link' ~ APPPATH/views/admin/settings/index.php [ 238 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(238): Kohana_Core::error_handler(8, 'Use of undefine...', '/var/www/zelora...', 238, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-23 10:53:17 --- ERROR: ErrorException [ 8 ]: Use of undefined constant link - assumed 'link' ~ APPPATH/views/admin/settings/index.php [ 238 ]
2013-10-23 10:53:17 --- STRACE: ErrorException [ 8 ]: Use of undefined constant link - assumed 'link' ~ APPPATH/views/admin/settings/index.php [ 238 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(238): Kohana_Core::error_handler(8, 'Use of undefine...', '/var/www/zelora...', 238, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-23 10:55:13 --- ERROR: ErrorException [ 8 ]: Undefined variable: cloud ~ APPPATH/views/admin/settings/index.php [ 247 ]
2013-10-23 10:55:13 --- STRACE: ErrorException [ 8 ]: Undefined variable: cloud ~ APPPATH/views/admin/settings/index.php [ 247 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/settings/index.php(247): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 247, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-10-23 10:55:51 --- INFO: Zip Compression Class Initialized
2013-10-23 10:55:51 --- ERROR: ErrorException [ 1 ]: Call to undefined function showMessage() ~ APPPATH/classes/controller/admin/settings.php [ 85 ]
2013-10-23 10:55:51 --- STRACE: ErrorException [ 1 ]: Call to undefined function showMessage() ~ APPPATH/classes/controller/admin/settings.php [ 85 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}