<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2013-08-21 01:06:44 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 01:06:44 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 05:02:45 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 05:02:45 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 05:11:11 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 05:11:11 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:31:27 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:31:27 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:31:33 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:31:33 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:31:33 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:31:33 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:31:33 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:31:33 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:31:37 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:31:37 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:31:39 --- ERROR: ErrorException [ 8 ]: Undefined index: fisrt ~ APPPATH/classes/controller/admin/menus.php [ 65 ]
2013-08-21 12:31:39 --- STRACE: ErrorException [ 8 ]: Undefined index: fisrt ~ APPPATH/classes/controller/admin/menus.php [ 65 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/menus.php(65): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 65, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(152): Controller_Admin_Menus->menus_data_edit('2', '5')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('menus_data/edit...')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-08-21 12:31:40 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:31:40 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:32:22 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:32:22 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:33:01 --- ERROR: ErrorException [ 8 ]: Undefined index: fisrt ~ APPPATH/classes/controller/admin/menus.php [ 65 ]
2013-08-21 12:33:01 --- STRACE: ErrorException [ 8 ]: Undefined index: fisrt ~ APPPATH/classes/controller/admin/menus.php [ 65 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/menus.php(65): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 65, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(152): Controller_Admin_Menus->menus_data_edit('2', '5')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('menus_data/edit...')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-08-21 12:33:01 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:33:01 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:33:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:33:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:35:01 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:35:01 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:35:05 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:35:05 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:36:13 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:36:13 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:36:13 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:36:13 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:37:55 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:37:55 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:37:55 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:37:55 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:39:27 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:39:27 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:39:27 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:39:27 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:39:31 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:39:31 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:39:31 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:39:31 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:39:31 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:39:31 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:39:32 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:39:32 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:39:33 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:39:33 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:39:33 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:39:33 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:39:33 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:39:33 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:39:34 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:39:34 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:40:06 --- ERROR: ErrorException [ 8 ]: Undefined index: fisrt ~ APPPATH/classes/controller/admin/menus.php [ 72 ]
2013-08-21 12:40:06 --- STRACE: ErrorException [ 8 ]: Undefined index: fisrt ~ APPPATH/classes/controller/admin/menus.php [ 72 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/menus.php(72): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 72, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(152): Controller_Admin_Menus->menus_data_edit('2', '7')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('menus_data/edit...')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-08-21 12:40:07 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:40:07 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:41:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:41:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:41:17 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:41:17 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:56:42 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'category_id' in 'where clause' [ SELECT `sx_pages`.`id` AS `id`, `sx_pages`.`title` AS `title`, `sx_pages`.`short_text` AS `short_text`, `sx_pages`.`text` AS `text`, `sx_pages`.`url` AS `url`, `sx_pages`.`cat_url` AS `cat_url`, `sx_pages`.`category` AS `category`, `sx_pages`.`meta_keywords` AS `meta_keywords`, `sx_pages`.`meta_description` AS `meta_description`, `sx_pages`.`template` AS `template`, `sx_pages`.`author` AS `author`, `sx_pages`.`status` AS `status`, `sx_pages`.`position` AS `position`, `sx_pages`.`date` AS `date`, `sx_pages`.`update` AS `update` FROM `sx_pages` AS `sx_pages` WHERE `category_id` = '21' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-08-21 12:56:42 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'category_id' in 'where clause' [ SELECT `sx_pages`.`id` AS `id`, `sx_pages`.`title` AS `title`, `sx_pages`.`short_text` AS `short_text`, `sx_pages`.`text` AS `text`, `sx_pages`.`url` AS `url`, `sx_pages`.`cat_url` AS `cat_url`, `sx_pages`.`category` AS `category`, `sx_pages`.`meta_keywords` AS `meta_keywords`, `sx_pages`.`meta_description` AS `meta_description`, `sx_pages`.`template` AS `template`, `sx_pages`.`author` AS `author`, `sx_pages`.`status` AS `status`, `sx_pages`.`position` AS `position`, `sx_pages`.`date` AS `date`, `sx_pages`.`update` AS `update` FROM `sx_pages` AS `sx_pages` WHERE `category_id` = '21' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `sx_page...', 'Model_Pages', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/menus.php(74): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(152): Controller_Admin_Menus->menus_data_edit('2', '7')
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('menus_data/edit...')
#6 [internal function]: Controller_Admin->action_route()
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#10 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#11 {main}
2013-08-21 12:56:43 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:56:43 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:57:00 --- ERROR: ErrorException [ 8 ]: Undefined variable: esl ~ APPPATH/views/admin/menus/data/edit.php [ 74 ]
2013-08-21 12:57:00 --- STRACE: ErrorException [ 8 ]: Undefined variable: esl ~ APPPATH/views/admin/menus/data/edit.php [ 74 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/menus/data/edit.php(74): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 74, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-08-21 12:57:01 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:57:01 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:57:20 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH/views/admin/menus/data/edit.php [ 74 ]
2013-08-21 12:57:20 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH/views/admin/menus/data/edit.php [ 74 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/menus/data/edit.php(74): Kohana_Core::error_handler(4096, 'Object of class...', '/var/www/zelora...', 74, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-08-21 12:57:21 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:57:21 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:57:21 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH/views/admin/menus/data/edit.php [ 74 ]
2013-08-21 12:57:21 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ APPPATH/views/admin/menus/data/edit.php [ 74 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/menus/data/edit.php(74): Kohana_Core::error_handler(4096, 'Object of class...', '/var/www/zelora...', 74, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-08-21 12:57:22 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:57:22 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:58:56 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:58:56 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 12:58:56 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 12:58:56 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 13:02:01 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 13:02:01 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 13:02:02 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 13:02:02 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 13:06:24 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 13:06:24 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 13:06:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 13:06:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 13:06:56 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 13:06:56 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 13:06:57 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 13:06:57 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 13:07:07 --- ERROR: ErrorException [ 8 ]: Undefined variable: pages ~ APPPATH/classes/controller/admin/special.php [ 195 ]
2013-08-21 13:07:07 --- STRACE: ErrorException [ 8 ]: Undefined variable: pages ~ APPPATH/classes/controller/admin/special.php [ 195 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/special.php(195): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 195, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(175): Controller_Admin_Special->ajax_getPages_opt('22')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('syscom/getPages...')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-08-21 13:07:12 --- ERROR: ErrorException [ 8 ]: Undefined variable: pages ~ APPPATH/classes/controller/admin/special.php [ 195 ]
2013-08-21 13:07:12 --- STRACE: ErrorException [ 8 ]: Undefined variable: pages ~ APPPATH/classes/controller/admin/special.php [ 195 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/special.php(195): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 195, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(175): Controller_Admin_Special->ajax_getPages_opt('22')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('syscom/getPages...')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-08-21 13:08:39 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 13:08:39 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 13:08:39 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 13:08:39 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 13:08:39 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 13:08:39 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 13:08:40 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 13:08:40 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 13:08:46 --- ERROR: ErrorException [ 8 ]: Undefined index: sechtml ~ APPPATH/views/admin/menus/data/edit.php [ 74 ]
2013-08-21 13:08:46 --- STRACE: ErrorException [ 8 ]: Undefined index: sechtml ~ APPPATH/views/admin/menus/data/edit.php [ 74 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/menus/data/edit.php(74): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 74, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-08-21 13:08:47 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 13:08:47 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 13:12:58 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 13:12:58 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 13:12:59 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 13:12:59 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 13:46:46 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 13:46:46 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 13:46:47 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 13:46:47 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 13:59:44 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 13:59:44 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 14:46:05 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 14:46:05 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 14:46:05 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 14:46:05 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 15:11:12 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 15:11:12 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 15:11:12 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 15:11:12 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 15:11:18 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 15:11:18 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 15:11:19 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 15:11:19 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 15:41:27 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 15:41:27 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 15:41:27 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 15:41:27 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 15:41:31 --- ERROR: ErrorException [ 8 ]: Undefined index: menus ~ APPPATH/classes/controller/admin/special.php [ 63 ]
2013-08-21 15:41:31 --- STRACE: ErrorException [ 8 ]: Undefined index: menus ~ APPPATH/classes/controller/admin/special.php [ 63 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/special.php(63): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 63, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(167): Controller_Admin_Special->ajax_delete('menus')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('syscom/ajax_del...')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-08-21 15:44:13 --- ERROR: ErrorException [ 8 ]: Undefined index: menus ~ APPPATH/classes/controller/admin/special.php [ 63 ]
2013-08-21 15:44:13 --- STRACE: ErrorException [ 8 ]: Undefined index: menus ~ APPPATH/classes/controller/admin/special.php [ 63 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/special.php(63): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 63, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(167): Controller_Admin_Special->ajax_delete('menus')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('syscom/ajax_del...')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-08-21 15:44:14 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 15:44:14 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 15:44:41 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 15:44:41 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 15:46:31 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 15:46:31 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 15:52:38 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 15:52:38 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 15:57:59 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 15:57:59 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 15:58:02 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 15:58:02 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 15:58:03 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 15:58:03 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:03:54 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:03:54 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:03:55 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:03:55 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:03:56 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:03:56 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:03:56 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:03:56 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:04:12 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:04:12 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:04:13 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:04:13 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:04:13 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:04:13 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:04:14 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:04:14 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:04:53 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:04:53 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:04:54 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:04:54 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:04:57 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:04:57 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:04:57 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:04:57 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:04:57 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:04:57 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:04:58 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:04:58 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:05:01 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:05:01 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:05:01 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:05:01 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:05:03 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:05:03 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:05:03 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:05:03 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:05:03 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:05:03 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:05:04 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:05:04 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:05:14 --- ERROR: ErrorException [ 8 ]: Undefined index: menus ~ APPPATH/classes/controller/admin/special.php [ 63 ]
2013-08-21 16:05:14 --- STRACE: ErrorException [ 8 ]: Undefined index: menus ~ APPPATH/classes/controller/admin/special.php [ 63 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/special.php(63): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 63, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(167): Controller_Admin_Special->ajax_delete('menus')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('syscom/ajax_del...')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-08-21 16:24:34 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:24:34 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:24:34 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:24:34 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:24:56 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:24:56 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:24:56 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:24:56 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:26:37 --- ERROR: ErrorException [ 8 ]: Undefined index: menus ~ APPPATH/classes/controller/admin/special.php [ 63 ]
2013-08-21 16:26:37 --- STRACE: ErrorException [ 8 ]: Undefined index: menus ~ APPPATH/classes/controller/admin/special.php [ 63 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/special.php(63): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 63, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(167): Controller_Admin_Special->ajax_delete('menus')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('syscom/ajax_del...')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-08-21 16:26:49 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:26:49 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:26:50 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:26:50 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:26:57 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:26:57 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:26:57 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:26:57 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:00 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:00 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:00 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:00 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:01 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:01 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:01 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:01 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:02 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:02 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:03 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:03 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:04 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:04 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:04 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:04 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:05 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:05 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:05 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:05 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:06 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:06 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:07 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:07 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:09 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:09 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:19 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:19 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:20 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:20 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:23 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:23 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:23 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:23 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:23 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:23 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:24 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:24 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:31 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:31 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:32 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:32 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:34 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:34 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:34 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:34 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:34 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:34 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:35 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:35 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:41 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:41 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:42 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:42 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:43 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:43 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:43 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:43 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:44 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:44 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:27:44 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:27:44 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:30:40 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:30:40 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:30:40 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:30:40 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:30:43 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:30:43 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:30:44 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:30:44 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:30:45 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:30:45 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:30:45 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:30:45 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:30:45 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:30:45 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:30:46 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:30:46 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:30:55 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:30:55 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:30:55 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:30:55 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:30:56 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:30:56 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:30:56 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:30:56 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:30:57 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:30:57 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:30:57 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:30:57 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:31:04 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:31:04 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:31:05 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:31:05 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:31:10 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:31:10 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:31:10 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:31:10 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:31:10 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:31:10 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:31:11 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:31:11 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:31:19 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:31:19 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:31:20 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:31:20 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:31:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:31:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:31:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:31:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:31:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:31:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:31:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:31:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:37:04 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:37:04 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:37:04 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:37:04 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:37:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:37:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:37:09 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:37:09 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:37:11 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:37:11 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:37:11 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:37:11 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:37:11 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:37:11 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:37:11 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:37:11 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:37:14 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:37:14 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:37:15 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:37:15 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:37:15 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:37:15 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:37:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:37:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:37:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:37:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:37:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:37:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:37:24 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:37:24 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:37:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:37:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:42:01 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:42:01 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:42:01 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:42:01 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:42:01 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:42:01 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:42:02 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:42:02 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:42:03 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:42:03 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:42:04 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:42:04 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:42:25 --- ERROR: Kohana_Exception [ 0 ]: Cannot delete links model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1360 ]
2013-08-21 16:42:25 --- STRACE: Kohana_Exception [ 0 ]: Cannot delete links model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1360 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/special.php(123): Kohana_ORM->delete()
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(167): Controller_Admin_Special->ajax_delete('menu')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('syscom/ajax_del...')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-08-21 16:42:53 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:42:53 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:42:54 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:42:54 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:43:52 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:43:52 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:43:53 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:43:53 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:43:57 --- ERROR: Kohana_Exception [ 0 ]: Cannot delete links model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1360 ]
2013-08-21 16:43:57 --- STRACE: Kohana_Exception [ 0 ]: Cannot delete links model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1360 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/special.php(123): Kohana_ORM->delete()
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(167): Controller_Admin_Special->ajax_delete('menu')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('syscom/ajax_del...')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-08-21 16:49:05 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:49:05 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:49:05 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 16:49:05 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 16:49:09 --- ERROR: Kohana_Exception [ 0 ]: Cannot delete links model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1360 ]
2013-08-21 16:49:09 --- STRACE: Kohana_Exception [ 0 ]: Cannot delete links model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1360 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/special.php(123): Kohana_ORM->delete()
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(167): Controller_Admin_Special->ajax_delete('menu')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('syscom/ajax_del...')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-08-21 17:07:45 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 17:07:45 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 17:07:46 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 17:07:46 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 17:11:04 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 17:11:04 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 17:11:05 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 17:11:05 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 17:11:34 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 17:11:34 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 17:11:34 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 17:11:34 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 17:25:02 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 17:25:02 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 17:25:03 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 17:25:03 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 17:25:12 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 17:25:12 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 17:25:13 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 17:25:13 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 17:37:12 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 17:37:12 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 17:37:12 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 17:37:12 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 17:37:12 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 17:37:12 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 17:37:13 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 17:37:13 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 18:12:29 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 18:12:29 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 18:12:32 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 18:12:32 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 18:16:35 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 18:16:35 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 18:31:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 18:31:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 18:31:33 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 18:31:33 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 18:31:33 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 18:31:33 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 18:31:45 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 18:31:45 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 18:31:45 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 18:31:45 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 18:31:46 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 18:31:46 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 18:31:46 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 18:31:46 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 18:32:07 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 18:32:07 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 18:32:07 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 18:32:07 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 18:32:07 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 18:32:07 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 20:03:28 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 20:03:28 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 23:15:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 23:15:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 23:15:27 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 23:15:27 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-21 23:45:17 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-21 23:45:17 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}