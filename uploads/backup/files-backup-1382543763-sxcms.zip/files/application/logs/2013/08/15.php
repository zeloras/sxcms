<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2013-08-15 01:36:14 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-15 01:36:14 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-15 01:36:20 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-15 01:36:20 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-15 01:36:44 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-15 01:36:44 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-15 01:36:48 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-15 01:36:48 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-15 01:36:56 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-15 01:36:56 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-15 05:50:52 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-15 05:50:52 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-15 05:50:53 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-15 05:50:53 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-15 06:02:41 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-15 06:02:41 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-15 06:02:42 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-15 06:02:42 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-15 07:58:11 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-15 07:58:11 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-15 08:06:23 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-15 08:06:23 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-15 08:27:40 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-15 08:27:40 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-15 09:34:48 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-15 09:34:48 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-15 09:57:40 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-15 09:57:40 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-15 12:28:53 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-15 12:28:53 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-15 13:26:57 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-15 13:26:57 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-15 17:24:31 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-15 17:24:31 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-15 20:29:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-15 20:29:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-15 20:57:32 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-15 20:57:32 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}