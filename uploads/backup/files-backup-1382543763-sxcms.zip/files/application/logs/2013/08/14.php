<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2013-08-14 01:13:46 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 01:13:46 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 01:23:21 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 01:23:22 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 05:36:52 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 05:36:52 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 05:36:53 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 05:36:53 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 07:20:43 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 07:20:43 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 07:20:46 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 07:20:46 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 07:20:46 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 07:20:46 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 07:20:46 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 07:20:46 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 07:21:10 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 07:21:10 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 07:21:10 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 07:21:10 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 07:21:11 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 07:21:11 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 07:21:15 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 07:21:15 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 07:21:15 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 07:21:15 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 07:21:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 07:21:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 07:21:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 07:21:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 07:21:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 07:21:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 07:21:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 07:21:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 07:21:39 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 07:21:39 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 07:21:53 --- ERROR: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
2013-08-14 07:21:53 --- STRACE: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(80): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 80, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-14 07:21:53 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 07:21:53 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 07:29:00 --- ERROR: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
2013-08-14 07:29:00 --- STRACE: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(80): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 80, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-08-14 07:29:00 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 07:29:00 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 07:33:04 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 07:33:04 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 07:41:29 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 07:41:29 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 07:41:31 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 07:41:31 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 07:49:45 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 07:49:45 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 07:56:34 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 07:56:34 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 07:56:39 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 07:56:39 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 07:56:40 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 07:56:40 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 07:57:07 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 07:57:07 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 07:57:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 07:57:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 08:03:03 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 08:03:03 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 08:03:03 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 08:03:03 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 08:03:04 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 08:03:04 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 08:03:05 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 08:03:05 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 08:03:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 08:03:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 08:03:09 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 08:03:09 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 08:44:20 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 08:44:20 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 08:44:20 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 08:44:20 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 08:44:20 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 08:44:20 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 08:44:21 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 08:44:21 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 08:44:23 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 08:44:23 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 08:44:23 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 08:44:23 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 08:44:24 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 08:44:24 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 08:44:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 08:44:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 08:44:39 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Admin::category_edit() ~ APPPATH/classes/controller/admin.php [ 100 ]
2013-08-14 08:44:39 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Admin::category_edit() ~ APPPATH/classes/controller/admin.php [ 100 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-08-14 08:44:40 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 08:44:40 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 08:44:45 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 08:44:45 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 08:44:46 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 08:44:46 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 09:40:57 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 09:40:57 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 09:42:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 09:42:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 09:42:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 09:42:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 09:48:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 09:48:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 09:48:27 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 09:48:27 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 09:52:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 09:52:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 09:57:53 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 09:57:53 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 09:57:54 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 09:57:54 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 10:39:02 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 10:39:02 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 10:39:03 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 10:39:03 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 10:39:59 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 10:39:59 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 10:40:00 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 10:40:00 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 10:40:40 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 10:40:40 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 10:40:41 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 10:40:41 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 10:47:29 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 10:47:29 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 10:47:30 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 10:47:30 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 10:47:51 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 10:47:51 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 10:47:52 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 10:47:52 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 10:48:07 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 10:48:07 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 10:48:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 10:48:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 11:43:27 --- ERROR: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Validation::rules() must be of the type array, string given, called in /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php on line 358 and defined ~ SYSPATH/classes/kohana/validation.php [ 238 ]
2013-08-14 11:43:27 --- STRACE: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Validation::rules() must be of the type array, string given, called in /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php on line 358 and defined ~ SYSPATH/classes/kohana/validation.php [ 238 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(238): Kohana_Core::error_handler(4096, 'Argument 2 pass...', '/var/www/zelora...', 238, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(358): Kohana_Validation->rules(0, 'id')
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1198): Kohana_ORM->_validation()
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#9 [internal function]: Controller_Admin->action_route()
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#14 {main}
2013-08-14 11:43:29 --- ERROR: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Validation::rules() must be of the type array, string given, called in /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php on line 358 and defined ~ SYSPATH/classes/kohana/validation.php [ 238 ]
2013-08-14 11:43:29 --- STRACE: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Validation::rules() must be of the type array, string given, called in /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php on line 358 and defined ~ SYSPATH/classes/kohana/validation.php [ 238 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(238): Kohana_Core::error_handler(4096, 'Argument 2 pass...', '/var/www/zelora...', 238, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(358): Kohana_Validation->rules(0, 'id')
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1198): Kohana_ORM->_validation()
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#9 [internal function]: Controller_Admin->action_route()
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#14 {main}
2013-08-14 11:43:30 --- ERROR: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Validation::rules() must be of the type array, string given, called in /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php on line 358 and defined ~ SYSPATH/classes/kohana/validation.php [ 238 ]
2013-08-14 11:43:30 --- STRACE: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Validation::rules() must be of the type array, string given, called in /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php on line 358 and defined ~ SYSPATH/classes/kohana/validation.php [ 238 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(238): Kohana_Core::error_handler(4096, 'Argument 2 pass...', '/var/www/zelora...', 238, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(358): Kohana_Validation->rules(0, 'id')
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1198): Kohana_ORM->_validation()
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#9 [internal function]: Controller_Admin->action_route()
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#14 {main}
2013-08-14 11:43:30 --- ERROR: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Validation::rules() must be of the type array, string given, called in /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php on line 358 and defined ~ SYSPATH/classes/kohana/validation.php [ 238 ]
2013-08-14 11:43:30 --- STRACE: ErrorException [ 4096 ]: Argument 2 passed to Kohana_Validation::rules() must be of the type array, string given, called in /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php on line 358 and defined ~ SYSPATH/classes/kohana/validation.php [ 238 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(238): Kohana_Core::error_handler(4096, 'Argument 2 pass...', '/var/www/zelora...', 238, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(358): Kohana_Validation->rules(0, 'id')
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1198): Kohana_ORM->_validation()
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#9 [internal function]: Controller_Admin->action_route()
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#14 {main}
2013-08-14 11:56:14 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 11:56:14 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 11:56:55 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 11:56:55 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 11:57:25 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 11:57:25 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 11:58:06 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 11:58:06 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 11:58:07 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 11:58:07 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 11:58:07 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 11:58:07 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 11:58:52 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 11:58:52 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 11:58:53 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 11:58:53 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 11:58:55 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 11:58:55 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 11:58:57 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 11:58:57 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 11:58:58 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 11:58:58 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:01:34 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:01:34 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:01:34 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:01:34 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:02:10 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:02:10 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:02:11 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:02:11 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:02:11 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:02:11 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:02:42 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:02:42 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:02:43 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:02:43 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:02:43 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:02:43 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:02:44 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:02:44 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:02:44 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:02:44 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:02:46 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:02:46 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:03:21 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:03:21 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:03:22 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:03:22 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:03:55 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:03:55 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:04:46 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:04:46 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:04:48 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:04:48 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:04:49 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:04:49 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:05:49 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:05:49 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:05:50 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:05:50 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:07:50 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:07:50 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:07:51 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:07:51 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:08:08 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:08:08 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:08:09 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:08:09 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:08:09 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:08:09 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:08:11 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:08:11 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:08:12 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:08:12 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:08:15 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:08:15 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:08:16 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:08:16 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:08:40 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:08:40 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:08:41 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:08:41 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:08:42 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:08:42 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:08:43 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:08:43 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:08:52 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:08:52 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:08:53 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:08:53 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:09:18 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:09:18 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:09:19 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:09:19 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:09:19 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:09:19 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(33): Kohana_ORM->save()
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_add()
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#9 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#10 [internal function]: Controller_Admin->action_route()
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#14 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#15 {main}
2013-08-14 12:11:19 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:11:19 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:11:20 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:11:20 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:12:45 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:12:45 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1289): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(70): Kohana_ORM->update()
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_edit('18')
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#9 [internal function]: Controller_Admin->action_route()
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#14 {main}
2013-08-14 12:17:15 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:17:15 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1289): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(70): Kohana_ORM->update()
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_edit('18')
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#9 [internal function]: Controller_Admin->action_route()
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#14 {main}
2013-08-14 12:25:41 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:25:41 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:25:41 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:25:41 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:25:43 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:25:43 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1289): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(70): Kohana_ORM->update()
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_edit('18')
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#9 [internal function]: Controller_Admin->action_route()
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#14 {main}
2013-08-14 12:25:44 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:25:44 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:29:13 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:29:13 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:29:49 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:29:49 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:30:04 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:30:04 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:31:17 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
2013-08-14 12:31:17 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 48 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(48): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 48, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1289): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(70): Kohana_ORM->update()
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_edit('18')
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#9 [internal function]: Controller_Admin->action_route()
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#14 {main}
2013-08-14 12:31:18 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:31:18 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:33:04 --- ERROR: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 49 ]
2013-08-14 12:33:04 --- STRACE: ErrorException [ 8 ]: Object of class Model_Categorys could not be converted to int ~ APPPATH/classes/model/categorys.php [ 49 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/categorys.php(49): Kohana_Core::error_handler(8, 'Object of class...', '/var/www/zelora...', 49, Array)
#1 [internal function]: Model_Categorys->check_url(Object(Validation))
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/validation.php(377): call_user_func_array(Array, Array)
#3 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(1289): Kohana_ORM->check(NULL)
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(70): Kohana_ORM->update()
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(60): Model_Admin_Categorys->admin_category_edit('18')
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('18')
#8 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#9 [internal function]: Controller_Admin->action_route()
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#13 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#14 {main}
2013-08-14 12:33:05 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:33:05 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:33:24 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:33:24 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:33:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:33:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:33:41 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:33:41 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:33:42 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:33:42 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:33:47 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:33:47 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:33:48 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:33:48 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:49:06 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:49:06 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:49:06 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:49:06 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:49:07 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:49:07 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:49:07 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:49:07 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:49:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:49:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:49:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:49:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:49:09 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:49:09 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:49:09 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:49:09 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:49:11 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:49:11 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:49:11 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:49:11 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:49:12 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:49:12 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:49:13 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:49:13 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:49:14 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:49:14 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:49:14 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:49:14 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:49:15 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:49:15 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:49:15 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:49:15 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:49:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:49:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:49:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:49:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:49:37 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:49:37 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:49:38 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:49:38 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:49:48 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:49:48 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:49:49 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:49:49 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:49:54 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:49:54 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:49:54 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:49:54 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:49:54 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:49:54 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:49:55 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:49:55 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:49:59 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:49:59 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:49:59 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:49:59 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:50:00 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:50:00 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:50:00 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:50:00 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:50:22 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:50:22 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:50:22 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:50:22 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:58:22 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/admin/categorys.php [ 55 ]
2013-08-14 12:58:22 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/admin/categorys.php [ 55 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(55): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 55, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('22')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-08-14 12:58:23 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:58:23 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:58:45 --- ERROR: ErrorException [ 8 ]: Undefined index: category_id ~ APPPATH/classes/controller/admin/categorys.php [ 55 ]
2013-08-14 12:58:45 --- STRACE: ErrorException [ 8 ]: Undefined index: category_id ~ APPPATH/classes/controller/admin/categorys.php [ 55 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(55): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 55, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(100): Controller_Admin_Categorys->category_edit('22')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('categorys/edit/...')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-08-14 12:58:46 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:58:46 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:59:01 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:59:01 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 12:59:02 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 12:59:02 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 13:05:27 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 13:05:27 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 13:05:27 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 13:05:27 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 13:05:27 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 13:05:27 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 13:05:28 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 13:05:28 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 13:05:33 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 13:05:33 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 13:05:34 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 13:05:34 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 13:05:42 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 13:05:42 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 13:05:42 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 13:05:42 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 13:05:43 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 13:05:43 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 13:05:44 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 13:05:44 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 13:05:47 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 13:05:47 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 13:05:47 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 13:05:47 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 14:33:36 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 14:33:36 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 14:33:36 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 14:33:36 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 14:33:36 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 14:33:36 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 14:33:37 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 14:33:37 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 14:34:38 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 14:34:38 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 14:34:39 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 14:34:39 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 14:34:40 --- ERROR: ErrorException [ 8 ]: Undefined index: category ~ APPPATH/classes/controller/admin/pages.php [ 44 ]
2013-08-14 14:34:40 --- STRACE: ErrorException [ 8 ]: Undefined index: category ~ APPPATH/classes/controller/admin/pages.php [ 44 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/pages.php(44): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 44, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(76): Controller_Admin_Pages->page_edit('3')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(24): Controller_Admin->routes('pages/edit/3')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-08-14 14:34:41 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 14:34:41 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 14:35:36 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 14:35:36 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 14:35:37 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 14:35:37 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 14:35:50 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 14:35:50 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 14:35:50 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 14:35:50 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 14:35:51 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 14:35:51 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 14:35:51 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 14:35:51 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 14:35:54 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 14:35:54 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 14:35:54 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 14:35:54 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 14:36:44 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 14:36:44 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 14:36:44 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 14:36:44 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 14:36:45 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 14:36:45 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 14:36:45 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 14:36:45 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 14:39:56 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 14:39:56 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 14:39:57 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 14:39:57 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 14:45:56 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 14:45:56 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 14:45:56 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 14:45:56 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 14:45:59 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 14:45:59 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 14:46:00 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 14:46:00 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 14:56:43 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 14:56:43 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 14:56:44 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 14:56:44 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:02:29 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:02:29 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:02:30 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:02:30 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:02:50 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:02:50 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:02:50 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:02:50 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:03:13 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:03:13 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:03:14 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:03:14 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:06:51 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:06:51 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:09:40 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:09:40 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:09:41 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:09:41 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:14:32 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:14:32 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:14:33 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:14:33 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:14:35 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:14:35 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:14:36 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:14:36 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:14:41 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:14:41 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:14:42 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:14:42 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:14:46 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:14:46 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:14:46 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:14:46 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:14:48 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:14:48 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:14:48 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:14:48 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:14:48 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:14:48 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:14:49 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:14:49 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:14:50 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:14:50 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:14:50 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:14:50 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:14:50 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:14:50 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:14:51 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:14:51 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:14:54 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:14:54 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:14:55 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:14:55 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:14:55 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:14:55 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:14:56 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:14:56 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:14:57 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:14:57 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:14:57 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:14:57 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:14:58 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:14:58 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:14:58 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:14:58 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:14:59 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:14:59 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:14:59 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:14:59 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:15:00 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:15:00 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:15:01 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:15:01 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:15:02 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:15:02 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 15:15:03 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 15:15:03 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 17:41:27 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 17:41:27 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 17:42:05 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 17:42:05 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 18:41:33 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 18:41:33 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 21:00:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 21:00:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 23:47:02 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 23:47:02 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}
2013-08-14 23:52:24 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
2013-08-14 23:52:24 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/public.php [ 144 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/public.php(144): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 144, Array)
#1 [internal function]: Controller_Public->action_route()
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Public))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#6 {main}