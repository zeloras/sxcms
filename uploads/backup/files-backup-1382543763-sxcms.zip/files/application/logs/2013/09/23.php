<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2013-09-23 00:10:56 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_User as array ~ APPPATH/classes/base.php [ 9 ]
2013-09-23 00:10:56 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_User as array ~ APPPATH/classes/base.php [ 9 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-09-23 00:13:41 --- ERROR: ErrorException [ 1 ]: Class 'Model_Userroles' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
2013-09-23 00:13:41 --- STRACE: ErrorException [ 1 ]: Class 'Model_Userroles' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-09-23 00:17:08 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/base.php [ 14 ]
2013-09-23 00:17:08 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/base.php [ 14 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/base.php(14): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 14, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(7): Base->get_access()
#2 [internal function]: Controller_Admin->action_route()
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-09-23 00:34:59 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Admin::access_error() ~ APPPATH/classes/controller/admin.php [ 79 ]
2013-09-23 00:34:59 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Admin::access_error() ~ APPPATH/classes/controller/admin.php [ 79 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-09-23 00:34:59 --- ERROR: ErrorException [ 1 ]: Call to undefined method Controller_Admin::access_error() ~ APPPATH/classes/controller/admin.php [ 79 ]
2013-09-23 00:34:59 --- STRACE: ErrorException [ 1 ]: Call to undefined method Controller_Admin::access_error() ~ APPPATH/classes/controller/admin.php [ 79 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-09-23 00:46:10 --- ERROR: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
2013-09-23 00:46:10 --- STRACE: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(80): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 80, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-09-23 00:46:11 --- ERROR: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
2013-09-23 00:46:11 --- STRACE: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(80): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 80, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-09-23 00:46:13 --- ERROR: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
2013-09-23 00:46:13 --- STRACE: ErrorException [ 8 ]: Undefined variable: menu_admin_html ~ APPPATH/views/admin/desktop.php [ 80 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(80): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 80, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#4 [internal function]: Kohana_Controller_Template->after()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-09-23 00:57:29 --- ERROR: ErrorException [ 1 ]: Call to a member function param() on a non-object ~ APPPATH/classes/controller/admin.php [ 15 ]
2013-09-23 00:57:29 --- STRACE: ErrorException [ 1 ]: Call to a member function param() on a non-object ~ APPPATH/classes/controller/admin.php [ 15 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-09-23 00:57:37 --- ERROR: ErrorException [ 1 ]: Call to a member function param() on a non-object ~ APPPATH/classes/controller/admin.php [ 15 ]
2013-09-23 00:57:37 --- STRACE: ErrorException [ 1 ]: Call to a member function param() on a non-object ~ APPPATH/classes/controller/admin.php [ 15 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-09-23 00:57:38 --- ERROR: ErrorException [ 1 ]: Call to a member function param() on a non-object ~ APPPATH/classes/controller/admin.php [ 15 ]
2013-09-23 00:57:38 --- STRACE: ErrorException [ 1 ]: Call to a member function param() on a non-object ~ APPPATH/classes/controller/admin.php [ 15 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-09-23 00:58:09 --- ERROR: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Controller::__construct() must be an instance of Request, none given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php on line 10 and defined ~ SYSPATH/classes/kohana/controller.php [ 43 ]
2013-09-23 00:58:09 --- STRACE: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Controller::__construct() must be an instance of Request, none given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php on line 10 and defined ~ SYSPATH/classes/kohana/controller.php [ 43 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller.php(43): Kohana_Core::error_handler(4096, 'Argument 1 pass...', '/var/www/zelora...', 43, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(10): Kohana_Controller->__construct()
#2 [internal function]: Controller_Admin->__construct(Object(Request), Object(Response))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(101): ReflectionClass->newInstance(Object(Request), Object(Response))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-09-23 00:58:10 --- ERROR: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Controller::__construct() must be an instance of Request, none given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php on line 10 and defined ~ SYSPATH/classes/kohana/controller.php [ 43 ]
2013-09-23 00:58:10 --- STRACE: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Controller::__construct() must be an instance of Request, none given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php on line 10 and defined ~ SYSPATH/classes/kohana/controller.php [ 43 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller.php(43): Kohana_Core::error_handler(4096, 'Argument 1 pass...', '/var/www/zelora...', 43, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(10): Kohana_Controller->__construct()
#2 [internal function]: Controller_Admin->__construct(Object(Request), Object(Response))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(101): ReflectionClass->newInstance(Object(Request), Object(Response))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-09-23 00:58:52 --- ERROR: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Controller::__construct() must be an instance of Request, none given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php on line 10 and defined ~ SYSPATH/classes/kohana/controller.php [ 43 ]
2013-09-23 00:58:52 --- STRACE: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Controller::__construct() must be an instance of Request, none given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php on line 10 and defined ~ SYSPATH/classes/kohana/controller.php [ 43 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller.php(43): Kohana_Core::error_handler(4096, 'Argument 1 pass...', '/var/www/zelora...', 43, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(10): Kohana_Controller->__construct()
#2 [internal function]: Controller_Admin->__construct(Object(Request), Object(Response))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(101): ReflectionClass->newInstance(Object(Request), Object(Response))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-09-23 00:58:53 --- ERROR: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Controller::__construct() must be an instance of Request, none given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php on line 10 and defined ~ SYSPATH/classes/kohana/controller.php [ 43 ]
2013-09-23 00:58:53 --- STRACE: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Controller::__construct() must be an instance of Request, none given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php on line 10 and defined ~ SYSPATH/classes/kohana/controller.php [ 43 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller.php(43): Kohana_Core::error_handler(4096, 'Argument 1 pass...', '/var/www/zelora...', 43, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(10): Kohana_Controller->__construct()
#2 [internal function]: Controller_Admin->__construct(Object(Request), Object(Response))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(101): ReflectionClass->newInstance(Object(Request), Object(Response))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-09-23 00:58:54 --- ERROR: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Controller::__construct() must be an instance of Request, none given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php on line 10 and defined ~ SYSPATH/classes/kohana/controller.php [ 43 ]
2013-09-23 00:58:54 --- STRACE: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Controller::__construct() must be an instance of Request, none given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php on line 10 and defined ~ SYSPATH/classes/kohana/controller.php [ 43 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller.php(43): Kohana_Core::error_handler(4096, 'Argument 1 pass...', '/var/www/zelora...', 43, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(10): Kohana_Controller->__construct()
#2 [internal function]: Controller_Admin->__construct(Object(Request), Object(Response))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(101): ReflectionClass->newInstance(Object(Request), Object(Response))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-09-23 00:58:54 --- ERROR: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Controller::__construct() must be an instance of Request, none given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php on line 10 and defined ~ SYSPATH/classes/kohana/controller.php [ 43 ]
2013-09-23 00:58:54 --- STRACE: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Controller::__construct() must be an instance of Request, none given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php on line 10 and defined ~ SYSPATH/classes/kohana/controller.php [ 43 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller.php(43): Kohana_Core::error_handler(4096, 'Argument 1 pass...', '/var/www/zelora...', 43, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(10): Kohana_Controller->__construct()
#2 [internal function]: Controller_Admin->__construct(Object(Request), Object(Response))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(101): ReflectionClass->newInstance(Object(Request), Object(Response))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-09-23 00:58:54 --- ERROR: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Controller::__construct() must be an instance of Request, none given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php on line 10 and defined ~ SYSPATH/classes/kohana/controller.php [ 43 ]
2013-09-23 00:58:54 --- STRACE: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Controller::__construct() must be an instance of Request, none given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php on line 10 and defined ~ SYSPATH/classes/kohana/controller.php [ 43 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller.php(43): Kohana_Core::error_handler(4096, 'Argument 1 pass...', '/var/www/zelora...', 43, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(10): Kohana_Controller->__construct()
#2 [internal function]: Controller_Admin->__construct(Object(Request), Object(Response))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(101): ReflectionClass->newInstance(Object(Request), Object(Response))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-09-23 00:58:55 --- ERROR: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Controller::__construct() must be an instance of Request, none given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php on line 10 and defined ~ SYSPATH/classes/kohana/controller.php [ 43 ]
2013-09-23 00:58:55 --- STRACE: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Controller::__construct() must be an instance of Request, none given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php on line 10 and defined ~ SYSPATH/classes/kohana/controller.php [ 43 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller.php(43): Kohana_Core::error_handler(4096, 'Argument 1 pass...', '/var/www/zelora...', 43, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(10): Kohana_Controller->__construct()
#2 [internal function]: Controller_Admin->__construct(Object(Request), Object(Response))
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(101): ReflectionClass->newInstance(Object(Request), Object(Response))
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#7 {main}
2013-09-23 00:59:12 --- ERROR: ErrorException [ 1 ]: Call to a member function param() on a non-object ~ APPPATH/classes/controller/admin.php [ 15 ]
2013-09-23 00:59:12 --- STRACE: ErrorException [ 1 ]: Call to a member function param() on a non-object ~ APPPATH/classes/controller/admin.php [ 15 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-09-23 00:59:13 --- ERROR: ErrorException [ 1 ]: Call to a member function param() on a non-object ~ APPPATH/classes/controller/admin.php [ 15 ]
2013-09-23 00:59:13 --- STRACE: ErrorException [ 1 ]: Call to a member function param() on a non-object ~ APPPATH/classes/controller/admin.php [ 15 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-09-23 01:10:26 --- ERROR: ErrorException [ 8 ]: Undefined variable: access_code ~ APPPATH/views/admin/categorys/list-item.php [ 3 ]
2013-09-23 01:10:26 --- STRACE: ErrorException [ 8 ]: Undefined variable: access_code ~ APPPATH/views/admin/categorys/list-item.php [ 3 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/categorys/list-item.php(3): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 3, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(292): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(11): Model_Admin_Categorys->renderCatList(Array)
#6 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(136): Controller_Admin_Categorys->category_list('page', 0)
#7 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('categorys')
#8 [internal function]: Controller_Admin->action_route()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}
2013-09-23 01:18:09 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Admin_Categorys::get_access() ~ APPPATH/classes/model/admin/categorys.php [ 338 ]
2013-09-23 01:18:09 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Admin_Categorys::get_access() ~ APPPATH/classes/model/admin/categorys.php [ 338 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-09-23 01:18:10 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Admin_Categorys::get_access() ~ APPPATH/classes/model/admin/categorys.php [ 338 ]
2013-09-23 01:18:10 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Admin_Categorys::get_access() ~ APPPATH/classes/model/admin/categorys.php [ 338 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-09-23 01:18:11 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Admin_Categorys::get_access() ~ APPPATH/classes/model/admin/categorys.php [ 338 ]
2013-09-23 01:18:11 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Admin_Categorys::get_access() ~ APPPATH/classes/model/admin/categorys.php [ 338 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-09-23 01:18:11 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Admin_Categorys::get_access() ~ APPPATH/classes/model/admin/categorys.php [ 338 ]
2013-09-23 01:18:11 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Admin_Categorys::get_access() ~ APPPATH/classes/model/admin/categorys.php [ 338 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-09-23 01:18:12 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Admin_Categorys::get_access() ~ APPPATH/classes/model/admin/categorys.php [ 338 ]
2013-09-23 01:18:12 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Admin_Categorys::get_access() ~ APPPATH/classes/model/admin/categorys.php [ 338 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-09-23 01:18:13 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Admin_Categorys::get_access() ~ APPPATH/classes/model/admin/categorys.php [ 338 ]
2013-09-23 01:18:13 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Admin_Categorys::get_access() ~ APPPATH/classes/model/admin/categorys.php [ 338 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-09-23 01:25:21 --- ERROR: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Controller::__construct() must be an instance of Request, none given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php on line 338 and defined ~ SYSPATH/classes/kohana/controller.php [ 43 ]
2013-09-23 01:25:21 --- STRACE: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Controller::__construct() must be an instance of Request, none given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php on line 338 and defined ~ SYSPATH/classes/kohana/controller.php [ 43 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller.php(43): Kohana_Core::error_handler(4096, 'Argument 1 pass...', '/var/www/zelora...', 43, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(338): Kohana_Controller->__construct()
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(293): Model_Admin_Categorys->fetch_tpl('list-item', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(11): Model_Admin_Categorys->renderCatList(Array)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(136): Controller_Admin_Categorys->category_list('page', 0)
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('categorys')
#6 [internal function]: Controller_Admin->action_route()
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#10 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#11 {main}
2013-09-23 01:25:44 --- ERROR: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Controller::__construct() must be an instance of Request, none given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php on line 338 and defined ~ SYSPATH/classes/kohana/controller.php [ 43 ]
2013-09-23 01:25:44 --- STRACE: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Controller::__construct() must be an instance of Request, none given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php on line 338 and defined ~ SYSPATH/classes/kohana/controller.php [ 43 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller.php(43): Kohana_Core::error_handler(4096, 'Argument 1 pass...', '/var/www/zelora...', 43, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(338): Kohana_Controller->__construct()
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(293): Model_Admin_Categorys->fetch_tpl('list-item', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(11): Model_Admin_Categorys->renderCatList(Array)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(136): Controller_Admin_Categorys->category_list('page', 0)
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('categorys')
#6 [internal function]: Controller_Admin->action_route()
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#10 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#11 {main}
2013-09-23 01:25:45 --- ERROR: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Controller::__construct() must be an instance of Request, none given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php on line 338 and defined ~ SYSPATH/classes/kohana/controller.php [ 43 ]
2013-09-23 01:25:45 --- STRACE: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Controller::__construct() must be an instance of Request, none given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php on line 338 and defined ~ SYSPATH/classes/kohana/controller.php [ 43 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller.php(43): Kohana_Core::error_handler(4096, 'Argument 1 pass...', '/var/www/zelora...', 43, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(338): Kohana_Controller->__construct()
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(293): Model_Admin_Categorys->fetch_tpl('list-item', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(11): Model_Admin_Categorys->renderCatList(Array)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(136): Controller_Admin_Categorys->category_list('page', 0)
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('categorys')
#6 [internal function]: Controller_Admin->action_route()
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#10 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#11 {main}
2013-09-23 01:25:45 --- ERROR: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Controller::__construct() must be an instance of Request, none given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php on line 338 and defined ~ SYSPATH/classes/kohana/controller.php [ 43 ]
2013-09-23 01:25:45 --- STRACE: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Controller::__construct() must be an instance of Request, none given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php on line 338 and defined ~ SYSPATH/classes/kohana/controller.php [ 43 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller.php(43): Kohana_Core::error_handler(4096, 'Argument 1 pass...', '/var/www/zelora...', 43, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(338): Kohana_Controller->__construct()
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(293): Model_Admin_Categorys->fetch_tpl('list-item', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(11): Model_Admin_Categorys->renderCatList(Array)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(136): Controller_Admin_Categorys->category_list('page', 0)
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('categorys')
#6 [internal function]: Controller_Admin->action_route()
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#10 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#11 {main}
2013-09-23 01:25:46 --- ERROR: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Controller::__construct() must be an instance of Request, none given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php on line 338 and defined ~ SYSPATH/classes/kohana/controller.php [ 43 ]
2013-09-23 01:25:46 --- STRACE: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Controller::__construct() must be an instance of Request, none given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php on line 338 and defined ~ SYSPATH/classes/kohana/controller.php [ 43 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller.php(43): Kohana_Core::error_handler(4096, 'Argument 1 pass...', '/var/www/zelora...', 43, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(338): Kohana_Controller->__construct()
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(293): Model_Admin_Categorys->fetch_tpl('list-item', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(11): Model_Admin_Categorys->renderCatList(Array)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(136): Controller_Admin_Categorys->category_list('page', 0)
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('categorys')
#6 [internal function]: Controller_Admin->action_route()
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#10 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#11 {main}
2013-09-23 01:26:02 --- ERROR: ErrorException [ 8 ]: Undefined variable: request ~ APPPATH/classes/model/admin/categorys.php [ 338 ]
2013-09-23 01:26:02 --- STRACE: ErrorException [ 8 ]: Undefined variable: request ~ APPPATH/classes/model/admin/categorys.php [ 338 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(338): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 338, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(293): Model_Admin_Categorys->fetch_tpl('list-item', Array)
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(11): Model_Admin_Categorys->renderCatList(Array)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(136): Controller_Admin_Categorys->category_list('page', 0)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('categorys')
#5 [internal function]: Controller_Admin->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-09-23 01:26:03 --- ERROR: ErrorException [ 8 ]: Undefined variable: request ~ APPPATH/classes/model/admin/categorys.php [ 338 ]
2013-09-23 01:26:03 --- STRACE: ErrorException [ 8 ]: Undefined variable: request ~ APPPATH/classes/model/admin/categorys.php [ 338 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(338): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 338, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(293): Model_Admin_Categorys->fetch_tpl('list-item', Array)
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(11): Model_Admin_Categorys->renderCatList(Array)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(136): Controller_Admin_Categorys->category_list('page', 0)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('categorys')
#5 [internal function]: Controller_Admin->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-09-23 01:26:04 --- ERROR: ErrorException [ 8 ]: Undefined variable: request ~ APPPATH/classes/model/admin/categorys.php [ 338 ]
2013-09-23 01:26:04 --- STRACE: ErrorException [ 8 ]: Undefined variable: request ~ APPPATH/classes/model/admin/categorys.php [ 338 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(338): Kohana_Core::error_handler(8, 'Undefined varia...', '/var/www/zelora...', 338, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(293): Model_Admin_Categorys->fetch_tpl('list-item', Array)
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(11): Model_Admin_Categorys->renderCatList(Array)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(136): Controller_Admin_Categorys->category_list('page', 0)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('categorys')
#5 [internal function]: Controller_Admin->action_route()
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#10 {main}
2013-09-23 01:26:13 --- ERROR: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Controller::__construct() must be an instance of Request, none given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php on line 338 and defined ~ SYSPATH/classes/kohana/controller.php [ 43 ]
2013-09-23 01:26:13 --- STRACE: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Controller::__construct() must be an instance of Request, none given, called in /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php on line 338 and defined ~ SYSPATH/classes/kohana/controller.php [ 43 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller.php(43): Kohana_Core::error_handler(4096, 'Argument 1 pass...', '/var/www/zelora...', 43, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(338): Kohana_Controller->__construct()
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/categorys.php(293): Model_Admin_Categorys->fetch_tpl('list-item', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/categorys.php(11): Model_Admin_Categorys->renderCatList(Array)
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(136): Controller_Admin_Categorys->category_list('page', 0)
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('categorys')
#6 [internal function]: Controller_Admin->action_route()
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#10 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#11 {main}
2013-09-23 01:28:09 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' ~ APPPATH/classes/model/admin/categorys.php [ 353 ]
2013-09-23 01:28:09 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' ~ APPPATH/classes/model/admin/categorys.php [ 353 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-09-23 01:28:09 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' ~ APPPATH/classes/model/admin/categorys.php [ 353 ]
2013-09-23 01:28:09 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' ~ APPPATH/classes/model/admin/categorys.php [ 353 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-09-23 01:51:10 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected ')', expecting ']' ~ APPPATH/classes/controller/admin/special.php [ 71 ]
2013-09-23 01:51:10 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected ')', expecting ']' ~ APPPATH/classes/controller/admin/special.php [ 71 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-09-23 01:51:35 --- ERROR: ErrorException [ 8 ]: Undefined index: roles ~ APPPATH/classes/controller/admin/special.php [ 68 ]
2013-09-23 01:51:35 --- STRACE: ErrorException [ 8 ]: Undefined index: roles ~ APPPATH/classes/controller/admin/special.php [ 68 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/special.php(68): Kohana_Core::error_handler(8, 'Undefined index...', '/var/www/zelora...', 68, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(287): Controller_Admin_Special->ajax_delete('roles', Array)
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('syscom/ajax_del...')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-09-23 01:51:47 --- ERROR: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/controller/admin/special.php [ 71 ]
2013-09-23 01:51:47 --- STRACE: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/controller/admin/special.php [ 71 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/special.php(71): Kohana_Core::error_handler(8, 'Undefined offse...', '/var/www/zelora...', 71, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(287): Controller_Admin_Special->ajax_delete('users', Array)
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('syscom/ajax_del...')
#3 [internal function]: Controller_Admin->action_route()
#4 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#8 {main}
2013-09-23 02:30:37 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, title' in 'field list' [ SELECT `id, title`, `sx_roles`.`id` AS `id`, `sx_roles`.`title` AS `title`, `sx_roles`.`name` AS `name`, `sx_roles`.`access` AS `access`, `sx_roles`.`description` AS `description` FROM `sx_roles` AS `sx_roles` ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-09-23 02:30:37 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, title' in 'field list' [ SELECT `id, title`, `sx_roles`.`id` AS `id`, `sx_roles`.`title` AS `title`, `sx_roles`.`name` AS `name`, `sx_roles`.`access` AS `access`, `sx_roles`.`description` AS `description` FROM `sx_roles` AS `sx_roles` ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, tit...', 'Model_Roles', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/users.php(16): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(190): Controller_Admin_Users->users_add()
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('users/add')
#6 [internal function]: Controller_Admin->action_route()
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#10 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#11 {main}
2013-09-23 02:30:37 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, title' in 'field list' [ SELECT `id, title`, `sx_roles`.`id` AS `id`, `sx_roles`.`title` AS `title`, `sx_roles`.`name` AS `name`, `sx_roles`.`access` AS `access`, `sx_roles`.`description` AS `description` FROM `sx_roles` AS `sx_roles` ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-09-23 02:30:37 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, title' in 'field list' [ SELECT `id, title`, `sx_roles`.`id` AS `id`, `sx_roles`.`title` AS `title`, `sx_roles`.`name` AS `name`, `sx_roles`.`access` AS `access`, `sx_roles`.`description` AS `description` FROM `sx_roles` AS `sx_roles` ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, tit...', 'Model_Roles', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/users.php(16): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(190): Controller_Admin_Users->users_add()
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('users/add')
#6 [internal function]: Controller_Admin->action_route()
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#10 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#11 {main}
2013-09-23 02:31:23 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, title' in 'field list' [ SELECT `id, title`, `sx_roles`.`id` AS `id`, `sx_roles`.`title` AS `title`, `sx_roles`.`name` AS `name`, `sx_roles`.`access` AS `access`, `sx_roles`.`description` AS `description` FROM `sx_roles` AS `sx_roles` ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-09-23 02:31:23 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, title' in 'field list' [ SELECT `id, title`, `sx_roles`.`id` AS `id`, `sx_roles`.`title` AS `title`, `sx_roles`.`name` AS `name`, `sx_roles`.`access` AS `access`, `sx_roles`.`description` AS `description` FROM `sx_roles` AS `sx_roles` ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, tit...', 'Model_Roles', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/users.php(16): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(190): Controller_Admin_Users->users_add()
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('users/add')
#6 [internal function]: Controller_Admin->action_route()
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#10 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#11 {main}
2013-09-23 02:31:28 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, title' in 'field list' [ SELECT `id, title`, `sx_roles`.`id` AS `id`, `sx_roles`.`title` AS `title`, `sx_roles`.`name` AS `name`, `sx_roles`.`access` AS `access`, `sx_roles`.`description` AS `description` FROM `sx_roles` AS `sx_roles` ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-09-23 02:31:28 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, title' in 'field list' [ SELECT `id, title`, `sx_roles`.`id` AS `id`, `sx_roles`.`title` AS `title`, `sx_roles`.`name` AS `name`, `sx_roles`.`access` AS `access`, `sx_roles`.`description` AS `description` FROM `sx_roles` AS `sx_roles` ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, tit...', 'Model_Roles', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/users.php(16): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(190): Controller_Admin_Users->users_add()
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('users/add')
#6 [internal function]: Controller_Admin->action_route()
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#10 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#11 {main}
2013-09-23 02:31:29 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id, title' in 'field list' [ SELECT `id, title`, `sx_roles`.`id` AS `id`, `sx_roles`.`title` AS `title`, `sx_roles`.`name` AS `name`, `sx_roles`.`access` AS `access`, `sx_roles`.`description` AS `description` FROM `sx_roles` AS `sx_roles` ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2013-09-23 02:31:29 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id, title' in 'field list' [ SELECT `id, title`, `sx_roles`.`id` AS `id`, `sx_roles`.`title` AS `title`, `sx_roles`.`name` AS `name`, `sx_roles`.`access` AS `access`, `sx_roles`.`description` AS `description` FROM `sx_roles` AS `sx_roles` ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id, tit...', 'Model_Roles', Array)
#1 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /var/www/zeloras/data/www/sxservice.ru/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/users.php(16): Kohana_ORM->find_all()
#4 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(190): Controller_Admin_Users->users_add()
#5 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('users/add')
#6 [internal function]: Controller_Admin->action_route()
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#8 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#10 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#11 {main}
2013-09-23 02:44:43 --- ERROR: ErrorException [ 1 ]: Class 'Model_Role_users' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
2013-09-23 02:44:43 --- STRACE: ErrorException [ 1 ]: Class 'Model_Role_users' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-09-23 02:45:10 --- ERROR: ErrorException [ 1 ]: Class 'Model_Userrole' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
2013-09-23 02:45:10 --- STRACE: ErrorException [ 1 ]: Class 'Model_Userrole' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-09-23 02:45:12 --- ERROR: ErrorException [ 1 ]: Class 'Model_Userrole' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
2013-09-23 02:45:12 --- STRACE: ErrorException [ 1 ]: Class 'Model_Userrole' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-09-23 02:45:13 --- ERROR: ErrorException [ 1 ]: Class 'Model_Userrole' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
2013-09-23 02:45:13 --- STRACE: ErrorException [ 1 ]: Class 'Model_Userrole' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-09-23 02:45:13 --- ERROR: ErrorException [ 1 ]: Class 'Model_Userrole' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
2013-09-23 02:45:13 --- STRACE: ErrorException [ 1 ]: Class 'Model_Userrole' not found ~ MODPATH/orm/classes/kohana/orm.php [ 37 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-09-23 02:49:24 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Userroles as array ~ APPPATH/classes/controller/admin/users.php [ 41 ]
2013-09-23 02:49:24 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Userroles as array ~ APPPATH/classes/controller/admin/users.php [ 41 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-09-23 03:09:48 --- ERROR: Kohana_Exception [ 0 ]: Cannot update userroles model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1284 ]
2013-09-23 03:09:48 --- STRACE: Kohana_Exception [ 0 ]: Cannot update userroles model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1284 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/users.php(58): Kohana_ORM->update()
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/users.php(46): Model_Admin_Users->admin_users_edit('4')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(197): Controller_Admin_Users->users_edit('4')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('users/edit/4')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-09-23 03:10:13 --- ERROR: Kohana_Exception [ 0 ]: Cannot update userroles model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1284 ]
2013-09-23 03:10:13 --- STRACE: Kohana_Exception [ 0 ]: Cannot update userroles model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1284 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/users.php(59): Kohana_ORM->update()
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/users.php(46): Model_Admin_Users->admin_users_edit('4')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(197): Controller_Admin_Users->users_edit('4')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('users/edit/4')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-09-23 03:10:14 --- ERROR: Kohana_Exception [ 0 ]: Cannot update userroles model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1284 ]
2013-09-23 03:10:14 --- STRACE: Kohana_Exception [ 0 ]: Cannot update userroles model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1284 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/users.php(59): Kohana_ORM->update()
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/users.php(46): Model_Admin_Users->admin_users_edit('4')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(197): Controller_Admin_Users->users_edit('4')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('users/edit/4')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-09-23 03:11:15 --- ERROR: Kohana_Exception [ 0 ]: Cannot update userroles model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1284 ]
2013-09-23 03:11:15 --- STRACE: Kohana_Exception [ 0 ]: Cannot update userroles model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1284 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/users.php(59): Kohana_ORM->update()
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/users.php(46): Model_Admin_Users->admin_users_edit('4')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(197): Controller_Admin_Users->users_edit('4')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('users/edit/4')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-09-23 03:12:31 --- ERROR: Kohana_Exception [ 0 ]: Cannot update userroles model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1284 ]
2013-09-23 03:12:31 --- STRACE: Kohana_Exception [ 0 ]: Cannot update userroles model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1284 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/users.php(59): Kohana_ORM->update()
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/users.php(46): Model_Admin_Users->admin_users_edit('4')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(197): Controller_Admin_Users->users_edit('4')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('users/edit/4')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-09-23 03:12:32 --- ERROR: Kohana_Exception [ 0 ]: Cannot update userroles model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1284 ]
2013-09-23 03:12:32 --- STRACE: Kohana_Exception [ 0 ]: Cannot update userroles model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1284 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/users.php(59): Kohana_ORM->update()
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/users.php(46): Model_Admin_Users->admin_users_edit('4')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(197): Controller_Admin_Users->users_edit('4')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('users/edit/4')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-09-23 03:12:32 --- ERROR: Kohana_Exception [ 0 ]: Cannot update userroles model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1284 ]
2013-09-23 03:12:32 --- STRACE: Kohana_Exception [ 0 ]: Cannot update userroles model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1284 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/users.php(59): Kohana_ORM->update()
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/users.php(46): Model_Admin_Users->admin_users_edit('4')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(197): Controller_Admin_Users->users_edit('4')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('users/edit/4')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-09-23 03:14:00 --- ERROR: Kohana_Exception [ 0 ]: Cannot update userroles model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1284 ]
2013-09-23 03:14:00 --- STRACE: Kohana_Exception [ 0 ]: Cannot update userroles model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1284 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/users.php(59): Kohana_ORM->update()
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/users.php(46): Model_Admin_Users->admin_users_edit('4')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(197): Controller_Admin_Users->users_edit('4')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('users/edit/4')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-09-23 03:14:05 --- ERROR: Kohana_Exception [ 0 ]: Cannot update userroles model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1284 ]
2013-09-23 03:14:05 --- STRACE: Kohana_Exception [ 0 ]: Cannot update userroles model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1284 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/users.php(59): Kohana_ORM->update()
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/users.php(46): Model_Admin_Users->admin_users_edit('4')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(197): Controller_Admin_Users->users_edit('4')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('users/edit/4')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-09-23 03:18:01 --- ERROR: Kohana_Exception [ 0 ]: Cannot update userroles model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1284 ]
2013-09-23 03:18:01 --- STRACE: Kohana_Exception [ 0 ]: Cannot update userroles model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1284 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/users.php(47): Kohana_ORM->update()
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/users.php(46): Model_Admin_Users->admin_users_edit('4')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(197): Controller_Admin_Users->users_edit('4')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('users/edit/4')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-09-23 03:18:28 --- ERROR: Kohana_Exception [ 0 ]: Cannot update userroles model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1284 ]
2013-09-23 03:18:28 --- STRACE: Kohana_Exception [ 0 ]: Cannot update userroles model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1284 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/users.php(47): Kohana_ORM->update()
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/users.php(46): Model_Admin_Users->admin_users_edit('4')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(197): Controller_Admin_Users->users_edit('4')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('users/edit/4')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-09-23 03:19:58 --- ERROR: Kohana_Exception [ 0 ]: Cannot update userroles model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1284 ]
2013-09-23 03:19:58 --- STRACE: Kohana_Exception [ 0 ]: Cannot update userroles model because it is not loaded. ~ MODPATH/orm/classes/kohana/orm.php [ 1284 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/classes/model/admin/users.php(47): Kohana_ORM->update()
#1 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin/users.php(46): Model_Admin_Users->admin_users_edit('4')
#2 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(197): Controller_Admin_Users->users_edit('4')
#3 /var/www/zeloras/data/www/sxservice.ru/application/classes/controller/admin.php(33): Controller_Admin->routes('users/edit/4')
#4 [internal function]: Controller_Admin->action_route()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin))
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#9 {main}
2013-09-23 03:34:35 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Userroles as array ~ APPPATH/classes/controller/admin/users.php [ 13 ]
2013-09-23 03:34:35 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Userroles as array ~ APPPATH/classes/controller/admin/users.php [ 13 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-09-23 03:35:21 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Model_Userroles as array ~ APPPATH/classes/controller/admin/users.php [ 17 ]
2013-09-23 03:35:21 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Model_Userroles as array ~ APPPATH/classes/controller/admin/users.php [ 17 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2013-09-23 03:35:33 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/views/admin/users/index.php [ 65 ]
2013-09-23 03:35:33 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/views/admin/users/index.php [ 65 ]
--
#0 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/users/index.php(65): Kohana_Core::error_handler(8, 'Trying to get p...', '/var/www/zelora...', 65, Array)
#1 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#2 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#3 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /var/www/zeloras/data/www/sxservice.ru/application/views/admin/desktop.php(82): Kohana_View->__toString()
#5 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(61): include('/var/www/zelora...')
#6 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/view.php(343): Kohana_View::capture('/var/www/zelora...', Array)
#7 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 [internal function]: Kohana_Controller_Template->after()
#9 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin))
#10 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /var/www/zeloras/data/www/sxservice.ru/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /var/www/zeloras/data/www/sxservice.ru/index.php(109): Kohana_Request->execute()
#13 {main}