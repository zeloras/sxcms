<title><?echo $title;?></title>
<meta name="description" content="<?echo $description;?>" />		
<meta name="keywords" content="<?echo $keywords;?>" />
