<?echo $breadcrumbs;?>
<div class="center">
    <?echo $page[0]->text;?>
</div>