<div class="main">
    <div class="container">
        <div class="row">
            <div class="span12">
                <div class="widget stacked">	
                    <div class="widget-header">
                        <i class="icon-file"></i>
                        <h3><?=__('Pages list')?></h3>
                        <span class="action_buttons">
                            <?if (in_array(12, $access_code)) {?>
                            <button class="btn btn-info pull-right pjax_button" data-href="/admin/pages/add" data-container="#base-container">
                                <i class="icon-plus-sign-alt icon-large"></i> <?=__('Create')?>
                            </button>
                            <?}?>
                            
                            <?if (in_array(14, $access_code)) {?>
                            <button class="btn btn-danger pull-right sx_modal_show" data-modal=".sx_remove_page">
                                <i class="icon-trash icon-large"></i> <?=__('Delete')?>
                            </button>
                            <?}?>
                        </span>
                    </div>

                    <div class="widget-content">
                        <table class="table table-bordered table-striped table-highlight">
                            <thead>
                              <tr>
                                <th class="box-center">
                                    <?if (in_array(14, $access_code)) {?>
                                    <span class="niceCheck" id="sx_checkbox_general">
                                        <input type="checkbox" data-inputs=".checkbox_slected">
                                    </span>
                                    <?}?>
                                </th>
                                <th><?=__('ID')?></th>
                                <th><?=__('Title')?></th>
                                <th><?=__('URL')?></th>
                                <th><?=__('Category')?></th>
                                <th><?=__('Created')?></th>
                                <th><?=__('Status')?></th>
                              </tr>
                            </thead>
                            <tbody>
                                <?foreach ($pages as $key => $page) {?>
                                  <tr>
                                    <td class="box-center">
                                        <?if (in_array(14, $access_code)) {?>
                                        <span class="niceCheck">
                                            <input type="checkbox" name="ids" value="<?=$page->id?>" class="checkbox_slected">
                                        </span>
                                        <?}?>
                                    </td>
                                    <td><?=$page->id?></td>
                                    <td>
                                        <?if (in_array(13, $access_code)) {?>
                                        <a href="/admin/pages/edit/<?=$page->id?>">
                                                <?=$page->title?>
                                        </a>
                                        <?}else{?>
                                            <?=$page->title?>
                                        <?}?>
                                    </td>
                                    <td class="show_hidden" data-class=".hidden_button">
                                        <?=$page->url?>
                                        <?if ($page->url != '/') {?>
                                            <a href="/<?=$category_info[$key]['full_url']?><?=$page->url?>" target="_blank" class="hidden_button pull-right btn btn-small" style="visibility: hidden;">
                                                <i class="icon-share-alt"></i>
                                            </a>
                                        <?} else {?>
                                            <a href="/" target="_blank" class="hidden_button pull-right btn btn-small" style="visibility: hidden;">
                                                <i class="icon-share-alt"></i>
                                            </a>
                                        <?}?>
                                    </td>
                                    <td>
                                        <?if ($category_info[$key]['id'] > 0) {?>
                                        <a href="/admin/categorys/<?=$category_info[$key]['id']?>">
                                            <?=$category_info[$key]['title']?>
                                        </a>
                                        <?}else{?>
                                            <?=$category_info[$key]['title']?>
                                        <?}?>
                                    </td>
                                    <td><?=date('d-m-y H:i', $page->date)?></td>
                                    <td><?=$page->status?></td>
                                  </tr>
                                <?}?>
                            </tbody>
                      </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal hide sx_remove_page" aria-hidden="true">
  <div class="modal-header">
    <button type="button" class="close sx_modal_hide" data-modal=".sx_remove_page">×</button>
    <h3><?=__('Remove pages')?></h3>
  </div>
  <div class="modal-body">
    <p><?=__('Do you really want to delete the selected pages?')?></p>
  </div>
  <div class="modal-footer">
    <a href="javascript:;" class="btn sx_modal_hide" data-modal=".sx_remove_page"><?=__("Cancel")?></a>
    <a href="javascript:;" class="btn btn-primary sx_modal_hide sx_remove_function" data-modal=".sx_remove_page" data-href="pages"><?=__('Delete')?></a>
  </div>
</div>