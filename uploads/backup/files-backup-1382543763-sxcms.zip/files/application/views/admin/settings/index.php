<div class="main">
    <div class="container">
        <div class="row">
      	
            <div class="span10">
                <div class="widget stacked">			
                    <div class="widget-header">
                            <i class="icon-wrench"></i>
                            <h3><?=__('Settings')?></h3>
                    </div>
				
                    <div class="widget-content">
                        <div class="tab-content">
                            <div class="tab-pane fade active in" id="settings-global">
                                <div class="form-horizontal">
                                    
                                    <table class="table table-bordered table-hover">
                                        <thead>
                                            <tr>
                                                <th colspan="6">
                                                    <?=__('Settings')?>                        
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr class="">
                                                <td colspan="6">
                                                    <div class="control-group">
                                                        <div class="control-label"><?=__('Site name')?></div>
                                                        <div class="controls">
                                                            <input type="text" name="settings[general][site_name]" value="<?=$settings['general']['site_name']?>">
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="control-group">
                                                        <div class="control-label"><?=__('Disable site?')?></div>
                                                        <div class="controls">
                                                            <input type="text" name="settings[general][disable_site]" value="<?=$settings['general']['disable_site']?>">
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="control-group">
                                                        <div class="control-label"><?=__('Language')?></div>
                                                        <div class="controls">
                                                            <input type="text" name="settings[general][language]" value="<?=$settings['general']['language']?>">
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="control-group">
                                                        <div class="control-label"><?=__('Text editor')?></div>
                                                        <div class="controls">
                                                            <input type="text" name="settings[general][text_editor]" value="<?=$settings['general']['text_editor']?>">
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    
                                    <table class="table table-bordered table-hover">
                                        <thead>
                                            <tr>
                                                <th colspan="6">
                                                    SEO                        
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr class="">
                                                <td colspan="6">
                                                    <div class="control-group">
                                                        <div class="control-label"><?=__('Short site name')?></div>
                                                        <div class="controls">
                                                            <input type="text" name="settings[seo][site_name]" value="<?=$settings['seo']['site_name']?>">
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="control-group">
                                                        <div class="control-label"><?=__('Description')?></div>
                                                        <div class="controls">
                                                            <input type="text" name="settings[seo][description]" value="<?=$settings['seo']['description']?>">
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="control-group">
                                                        <div class="control-label"><?=__('Keywords')?></div>
                                                        <div class="controls">
                                                            <input type="text" name="settings[seo][keywords]" value="<?=$settings['seo']['keywords']?>">
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            
                            
                            
                            <div class="tab-pane fade" id="settings-template">
                                <?if (isset($success_template)) {?>
                                    <div id="template_status_block">
                                        <p id="status_success">showMessage('<?=__('Success change template')?>', '<?=__('Status template change')?>', 'success')</p>
                                    </div>
                                <?}?>
<table class="table table-bordered table-hover">
        <thead>
            <tr>
                <th colspan="6">
                    Шаблоны                                    
                </th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td colspan="6">
                    <div class="control-group">
                        <label class="control-label">Выбор шаблона для сайта:</label>
                        <div class="controls">
                            <select data-div=".information" class="sx_template_view" style="">
                                <?foreach ($templates as $tpl) {?>
                                    <option <?if ($template_current == $tpl['base']['name']) {?> selected="selected" <?}?>
                                        data-png="<?=$tpl['base']['png']?>"
                                        data-author="<?=$tpl['author']['name']?>"
                                        data-contacts="<?=$tpl['author']['contacts']?>"
                                        value="<?=$tpl['base']['name']?>">
                                        <?=$tpl['base']['title_rus']?>
                                    </option>
                                <?}?>
                            </select>
                                <input type="button" data-value=".sx_template_view" class="sx_save_template btn btn-primary" value="Изменить шаблон">
                        </div>

                        <div class="information">
                            <div class="base">
                                <table class="table table-striped table-bordered table-hover table-condensed">
                                    <thead>
                                        <tr>
                                            <th colspan="2">
                                                Информация о шаблоне                                    
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Шаблон:</td><td><?=$template_current?></td>
                                        </tr>

                                        <tr>
                                            <td>Автор:</td><td><?=$tpl['author']['name']?></td>
                                        </tr>

                                        <tr>
                                            <td colspan="2"><img width="250px" height="250px" src="<?=$tpl['base']['png']?>" /></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            <div class="contacts">
                                <table class="table table-striped table-bordered table-hover table-condensed">
                                    <thead>
                                        <tr>
                                            <th colspan="2">
                                                Информация о авторе                                    
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <? foreach ($tpl['author']['contacts_uns'] as $keyz => $cont) {?>
                                            <tr>
                                                <td><?=$keyz?></td>
                                                <td><?=$cont?></td>
                                            </tr>
                                        <?}?>
                                    </tbody>
                                </table>
                            </div>
                        </div> 
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
                            </div>
                            
                            
                            
                            <div class="tab-pane fade" id="settings-backup">
                                <?if (isset($success_backup_create)) {?>
                                    <div id="backup_status_block">
                                        <p id="status_success">showMessage('<?=__('Success create backup')?>', '<?=__('Status backup create')?>', 'success')</p>
                                    </div>
                                <?}?>
                                
                                <?if (isset($success_backup_delete)) {?>
                                    <div id="backup_status_block">
                                        <p id="status_success">showMessage('<?=__('Success delete backup')?>', '<?=__('Status backup delete')?>', 'success')</p>
                                    </div>
                                <?}?>
  <table class="table table-striped table-bordered table-hover table-condensed">
        <thead>
            <tr>
                <th colspan="6">
                    Бэкапы системы                                    
                </th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td colspan="6">
                    <div class="inside_padd">
                        <div class="control-group">
                            <label class="control-label">Резервная копия:</label>
                            <div class="controls">
                              <select class="select_backup_type">
                                  <option value="1"><?=__('Files')?></option>
                                  <option value="2"><?=__('Database')?></option>
                                  <option value="3"><?=__('Files & database')?></option>
                              </select>
                            </div>
                        </div> 
                        
                        <div class="control-group">
                            <div class="controls">
                              <button type="button" class="btn btn-small btn-primary action_on sx_new_backup" data-form="#settings_form" data-select=".select_backup_type"><i class="icon-ok"></i><?=__('Create new backup')?></button>
                            </div>
                        </div>
                        
                        <div class="control-group">
                            <label class="control-label">Готовые бэкапы:</label>
                            <div class="backups_list">
                            <?if (is_array($backup_mysql)) {?>
                                <ul>
                               <? foreach ($backup_mysql as $backup) {?>
                                   <li>
                                        <div class="first">
                                            <a href="/admin/components/run/myshop/download_file_backup/<?=$backup['link']?>" target="_blank">
                                                <?=$backup['name']?> -- Создан <?=date("d.m.Y H:i", $backup['time'])?>
                                            </a> 
                                            (<a href="javascript:void(0)" data-value="<?=$backup['link']?>" data-value-data=".sx_remove_backup" data-name="<?=date("d.m.Y", $backup['time'])?>" data-modal=".sx_remove_backup" data-span-name=".backup_name" class="sx_remove_backup_modal">
                                                Удалить
                                            </a>)
                                        </div>
                                                
                                        <div  class="second">
                                            <?if (@$cloud['yandex']['active'] == 1) {?>
                                                <?if ($cloud_files[$backup['link']]) {?>
                                                    <button type="button" class="btn btn-small btn-primary sx_cloud_delete" data-service="yandex" data-link="<?=$backup['link']?>">
                                                        <i class="icon-remove"></i>Удалить с диска
                                                    </button>
                                                <?}else{?>
                                                    <button type="button" class="btn btn-small btn-primary sx_cloud_save" data-service="yandex" data-link="<?=$backup['link']?>">
                                                        <i class="icon-file"></i>Сохранить на диск
                                                    </button>
                                                <?}?>
                                            <?}?>
                                            
                                            <?if (@$cloud['ftp']['active'] == 1) {?>
                                                <?if ($ftp_files[$backup['link']]) {?>
                                                    <button type="button" class="btn btn-small btn-primary sx_ftp_delete" data-service="ftp" data-link="<?=$backup['link']?>">
                                                        <i class="icon-remove"></i>Удалить с FTP
                                                    </button>
                                                <?}else{?>
                                                    <button type="button" class="btn btn-small btn-primary sx_ftp_save" data-service="ftp" data-link="<?=$backup['link']?>">
                                                        <i class="icon-file"></i>Сохранить на FTP
                                                    </button>
                                                <?}?>
                                            <?}?>
                                        </div>
                                   </li>
                               <?}?>
                               </ul>
                            <?}else{?>
                                <div><?=__('No backups')?></div> 
                            <?}?>
                            </div>
                        </div>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
                            </div>
                            
                            
                            
                            <div class="tab-pane fade" id="settings-remote">
                              <strong>Tab #4</strong>
                              <p>Trust fund seitan letterpress, keytar raw denim keffiyeh etsy art party before they sold out master cleanse gluten-free squid scenester freegan cosby sweater. Fanny pack portland seitan DIY, art party locavore wolf cliche high life echo park Austin. Cred vinyl keffiyeh DIY salvia PBR, banh mi before they sold out farm-to-table VHS viral locavore cosby sweater. Lomo wolf viral, mustache readymade thundercats keffiyeh craft beer marfa ethical. Wolf salvia freegan, sartorial keffiyeh echo park vegan.</p>
                            </div>
                        </div>
                    </div>
					
                </div> 	
            </div>
	        
	    
	    <div class="span2">	
                <div class="widget widget-plain">
                    <div class="widget-content">
                        <ul class="nav nav-pills nav-stacked" style="max-width: 300px;">
                            <li class="active">
                                <a href="#settings-global" data-toggle="tab"><?=__('Global settings')?></a>
                            </li>

                            <li>
                                <a href="#settings-template" data-toggle="tab"><?=__('Template')?></a>
                            </li>

                            <li>
                                <a href="#settings-backup" data-toggle="tab"><?=__('Backups')?></a>
                            </li>
                            
                            <li>
                                <a href="#settings-remote" data-toggle="tab"><?=__('Cloud/Ftp')?></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
      	
      </div> 
    </div>  
</div>

<div class="modal hide sx_remove_backup" aria-hidden="true">
  <div class="modal-header">
    <button type="button" class="close sx_modal_hide" data-modal=".sx_remove_backup">×</button>
    <h3><?=__('Remove backup')?></h3>
  </div>
  <div class="modal-body">
    <p><?=__('Do you really want to delete the selected backup?')?></p>
  </div>
  <div class="modal-footer">
    <a href="javascript:;" class="btn sx_modal_hide" data-modal=".sx_remove_backup"><?=__("Cancel")?></a>
    <a href="javascript:;" class="btn btn-primary sx_modal_hide sx_remove_function" data-modal=".sx_remove_backup" data-href="backup"><?=__('Delete')?></a>
  </div>
</div>