js = new Object;
js.loadedModules = new Array;
js.include = function(path) {
    if(js.loadedModules[path]) return;
    js.loadedModules[path] = true;
    $.ajax({
        url: path,
        dataType: "script",
        async: false,
        success: function(js){if(jQuery.browser.safari){eval(js);}}
    });
 
} //Взял этот с крипт с сайта netopalto.ru большое спасибо автору за этот скрипт.

js.include('/application/views/admin/js/comm/jquery.validate.js'); //Инклюдим файл с валидатором 
js.include('/application/views/admin/bootstrap/js/bootstrap.js'); //Инклюдим файл с twitter bootstrap
js.include('/application/views/admin/js/comm/jquery-ui-1.10.3.custom.min.js'); //Инклюдим файл Jquery UI
js.include('/application/views/admin/js/comm/pjax.js'); //Инклюдим файл с jaddress
js.include('/application/views/admin/js/comm/checkbox.jquery.js'); //Инклюдим файл с красивыми чекбоксами
js.include('/application/views/admin/js/comm/jquery.form.js'); //Инклюдим файл с асинхронной отправкой формы
js.include('/application/views/admin/js/comm/msgGrowl.js'); //Инклюдим файл с красивыми алертами
js.include('/application/views/admin/js/comm/Application.js'); //Инклюдим файл со всякими вкусностями

js.include('/application/views/admin/js/class.js'); //Инклюдим файл с классами
js.include('/application/views/admin/js/binds.js'); //Инклюдим файл с биндами
js.include('/application/views/admin/js/functions.js'); //Инклюдим файл с функциями
js.include('/application/views/admin/js/loader.js'); //Инклюдим файл с автозагрузками скриптами

js.include('/application/views/admin/js/elrite/js/elrte.min.js'); //Подключаем редактор elrite
js.include('/application/views/admin/js/elrite/js/i18n/elrte.ru.js'); //Подключаем русский ящык для elrite