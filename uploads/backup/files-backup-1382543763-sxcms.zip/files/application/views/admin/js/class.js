var mysx_functions = new Object({
    sortTable: function (label) {
            $(label).find('tr').not(':has(tr)').tooltip({
                'placement': 'top',
                'delay': {
                    show: 500,
                    hide: 100
                }
            }).css('cursor', 'move');
            $(label).sortable({
                axis: 'y',
                cursor: 'move',
                scroll: true,
                containment: $(label),
                cancel: 'td a, td input, td select, thead',
                helper: function(e, tr)
                {
                    var $originals = tr.children();
                    var $helper = tr.clone();
                    $helper.children().each(function(index)
                    {
                        $(this).width($originals.eq(index).width())
                    });
                    $helper.addClass('active');
                    return $helper;
                }

            }); 
    },
    checkbox_select:function (label) {
        $inputs = $(label).find("input").data("inputs");
        $checked = $(label).find("input").prop("checked");
        
        if (!$checked)
        {
            $($inputs).parent().css("background-position","0 -17px");
            $($inputs).prop("checked", true);
        }
        else
        {
            $($inputs).parent().css("background-position","0 0");
            $($inputs).prop("checked", false);
        }
    },
            
    niceCheck: function (label) {
             $input = $(label).find("input").eq(0);
             if(!$input.prop("checked")) {
                    $(label).css("background-position","0 -17px");	
                    $input.prop("checked", true)
            } else {
                    $(label).css("background-position","0 0");	
                    $input.prop("checked", false)
            }
    },
            
    pjax: function (label) {
        $href = $(label).data("href");
        $container = $(label).data("container");
        $.pjax({url: $href, container: $container});
    },
            

    formSubmit: function(label) {

    var selector = $(label).data('form');
    var action = $(label).data('action');
    var after = $(label).data('after');
    
    $(selector).validate();
    
    if ($(selector).valid())
    {
        $('#page-loading').fadeIn(100);
        var options = {
            beforeSubmit: function(formData) {
                formData.push({
                    name: "action",
                    value: action
                });
            },
            success: function(data) {
                $('#page-loading').fadeOut(100);
                $("#errors_block").hide();
                $errors_data = $(data).find("#errors_block");
                $success_data = $(data).find("#success_block");
                if ($success_data.size() < 1)
                {
                    $("#errors_block").html($errors_data.html());
                    $("#errors_block").fadeIn();
                }
                else
                {
                    $message = $success_data.find("#status_success").text();
                    $link = (after == "exit") ? $success_data.find("#url_success_exit").text(): $success_data.find("#url_success").text();
                    eval($message);
                    setTimeout(function () {
                        document.location.href = $link;
                    }, 1200);
                }
                return true;
            }
        };
        $(selector).ajaxSubmit(options);
    }
},
        
deleteConfirm: function (label) {
 $href = "/admin/syscom/ajax_delete/"+$(label).data("href");
        $modal = $(label).data("modal");
        var ids = new Array();
        $('input[name=ids]:checked').each(function() {
            ids.push($(this).val());
        });
        $.post($href, {
            ids: ids
        }, function(data) {
            $block = $(data).find("#status_delete_block");
            showMessage($block.find("#delete_text").text(), 'Статус удаления', $block.find("#delete_status").text())
            setTimeout(function () {
                document.location.reload();
            }, 1200);
        });
    return true; 
},

showHidden: function(label, type) {
    $class = $(label).data("class");
    if (type == 'show')
    {
        $(label).find($class).css("visibility", "visible");
    }
    else
    {
        $(label).find($class).css("visibility", "hidden");
    }
},
      
translitUrl: function (label) {
    $title = $(label).data('title');
    $url = $(label).data('url');
    $.post('/admin/syscom/getTranslitUrl', {text_translit: $($title).val()}, function (data) {
        $text = $(data).find("#translit_text").text();
        $($url).val($text);
    });
},
save_positions: function (label) {        
    $arr = new Array();
    $type = $(label).data('type');
    $('input[name=ids]').each(function() {
        $arr.push($(this).val());
    });
    
    $.post('/admin/syscom/ajax_save_position/'+$type, {positions: $arr}, function(data) 
    {
        $block = $(data).find("#save_position_status_block");
        showMessage($block.find("#position_text").text(), 'Статус сортировки', $block.find("#position_status").text())
    });
}

});

var mysx_modal = new Object({
    show: function (label) {
        $modal = $(label).data("modal");
        $($modal).fadeIn();
        $("#modal-background").fadeIn();
    },
            
    hide: function (label) {
        $modal = $(label).data("modal");
        $($modal).fadeOut();
        $("#modal-background").fadeOut();
    },
});

var mysx_menu = new Object({
    selectType: function (label) {
        $value = $(label).val();
        $fblock = $(label).data('first');
        $sblock = $(label).data('second');
        $tblock = $(label).data('threed');
        $this = $($fblock);
        $this_2 = $($sblock);
        $this_3 = $($tblock)
        $this.removeClass("hide");
        if ($value == 1)
        {
            $this_2.addClass("hide");
            $this_3.addClass("hide");
            $this.find("label").text("Ссылка на категорию");
            $this_2.addClass("hide");
            $.get('/admin/syscom/getCategorys_opt/', function (data) {
                $options = $(data).find("#select-category");
                $this.find("select").html(($options.html()));
            });
        }
        
        if ($value == 2)
        {
            $this_3.addClass("hide");
            $this.find("label").text("Категория");
            $.get('/admin/syscom/getCategorys_opt/', function (data) {
                $options = $(data).find("#select-category");
                $this.find("select").html(($options.html()));
            });
        }
        
        if ($value == 3)
        {
            $this.find("label").text("Ссылка на");
            $this_2.addClass("hide");
            $this_3.addClass("hide");
            $.get('/admin/syscom/getSystem_opt/', function (data) {
                $options = $(data).find("#select-system");
                $this.find("select").html(($options.html()));
            });
        }
        
        if ($value == 4)
        {
            $this_2.addClass("hide");
            $this.addClass("hide");
            $this_3.removeClass("hide");
            $this.addClass("hide");
        }
    },
    
    selectCategory: function (label) {
        $value = $(label).val();
        $sblock = $(label).data('second');
        $fblock = $(label).data('first');
        $tblock = $(label).data('type');
        $this_3 = $($tblock);
        $this_2 = $($sblock);
        $this_1 = $($fblock);
        
        if ($this_3.find("select").val() == 2)
        {
            $this_2.removeClass("hide");
            $.get('/admin/syscom/getPages_opt/'+$value, function (data) {
                $options = $(data).find("#select-page");
                $this_2.find("select").html(($options.html()));
            });
        }
        else
        {
            $this_2.addClass("hide");
        }
    }
});


var mysx_change_function = new Object({
        changeTemplate:function(label) {
            $image = $(label).find("option:selected").data("png");
            $div_block = $($(label).data("div"));
            $template = $(label).val();
            $author = $(label).find("option:selected").data("author");
            $contacts = $(label).find("option:selected").data("contacts");
            $contacts_exp = $contacts.split(',, ');
            $contacts_exp.pop();
            $div_block.find(".contacts tbody").find("tr").remove();
            $div_block.find(".base tbody").find("tr").remove();
            for (var key in $contacts_exp) {
                var val = $contacts_exp[key].split("::");
                $div_block.find(".contacts tbody").append('<tr><td>'+val[0]+':</td> <td>'+val[1]+'</td></tr>');
            }
            
            $div_block.find(".base tbody").append('<tr><td>Шаблон:</td><td>'+$template+'</td></tr>');
            
            $div_block.find(".base tbody").append('<tr><td>Автор:</td><td>'+$author+'</td></tr>');
            
            $div_block.find(".base tbody").append('<tr><td colspan="2"><img width="250px" height="250px" src="'+$image+'" /></td></tr>');
        },
                
        submitTemplate:function(label) {
            $value = $($(label).data("value")).val();
            $.post('/admin/settings', {
                    templatedir: $value,
                    change_template_base: 1,
                }, function(data) {
                    $block = $(data).find("#template_status_block");
                    eval($block.find("#status_success").text());
                });
        },
});



var mysx_backup = new Object({

deleteConfirm:function (label) {
        $value = $(label).data("value");
        $update_block = $(label).data("block");
        $href = "/admin/components/run/myshop/delete_backup/";
        $modal = $(label).data("modal");
        $.post($href, {
            backup: $value
        }, function(data) {
            $block = $(data).find("#backup_status_block");
            eval($block.find("#status_success").text());
        });
        mysx_modal.hide($modal);
        return false;
    },
    
deleteModal:function (label) {
            $b_name = $(label).data("name");
            $b_span_name = $(label).data("span-name");
            $value = $(label).data("value");
            $value_data = $(label).data("value-data");
            $($b_span_name).text($b_name);
            $($value_data).attr("data-value", $value);
            console.log($($value_data).data("value"));
            mysx_modal.show(label);
        },
        
createBackup:function (label) {
            $inval = $($(label).data('select')).val();
            $.post('/admin/settings/', {
                    submit_this_backup: 1,
                    select_backup_type: $inval,
                }, function(data) {
                    $block = $(data).find("#backup_status_block");
                    eval($block.find("#status_success").text());
                });
                return true;
        },
});
