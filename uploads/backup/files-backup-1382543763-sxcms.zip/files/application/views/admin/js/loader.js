    
$(document).ready(function () {
elRTE.prototype.options.panels.mypanelbar = [
     'bold', 'italic', 'underline', 'forecolor', 'justifyleft', 'justifyright',
     'justifycenter', 'justifyfull', 'formatblock', 'fontsize', 'fontname', 'insertorderedlist', 'insertunorderedlist',
     'link', 'image'
];
elRTE.prototype.options.toolbars.mypanelbar = ['mypanelbar'];
    var opts = {
            cssClass : 'el-rte',
            lang     : 'ru',
            height   : 250,
            width    : 700,
            toolbar  : 'mypanelbar',
            cssfiles : ['css/elrte-inner.css']
    }
    var elrite = $('.elrite').elrte(opts);
});