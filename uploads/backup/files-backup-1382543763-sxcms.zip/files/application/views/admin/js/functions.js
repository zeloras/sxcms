function showMessage($message, $title, $type)
{
    $title = ($title == null) ? 'Информация' : $title;
    $type = ($type == null) ? 'info' : $type;
    $.msgGrowl ({type: $type, title: $title, text: $message});
}
