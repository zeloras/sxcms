$("#sx_checkbox_general").bind('click', function() {
    mysx_functions.checkbox_select(this);
});

$(".niceCheck").bind('click', function() {
        mysx_functions.niceCheck(this);
});

$(".sx_modal_show").bind('click', function () {
    mysx_modal.show(this);
});

$(".sx_modal_hide").bind('click', function () {
    mysx_modal.hide(this);
});

$(".pjax_button").bind('click', function () {
    mysx_functions.pjax(this);
});

$(".formSubmit").bind('click', function () {
    mysx_functions.formSubmit(this);
});

$('.sx_remove_function').live('click', function() {
    mysx_functions.deleteConfirm(this);
});
    

$('#category .btn:has(.icon-plus)').die('click').live('click', function() {
    var $this = $(this);
    $this.closest('.row-category').next().show();
    $this.hide().prev().show();
});
$('#category .btn:has(.icon-minus)').die('click').live('click', function() {
    var $this = $(this);
    $this.closest('.row-category').next().hide();
    $this.hide().next().show();
});

$('.sx_sort_table').bind('mouseover', function () {
    mysx_functions.sortTable(this);
});

$('.show_hidden').bind('mouseover', function () {
    mysx_functions.showHidden(this, 'show');
});

$('.show_hidden').bind('mouseout', function () {
    mysx_functions.showHidden(this, 'hide');
});

$('.sx_menu_type').bind('change', function () {
    mysx_menu.selectType(this);
});

$('.sx_menu_first').bind('change', function () {
    mysx_menu.selectCategory(this);
});

$('.sx_translit_url').bind('click', function () {
    mysx_functions.translitUrl(this);
});

$(".sx_save_positions").bind("sortstop", function() {
    mysx_functions.save_positions(this);
});

$('.sx_template_view').bind('change', function () {
    mysx_change_function.changeTemplate(this);
});

$('.sx_save_template').bind('click', function () {
    mysx_change_function.submitTemplate(this);
});

$('.sx_remove_backup_modal').bind('click', function() {
    mysx_backup.deleteModal(this);
});

$('.sx_remove_backup').bind('click', function() {
    mysx_backup.deleteConfirm(this);
});

$('.sx_new_backup').live('click',function() {
    mysx_backup.createBackup(this);
});