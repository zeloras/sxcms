<div class="main">
    <div class="container">
        <div class="row">
            <div class="span12">
                <div class="widget stacked">
<div class="widget-header">
    <i class="icon-file"></i>
    <h3><?=__('Link create')?></h3>
    <span class="action_buttons">
        <button class="btn pull-right formSubmit" data-form="#submit-form" data-after="exit" data-action="/admin/menus_data/edit/<?=$menu_id?>/<?=$item_id?>">
            <i class=" icon-save icon-large"></i> <?=__('Save and exit')?>
        </button>
        <button class="btn btn-success pull-right formSubmit" data-form="#submit-form" data-after="save" data-action="/admin/menus_data/edit/<?=$menu_id?>/<?=$item_id?>">
            <i class=" icon-save icon-large"></i> <?=__('Save')?>
        </button>
        <button data-href="/admin/menus_data/<?=$menu_id?>" data-container="#base-container" class="btn pull-right btn-info pjax_button">
            <i class="icon-arrow-left"></i> <?=__('Back')?>
        </button>
    </span>
</div>
                    
<div class="widget-content">
    <?if (isset($success)) {?>
        <div id="success_block">
            <p id="status_success">showMessage('<?=__('Success create link')?>', '<?=__('Status link create')?>', 'success')</p>
            <p id="url_success">/admin/menus_data/edit/<?=$menu_id?>/<?=$item_id?></p>
            <p id="url_success_exit">/admin/menus_data/<?=$menu_id?></p>
        </div>
    <?}?>
    <div id="errors_block">
        <?if (isset($errors)) {?>
        <div class="alert alert-error">
            <strong>Ошибка!</strong>
            <ul>
                <?foreach ($errors as $error) {?>
                    <li><?=__($error)?></li>
                <?}?>
            </ul>
        </div>
        <?}?>
    </div>	
    <form id="submit-form" method="post" class="form-horizontal">
        <div class="tab-content">
            <input type="hidden" name="submit_this_form" value="1">
            <input type="hidden" name="menu_id" value="<?=$menu_id?>">
            <input type="hidden" name="item_id" value="<?=$item_id?>">
            <div class="tab-pane active" id="content">
                
                <div class="control-group sx_menu_block_type">
                    <label class="control-label" for="linktype_p"><?=__('Link type')?></label>
                    <div class="controls">
                        <select class="input-xxlarge sx_menu_type" name="linktype" id="linktype_p" data-first=".sx_menu_block_first" data-second=".sx_menu_block_second">
                            <option value="1" <?if ($sel['type'] == 1) {?>selected="selected"<?}?>><?=__("Category")?></option>
                            <option value="2" <?if ($sel['type'] == 2) {?>selected="selected"<?}?>><?=__("Page")?></option>
                            <option value="3" <?if ($sel['type'] == 3) {?>selected="selected"<?}?>><?=__("System")?></option>
                            <option value="4" <?if ($sel['type'] == 4) {?>selected="selected"<?}?>><?=__("Link")?></option>
                        </select>
                    </div>
                </div>
                
                <div class="control-group sx_menu_block_first <?if ($sel['type'] == 4){?>hide<?}?>">
                    <label class="control-label" for="first_p"><?=__('Category')?></label>
                    <div class="controls">
                        <select class="input-xxlarge sx_menu_first" name="first" id="first_p" data-second=".sx_menu_block_second" data-first=".sx_menu_block_first" data-type=".sx_menu_block_type">
                            <?if ($sel['type'] == 3) {?>
                            <option value="/" <?if ($sel['first'] == '/') {?>selected="selected"<?}?>><?=__('home')?></option>
                            <option value="/category" <?if ($sel['first'] == '/category') {?>selected="selected"<?}?>><?=__('categorys')?></option>
                            <?}else{?>
                                <?=$sel['first']?>
                            <?}?>
                        </select>
                    </div>
                </div>
                
                
                <div class="control-group sx_menu_block_second <?if ($sel['type'] != 2) {?>hide<?}?>">
                    <label class="control-label" for="second_p"><?=__('Page')?></label>
                    <div class="controls">
                        <select class="input-xxlarge" name="second" id="second_p">
                            <?if (strlen($sel['second']) > 0) {?>
                                <?foreach ($sel['sechtml'] as $pages) {?>
                                    <option value="<?=$pages->url?>" <?if ($sel['second'] == $pages->url) {?>selected="selected"<?}?>><?=$pages->title?></option>
                                <?}?>
                            <?}else{?>
                                <option value="0"><?=__('select')?></option>
                            <?}?>
                        </select>
                    </div>
                </div>
                
                <div class="control-group sx_menu_block_threed <?if ($sel['type'] != 4){?>hide<?}?>">
                    <label class="control-label" for="threed_p"><?=__('Link')?></label>
                    <div class="controls">
                        <input type="text" class="input-xxlarge" name="threed" id="threed_p" value="<?=$sel['threed']?>">
                    </div>
                </div>
                
                <div class="control-group">
                    <label class="control-label" for="title_p"><?=__('Title')?></label>
                    <div class="controls">
                        <input type="text" class="input-xxlarge" name="title" id="title_p" value="<?=$mdata->title?>">
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label" for="parent_p"><?=__('Parent')?></label>
                    <div class="controls">
                        <select class="input-xxlarge" name="parent" id="parent_p">
                            <option value="0"><?=__("No")?></option>
                            <?foreach ($parrents as $links) {?>
                                <option value="<?=$links->id?>" <?if ($links->id == $item_id) {?>disabled="disabled"<?}?> <?if ($mdata->parent_id == $links->id) {?>selected="selected"<?}?>><?=$links->title?></option>
                            <?}?>
                        </select>
                    </div>
                </div>
                <div class="control-group">
                    <label class="control-label" for="description_p"><?=__('Description')?></label>
                    <div class="controls">
                        <textarea name="description" class="input-xxlarge" id="description_p"><?=$mdata->description?></textarea>
                    </div>
                </div>
                
                <div class="control-group">
                    <label class="control-label" for="icon_p"><?=__('Icon')?></label>
                    <div class="controls">
                        <input type="text" class="input-xxlarge" name="icons" id="icon_p" value="<?=$mdata->icons?>">
                    </div>
                </div>
                
                <div class="control-group">
                    <label class="control-label" for="classes_p"><?=__('Item class')?></label>
                    <div class="controls">
                        <input type="text" class="input-xxlarge" name="classes" id="classes_p" value="<?=$mdata->classes?>">
                    </div>
                </div>
                
                <div class="control-group">
                    <label class="control-label" for="visible_p"><?=__('Visible')?></label>
                    <div class="controls">
                        <p><input type="radio" name="visible" <?if ($mdata->hidden == 0) {?>checked="checked"<?}?> class="radio" value="0">&nbsp;Да&nbsp;&nbsp;&nbsp;
                        <input type="radio" name="visible" <?if ($mdata->hidden == 1) {?>checked="checked"<?}?> class="radion" value="1">&nbsp;Нет</p>
                    </div>
                </div>
            </div>
        </div>	
    </form>
</div>
                </div>
            </div>
        </div>
    </div>
</div>