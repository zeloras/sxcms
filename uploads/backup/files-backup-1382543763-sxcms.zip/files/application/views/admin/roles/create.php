<div class="main">
    <div class="container">
        <div class="row">
            <div class="span12">
                <div class="widget stacked">
<div class="widget-header">
    <i class="icon-file"></i>
    <h3><?=__('Role create')?></h3>
    <span class="action_buttons">
        <button class="btn pull-right formSubmit" data-form="#submit-form" data-after="exit" data-action="/admin/roles/add">
            <i class=" icon-save icon-large"></i> <?=__('Save and exit')?>
        </button>
        <button class="btn btn-success pull-right formSubmit" data-form="#submit-form" data-after="save" data-action="/admin/roles/add">
            <i class=" icon-save icon-large"></i> <?=__('Save')?>
        </button>
        <button data-href="/admin/roles" data-container="#base-container" class="btn pull-right btn-info pjax_button">
            <i class="icon-arrow-left"></i> <?=__('Back')?>
        </button>
    </span>
</div>
                    
<div class="widget-content">
    <?if (isset($success)) {?>
        <div id="success_block">
            <p id="status_success">showMessage('<?=__('Success create role')?>', '<?=__('Status role create')?>', 'success')</p>
            <p id="url_success">/admin/roles/edit/<?=$success?></p>
            <p id="url_success_exit">/admin/roles/</p>
        </div>
    <?}?>
    <div id="errors_block">
        <?if (isset($errors)) {?>
        <div class="alert alert-error">
            <strong>Ошибка!</strong>
            <ul>
                <?foreach ($errors as $error) {?>
                    <li><?=__($error)?></li>
                <?}?>
            </ul>
        </div>
        <?}?>
    </div>
    <form id="submit-form" method="post" class="form-horizontal">
        <input type="hidden" name="submit_this_form" value="1">
            <div class="control-group">
                <label class="control-label" for="title_p"><?=__('Title')?></label>
                <div class="controls">
                    <input type="text" class="input-xxlarge" name="title" id="title_p">
                </div>
            </div>

            <div class="control-group">
                <label class="control-label" for="name_p"><?=__('Name')?></label>
                <div class="controls">
                    <input type="text" class="input-xxlarge" name="name" id="name_p">
                </div>
            </div>

            <div class="control-group">
                <label class="control-label" for="description_p"><?=__('Description')?></label>
                <div class="controls">
                    <input type="text" class="input-xxlarge" name="description" id="description_p">
                </div>
            </div>
                
            <div class="control-group">
                <div class="span3 pull-left">
                    <div class="widget stacked widget-table">
                        <div class="widget-header">
                            <span class="icon-th"></span>
                            <h3>Страницы</h3>
                        </div>

                        <div class="widget-content">
                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="11"></span> Просмотр списка страниц
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="12"></span> Создание страниц
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="13"></span> Редактирование страниц
                            </div>
                            
                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="14"></span> Удаление страниц
                            </div>
                        </div>
                    </div>
                </div>

                <div class="span3 pull-left">
                    <div class="widget stacked widget-table">
                        <div class="widget-header">
                            <span class="icon-list-alt"></span>
                            <h3>Категории</h3>
                        </div>

                        <div class="widget-content">
                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="21"></span> Просмотр списка категорий
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="22"></span> Создание категорий
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="23"></span> Редактирование категорий
                            </div>
                            
                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="24"></span> Удаление категорий
                            </div>
                        </div>
                    </div>
                </div>

                <div class="span3 pull-left">
                    <div class="widget stacked widget-table">
                        <div class="widget-header">
                            <span class="icon-link"></span>
                            <h3>Меню</h3>
                        </div>

                        <div class="widget-content">
                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="31"></span> Просмотр списка меню
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="32"></span> Создание меню
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="33"></span> Редактирование меню
                            </div>
                            
                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="34"></span> Удаление меню
                            </div>
                        </div>
                    </div>
                </div>

                <div class="span3 pull-left">
                    <div class="widget stacked widget-table">
                        <div class="widget-header">
                            <span class="icon-group"></span>
                            <h3>Группы</h3>
                        </div>

                        <div class="widget-content">
                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="41"></span> Просмотр списка групп
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="42"></span> Создание групп
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="43"></span> Редактирование групп
                            </div>
                            
                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="44"></span> Удаление групп
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="span3 pull-left">
                    <div class="widget stacked widget-table">
                        <div class="widget-header">
                            <span class="icon-user"></span>
                            <h3>Пользователи</h3>
                        </div>

                        <div class="widget-content">
                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="51"></span> Просмотр списка пользователей
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="52"></span> Создание пользователей
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="53"></span> Редактирование пользователей
                            </div>
                            
                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="54"></span> Удаление пользователей
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="span3 pull-left">
                    <div class="widget stacked widget-table">
                        <div class="widget-header">
                            <span class="icon-user"></span>
                            <h3>Для пользователей</h3>
                        </div>

                        <div class="widget-content">
                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="61"></span> Просмотр страниц
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="62"></span> Комментирование
                            </div>

                            <div class="checkbox-row">
                                <span class="niceCheck"><input type="checkbox" name="access[]" value="63"></span> Авторизация
                            </div>
                        </div>
                    </div>
                </div>
            </div>  
        </form>
    </div>
                </div>
            </div>
        </div>
    </div>
</div>